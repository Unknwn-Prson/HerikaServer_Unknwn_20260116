<?php

require_once(__DIR__."/utils.php");
// used for openai_token_count table

require_once(__DIR__."/utils_game_timestamp.php");
require_once(__DIR__."/model_dynmodel.php");
require_once(__DIR__."/core/npc_master.class.php");


function ChangeHerikaName($new_name="") {
    if ($new_name > "") {
        SaveOriginalHerikaName();
        $GLOBALS["HERIKA_NAME"] = $new_name;
    }
}

function SaveOriginalHerikaName() {
    $b_already_saved = ($GLOBALS["ORIGINAL_HERIKA_NAME_SAVED"] ?? false);
    if (!$b_already_saved) {
        $herika = ($GLOBALS["HERIKA_NAME"] ?? "");
        if ((strlen($herika) > 0) && ($herika != "Player") && ($herika != "LLMFallback") && (stripos($herika, "Narrator") === false) && (stripos($herika, "actor") === false) && (stripos($herika, "everyone") === false) && (stripos($herika, "*") === false) && (stripos($herika, "none") === false) ) {
            $GLOBALS["ORIGINAL_HERIKA_NAME"] = $herika;
            $GLOBALS["ORIGINAL_HERIKA_NAME_SAVED"] = true;
        } else {
            Logger::debug("SaveOriginalHerikaName: ignored new value for HERIKA_NAME {$herika}");
        }
    }
}

function GetOriginalHerikaName() {
    $b_already_saved = ($GLOBALS["ORIGINAL_HERIKA_NAME_SAVED"] ?? false);
    if ($b_already_saved) {
        $herika = $GLOBALS["ORIGINAL_HERIKA_NAME"];
    } else {
        $herika = $GLOBALS["HERIKA_NAME"];
    }
    return $herika;
} 

function ReplacePlayerNamePlaceholder($s_input) {
    //replace #PLAYER_NAME# with player name
    $s_res = $s_input;
    if ((strlen(trim($s_input))) > 12) {
        $s_res = strtr($s_input, [
            "#HERIKA_NAME#" =>$GLOBALS["HERIKA_NAME"],
            "#PLAYER_NAME#"=>$GLOBALS["PLAYER_NAME"] 
        ]);
    }
    return $s_res;
}

function getGoldFromMetadata($npcName = null) {
    if ($npcName === null) {
        $npcName = isset($GLOBALS["HERIKA_NAME"]) ? $GLOBALS["HERIKA_NAME"] : "";
    }
    
    if (empty($npcName)) {
        return 0;
    }
    
    try {
        $npcMaster = new NpcMaster();
        $npcData = $npcMaster->getByName($npcName);
        
        if (!$npcData) {
            return 0;
        }
        
        $metaData = $npcMaster->getMetaData($npcData);
        
        if (!isset($metaData["inventory"]) || !is_array($metaData["inventory"])) {
            return 0;
        }
        
        foreach ($metaData["inventory"] as $item) {
            $itemName = isset($item["name"]) ? strtolower($item["name"]) : "";
            if (stripos($itemName, "gold") !== false || stripos($itemName, "coin") !== false || stripos($itemName, "septim") !== false) {
                return isset($item["count"]) ? intval($item["count"]) : 0;
            }
        }
    } catch (Exception $e) {
        // Silently fail and return 0
    }
    
    return 0;
}

function isItemBlacklisted($itemName) {
    if (!isset($GLOBALS["ITEM_BLACKLIST"]) || empty($GLOBALS["ITEM_BLACKLIST"])) {
        return false;
    }
    
    $blacklistedItems = array_map('trim', explode(',', $GLOBALS["ITEM_BLACKLIST"]));
    $itemNameLower = strtolower(trim($itemName));
    
    foreach ($blacklistedItems as $blacklistedItem) {
        if (strtolower($blacklistedItem) === $itemNameLower) {
            return true;
        }
    }
    
    return false;
}

/**
 * Lookup description from descriptions table, supporting mod FormIDs (XX prefix)
 * Tries exact FormID first, then falls back to XX-prefixed version for mod items
 * 
 * @param string $formId The FormID to lookup (hex format, e.g., "0303572F")
 * @return array|null Array with 'name' and 'description' keys, or null if not found
 */
function lookupDescriptionByFormID(string $formId): ?array {
    global $db;
    
    // Ensure FormID is properly formatted (8 hex digits, uppercase)
    $formId = strtoupper(str_replace('0x', '', $formId));
    $formId = str_pad($formId, 8, '0', STR_PAD_LEFT);
    
    // Try exact FormID first
    $escapedFormId = $db->escape($formId);
    $record = $db->fetchOne(
        "SELECT name, description FROM descriptions WHERE baseid = '{$escapedFormId}' LIMIT 1"
    );
    
    if ($record && !empty($record['name'])) {
        return $record;
    }
    
    // If not found and FormID starts with a mod index (first 2 digits not 00-03), try XX prefix
    $modIndex = substr($formId, 0, 2);
    if ($modIndex !== '00' && $modIndex !== '01' && $modIndex !== '02' && $modIndex !== '03') {
        // Replace first 2 digits with XX for mod item lookup
        $xxFormId = 'XX' . substr($formId, 2);
        $escapedXXFormId = $db->escape($xxFormId);
        $record = $db->fetchOne(
            "SELECT name, description FROM descriptions WHERE baseid = '{$escapedXXFormId}' LIMIT 1"
        );
        
        if ($record && !empty($record['name'])) {
            return $record;
        }
    }
    
    return null;
}

/**
 * Get height description based on scale value
 * Reads height descriptions from prompts table with hardcoded fallback
 * 
 * @param float $scale The NPC scale value (typically 0.6 to 1.4)
 * @return string Height description or empty string if not found
 */
function getHeightDescription(float $scale): string {
    static $heightDescriptions = null;
    
    // Hardcoded fallback in case database fails
    $fallbackDescriptions = [
        ['name' => 'VerySmall', 'min_scale' => 0.0, 'max_scale' => 0.60, 'description' => 'Very small and tiny in stature'],
        ['name' => 'Small', 'min_scale' => 0.60, 'max_scale' => 0.80, 'description' => 'Smaller than most people'],
        ['name' => 'ModestStature', 'min_scale' => 0.80, 'max_scale' => 0.95, 'description' => 'Slightly below average height'],
        ['name' => 'Average', 'min_scale' => 0.95, 'max_scale' => 1.05, 'description' => 'Typical height'],
        ['name' => 'Tall', 'min_scale' => 1.05, 'max_scale' => 1.20, 'description' => 'Tall, standing a head above most people'],
        ['name' => 'VeryTall', 'min_scale' => 1.20, 'max_scale' => 1.40, 'description' => 'Very tall'],
        ['name' => 'Giantlike', 'min_scale' => 1.40, 'max_scale' => 99.0, 'description' => 'Giant in height and stature']
    ];
    
    // Load height descriptions from prompts table (cached)
    if ($heightDescriptions === null) {
        try {
            global $db;
            $result = $db->fetchOne("SELECT COALESCE(custom_prompt, default_prompt) as prompt FROM prompts WHERE prompt_key = 'height_descriptions'");
            
            if ($result && !empty($result['prompt'])) {
                $data = json_decode($result['prompt'], true);
                $heightDescriptions = $data['height_descriptions'] ?? $fallbackDescriptions;
            } else {
                // Database query succeeded but no data - use fallback
                $heightDescriptions = $fallbackDescriptions;
            }
        } catch (Exception $e) {
            // Database error - use fallback
            Logger::debug("Using fallback height descriptions due to database error: " . $e->getMessage());
            $heightDescriptions = $fallbackDescriptions;
        }
    }
    
    // Find matching height description
    foreach ($heightDescriptions as $desc) {
        if ($scale >= $desc['min_scale'] && $scale < $desc['max_scale']) {
            return $desc['description'];
        }
    }
    
    return ''; // No description if out of range
}


function DataDequeue($timestamp = 0)
{
    global $db;
    if ($timestamp !== 0) {
        $clause="and localts<={$timestamp} ";
    } else {
        $clause="";
    }
    // Use atomic UPDATE...RETURNING to prevent race conditions where multiple concurrent
    // requests could fetch the same dialogue before it's marked as sent
    $results = $db->fetchAll(
        "UPDATE responselog 
         SET sent=1 
         WHERE rowid IN (
             SELECT rowid FROM responselog WHERE sent=0 $clause ORDER BY rowid ASC
         )
         RETURNING *, rowid"
    );
    
    $finalData = array();
    foreach ($results as $row) {
        $finalData[] = $row;
    }

    return $finalData;

}

function DataLastDataFor($actor, $lastNelements = -10)
{
    global $db;
    $lastDialogFull = array();
    $results = $db->fetchAll("select  
    case 
      when type like 'info%' or type like 'death%' or  type like 'funcret%' or type like 'location%' or data like '%background chat%' then 'The Narrator:'
      when type='book' then 'The Narrator: ({$GLOBALS["PLAYER_NAME"]} took the book ' 
      else '' 
    end||a.data  as data 
    FROM  eventlog a WHERE data like '%$actor%' 
    and type<>'combatend'  
    and type<>'bored' and type<>'init' and type<>'lockpicked' and type<>'infonpc' and type<>'infoloc' and type<>'infoitems' and type<>'info' and type<>'funcret'  and type<>'quest'
    and type<>'user_input'
    and type<>'funccall'  and type<>'togglemodel' order by gamets desc,ts desc,localts desc,rowid desc LIMIT 150 OFFSET 0");
    $lastData = "";


    foreach ($results as $row) {

        if ($lastData != md5($row["data"])) {
            if ((strpos($row["data"], "{$GLOBALS["HERIKA_NAME"]}:") !== false) || ((strpos($row["data"], "{$GLOBALS["PLAYER_NAME"]}:") !== false))) {
                $pattern = "/\(Context location:[^)]+?\)/"; // Remove only the exact context location pattern
                $replacement = "";
                $row["data"] = preg_replace($pattern, $replacement, $row["data"]); // // assistant vs user war
                if ((strpos($row["data"], "{$GLOBALS["HERIKA_NAME"]}:") !== false)) {
                    $role = "assistant";
                } else {
                    $role = "user";
                }

                $lastDialogFull[] = array('role' => $role, 'content' => $row["data"]);

            } else {
                $lastDialogFull[] = array('role' => 'user', 'content' => $row["data"]);
            }

        }
        $lastData = md5($row["data"]);

    }

    // Date issues

    foreach ($lastDialogFull as $n => $line) {

        $pattern = '/(\w+), (\d{1,2}:\d{2} (?:AM|PM)), (\d{1,2})(?:st|nd|rd|th) of ([A-Za-z\'\ ]+), 4E (\d+)/'; //extract also for months with apostrophe like Sun's Something
        $replacement = 'Day name: $1, Hour: $2, Day Number: $3, Month: $4, 4th Era, Year: $5';
        $result = preg_replace($pattern, $replacement, $line["content"]);
        $lastDialogFull[$n]["content"] = $result;
    }


    // Clean context locations for Herikas dialog.


    $lastDialogFullReversed = array_reverse($lastDialogFull);
    $lastDialog = array_slice($lastDialogFullReversed, $lastNelements);
    $last_location = null;


    return $lastDialog;

}

/**
 * Get context for actor to send to llm
 */
function DataLastInfoFor($actorBeingCalled, $lastNelements = -2,$addNPCDescriptions=false,$excludeBusy=false)
{
    
    $followers=[];
    $actorsInRangeList=DataBeingsInCloseRange();
    $actorsInRange=strtr($actorsInRangeList,["|"=>"\n* "]);
    $actorDetailedList=explode("|",$actorsInRangeList);
    // Not always the same order
    shuffle($actorDetailedList);
    // error_log("[DataLastInfoFor] $actorsInRangeList");
    
    // Track seen faction descriptions to avoid duplicates
    $seenFactionFormIDs = [];
    $factionDescriptions = []; // Store unique faction descriptions
    
    // Actors
    if ($actorsInRange && $addNPCDescriptions) {
        $actorDetailedListWithProfile=[];
        foreach ($actorDetailedList as $actor) {
            if (empty($actor))
                continue;
            if ($excludeBusy)
                if ((strpos($actor,"(busy)")>0)||(strpos($actor,"(dead)")>0))
                    continue;

            $actorName=trim(str_replace("(far away)","",$actor));
            if ($actorName==$GLOBALS["HERIKA_NAME"]) 
                continue;

            /* if (!(strpos($GLOBALS["HERIKA_NAME"],"actor")===false)) { // debug
                Logger::warn("DataLastInfoFor: unexpected value for HERIKA_NAME={$GLOBALS["HERIKA_NAME"]} | actor={$actor} actorname={$actorName} ");
            } */

            if ((strpos($actor,"(")===false) && ($GLOBALS["HERIKA_NAME"]!="The Narrator") && (strpos($GLOBALS["HERIKA_NAME"],"actor")===false)) {   
                $interactions=DirectConversationsWith($actor);
                if ($interactions==0) {
                    $ittext="{$actor} ({$GLOBALS["HERIKA_NAME"]} never talked to {$actorName} before, {$GLOBALS["HERIKA_NAME"]} should speak to this person as to a stranger or traveler...)";
                } else if ($interactions<5) {
                    $ittext="{$actor} ({$GLOBALS["HERIKA_NAME"]} has talked to {$actorName} a couple of times before)";
                } else {
                    $ittext="{$actor}";
                }
            } else {
                $ittext="{$actor}";
            }

            if ($actor==$GLOBALS["PLAYER_NAME"]) {
                // Player - read from core_player table (don't reveal they're "the player character")
                $profileString = "$actor";
                
                try {
                    require_once(__DIR__ . DIRECTORY_SEPARATOR . "core" . DIRECTORY_SEPARATOR . "player.class.php");
                    $player = new Player();
                    
                    // Add appearance if available
                    $appearance = $player->get('appearance');
                    if (!empty($appearance)) {
                        $profileString .= ": " . trim($appearance);
                    }
                    
                    // Add equipment if available
                    $equipmentData = $player->getJson('equipment');
                    if (is_array($equipmentData) && !empty($equipmentData)) {
                        $equipmentParts = [];
                        $slots = ['helmet', 'armor', 'boots', 'gloves', 'amulet', 'ring', 'left_hand', 'right_hand'];
                        foreach ($slots as $slot) {
                            if (!empty($equipmentData[$slot])) {
                                $itemName = trim($equipmentData[$slot]);
                                // Skip blacklisted items, empty names, or placeholder names
                                if (!isItemBlacklisted($itemName) && !empty($itemName) && stripos($itemName, 'Missing Name') === false) {
                                    $equipmentParts[] = $itemName;
                                }
                            }
                        }
                        if (!empty($equipmentParts)) {
                            $profileString .= ". Equipment: " . implode(", ", $equipmentParts);
                        }
                    }
                    
                } catch (Exception $e) {
                    Logger::debug("Could not load player data for context: " . $e->getMessage());
                }
                
                // Don't append $ittext for player - profileString already starts with player name
                $actorDetailedListWithProfile[] = $profileString;
                
            } else {
                
                $actorName = preg_replace("/\s*\(.*?\)\s*/", "", $actor);
                $codename = npcNameToCodename($actorName);
                $npcMaster=new NpcMaster();
                $currentNpcData=$npcMaster->getByName($actorName);

                
                if (isset($currentNpcData["core"]) && !empty($currentNpcData["core"])) {
                    // NPC name should always be at core section.
                    $npcName = $currentNpcData["npc_name"];
                    
                    // Format gender (capitalize first letter)
                    $gender = !empty($currentNpcData["gender"]) ? ucfirst(strtolower(trim($currentNpcData["gender"]))) : "";
                    $race = !empty($currentNpcData["race"]) ? trim($currentNpcData["race"]) : "";
                    
                    // Build name with race/gender in parentheses
                    $nameWithRaceGender = $npcName;
                    if (!empty($gender) && !empty($race)) {
                        $nameWithRaceGender .= " ({$gender} {$race})";
                    } elseif (!empty($race)) {
                        $nameWithRaceGender .= " ({$race})";
                    }
                    
                    // Check for reanimation status early to add to core
                    $extendedData = $npcMaster->getExtendedData($currentNpcData);
                    $reanimationText = "";
                    if (empty($GLOBALS["DISABLE_REANIMATION_TRACKING"]) && isset($extendedData["reanimated"]) && $extendedData["reanimated"] === true) {
                        $reanimationText = " This person has been reanimated from death as a zombie.";
                    }
                    
                    $profileString = "{$nameWithRaceGender}: " . trim("{$currentNpcData["core"]}{$reanimationText}");
                    
                    // Add appearance if available
                    if (!empty($currentNpcData["appearance"])) {
                        $profileString .= ". Appearance: " . trim($currentNpcData["appearance"]);
                    }
                    
                    // Add zombie appearance if reanimated
                    if (empty($GLOBALS["DISABLE_REANIMATION_TRACKING"]) && isset($extendedData["reanimated"]) && $extendedData["reanimated"] === true) {
                        $zombieAppearance = "Their skin has a deathly pale, greyish pallor with a corpse-like appearance. Their eyes are glazed and lifeless, and their movements are stiff and unnatural";
                        if (!empty($currentNpcData["appearance"])) {
                            $profileString .= ". " . $zombieAppearance;
                        } else {
                            $profileString .= ". Appearance: " . $zombieAppearance;
                        }
                    }
                    
                    // Get metadata once for both scale and equipment
                    $metaData = $npcMaster->getMetaData($currentNpcData);
                    
                    // Add height description based on scale
                    if (isset($metaData["stats"]["scale"])) {
                        $heightDesc = getHeightDescription(floatval($metaData["stats"]["scale"]));
                        if (!empty($heightDesc)) {
                            $profileString .= ". " . $heightDesc;
                        }
                    }
                    
                    // Add equipment if available
                    if (isset($metaData["equipment"]) && is_array($metaData["equipment"])) {
                        $equipmentParts = [];
                        $slots = ['helmet', 'armor', 'boots', 'gloves', 'amulet', 'ring', 'left_hand', 'right_hand'];
                        foreach ($slots as $slot) {
                            if (!empty($metaData["equipment"][$slot])) {
                                $itemName = trim($metaData["equipment"][$slot]);
                                // Skip blacklisted items, empty names, or placeholder names
                                if (!isItemBlacklisted($itemName) && !empty($itemName) && stripos($itemName, 'Missing Name') === false) {
                                    $equipmentParts[] = $itemName;
                                }
                            }
                        }
                        if (!empty($equipmentParts)) {
                            $profileString .= ". Equipment: " . implode(", ", $equipmentParts);
                        }
                        
                        // Check if humanoid NPC has no body armor - if so, note they're naked
                        $humanoidRaces = ['nord', 'imperial', 'breton', 'redguard', 'orc', 'orsimer', 
                                        'altmer', 'highelf', 'bosmer', 'woodelf', 'dunmer', 'darkelf', 
                                        'argonian', 'khajiit', 'khajit'];
                        $npcRace = isset($currentNpcData["race"]) ? strtolower(trim($currentNpcData["race"])) : '';
                        
                        if ($npcRace && in_array($npcRace, $humanoidRaces) && empty($metaData["equipment"]["armor"])) {
                            $profileString .= ". Naked (no body armor/clothing worn)";
                        }
                    }
                    
                    // Add faction information after equipment
                    $extendedData = $npcMaster->getExtendedData($currentNpcData);
                    if (isset($extendedData['factions']) && is_array($extendedData['factions']) && count($extendedData['factions']) > 0) {
                        $factionNames = [];
                        foreach ($extendedData['factions'] as $faction) {
                            if (isset($faction['formid'])) {
                                // Lookup faction using helper function (supports XX prefix)
                                $factionRecord = lookupDescriptionByFormID($faction['formid']);
                                
                                // Only add if found in descriptions table
                                if ($factionRecord && !empty($factionRecord['name'])) {
                                    $factionNames[] = $factionRecord['name'];
                                    
                                    // Track faction description (only once)
                                    if (!in_array($faction['formid'], $seenFactionFormIDs)) {
                                        $seenFactionFormIDs[] = $faction['formid'];
                                        if (!empty($factionRecord['description'])) {
                                            $factionDescriptions[$factionRecord['name']] = $factionRecord['description'];
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (!empty($factionNames)) {
                            $profileString .= ". Groups " . implode(", ", $factionNames);
                        }
                    }
                    
                    $actorDetailedListWithProfile[] = $profileString;

                }
                else
                    $actorDetailedListWithProfile[]="$ittext";
                
            }
        }
        $actorDetailedListWithProfileSanitized=[];
        foreach ($actorDetailedListWithProfile as $e)
            if (!empty($e))
                $actorDetailedListWithProfileSanitized[]=$e;

        if (!empty($actorDetailedListWithProfileSanitized))
            $actorsInRange=implode("\n## ",$actorDetailedListWithProfileSanitized);
        else 
            $actorsInRange="\nNo more actors in scene";// Catch
    }

    
    //Followers

    foreach (json_decode(DataGetCurrentPartyConf(),JSON_OBJECT_AS_ARRAY) as $followername=>$followerdata) {
        if (!$followername)
            continue;

        if ($followername==$GLOBALS["PLAYER_NAME"]) {
            $followers[]="$followername (roleplayed by player)";

        } else {
            if (isset($followerdata["core"]))
                $followers[]="{$followerdata["core"]} level {$followerdata["level"]},{$followerdata["gender"]} {$followerdata["race"]}".(($followerdata["isVampire"]=="yes")?", is vampire":"");
            else
                $followers[]="$followername, level {$followerdata["level"]},{$followerdata["gender"]} {$followerdata["race"]}".(($followerdata["isVampire"]=="yes")?", is vampire":"");
            
            $followersV2[]=$followername;

        }
            
    }

    $followers[]="{$GLOBALS["PLAYER_NAME"]}";
    $followersV2[]=$GLOBALS["PLAYER_NAME"];

    if (!isset($GLOBALS["PROMPT_NEARBY_SECTIONS"])) {
        $GLOBALS["PROMPT_NEARBY_SECTIONS"] = "";
    }
    $GLOBALS["PROMPT_NEARBY_SECTIONS"] .= "\n<nearby_actors>\n# NEARBY ACTORS/NPC IN THE SCENE \n## $actorsInRange\n</nearby_actors>";
    
    // Add faction descriptions section if any factions were found
    if (!empty($factionDescriptions)) {
        $factionDescText = "";
        foreach ($factionDescriptions as $name => $desc) {
            $factionDescText .= "## {$name}: {$desc}\n";
        }
        $GLOBALS["PROMPT_NEARBY_SECTIONS"] .= "\n<group_descriptions>\n# GROUP/FACTION DESCRIPTIONS\n{$factionDescText}</group_descriptions>";
    }
    
    // Add nearby items to context if available
    $itemsInRange = DataItemsInCloseRange();
    
    if (!empty($itemsInRange)) {
        $itemsList = explode(',', $itemsInRange);
        $formattedItems = [];
        $seenBaseIDs = [];
        $itemDescriptions = [];
        
        foreach ($itemsList as $item) {
            $trimmedItem = trim($item);
            if (empty($trimmedItem)) continue;
            
            // Parse format: "0xRefID:0xBaseID:ItemName" (new) or "0xRefID:ItemName" (old)
            $parts = explode(':', $trimmedItem, 3);
            
            if (count($parts) >= 3) {
                // New format with BaseID
                $refID = $parts[0];
                $baseID = $parts[1];
                $itemName = $parts[2];
                
                // Strip (STEALING) tag for blacklist check
                $itemNameClean = str_replace(' (STEALING)', '', $itemName);
                
                // Skip blacklisted items
                if (isItemBlacklisted($itemNameClean)) {
                    continue;
                }
                
                // Track unique base IDs for descriptions
                $hasDescription = false;
                if (!in_array($baseID, $seenBaseIDs)) {
                    $seenBaseIDs[] = $baseID;
                    
                    // Look up description from descriptions table
                    $baseIDDec = hexdec(str_replace('0x', '', $baseID));
                    $descRecord = $GLOBALS["db"]->fetchOne(
                        "SELECT description FROM descriptions WHERE baseid = '{$baseIDDec}' LIMIT 1"
                    );
                    
                    if ($descRecord && !empty($descRecord['description'])) {
                        // Store description under clean name (without STEALING tag)
                        $itemDescriptions[$itemNameClean] = $descRecord['description'];
                        $hasDescription = true;
                    }
                }
                
                // If filter is enabled and item has no description, skip it
                if (isset($GLOBALS["GROUND_ITEMS_DESCRIPTIONS_ONLY"]) && $GLOBALS["GROUND_ITEMS_DESCRIPTIONS_ONLY"] && !$hasDescription) {
                    continue;
                }
                
                // Format for display: "RefID:ItemName" (hide BaseID from NPC, keep STEALING tag)
                $displayItem = "{$refID}:{$itemName}";
                $formattedItems[] = $displayItem;
            } elseif (count($parts) == 2) {
                // Old format without BaseID - just use as-is
                $refID = $parts[0];
                $itemName = $parts[1];
                
                // Strip (STEALING) tag for blacklist check
                $itemNameClean = str_replace(' (STEALING)', '', $itemName);
                
                // Skip blacklisted items
                if (isItemBlacklisted($itemNameClean)) {
                    continue;
                }
                
                // Keep STEALING tag in display
                $displayItem = "{$refID}:{$itemName}";
                $formattedItems[] = $displayItem;
            }
        }
        
        if (!empty($formattedItems)) {
            $itemsText = implode("\n## ", $formattedItems);
            
            // Add descriptions for unique items if available
            $descriptionText = "";
            if (!empty($itemDescriptions)) {
                $descParts = [];
                foreach ($itemDescriptions as $name => $desc) {
                    $descParts[] = "{$name}: {$desc}";
                }
                $descriptionText = "\n\n# ITEM DESCRIPTIONS\n## " . implode("\n## ", $descParts);
            }
            
            $contextContent = "<nearby_items>\n# NEARBY ITEMS (format: RefID:ItemName)\n## {$itemsText}{$descriptionText}\n</nearby_items>";
            if (!isset($GLOBALS["PROMPT_NEARBY_SECTIONS"])) {
                $GLOBALS["PROMPT_NEARBY_SECTIONS"] = "";
            }
            $GLOBALS["PROMPT_NEARBY_SECTIONS"] .= "\n" . $contextContent;
        }
    }
    
    /*
    if (!isset($GLOBALS["IS_NPC"]) || !$GLOBALS["IS_NPC"])
        $lastDialog[] = array('role' => 'user', 'content' => "# PARTY STATUS\n## ". (implode("\n## ",$followers)));
    else 
        $lastDialog[] = array('role' => 'user', 'content' => "# YOU'RE NOT PART OF THE GROUP FORMED BY\n## ". (implode("\n## ",$followers)));

    $arr_poi = DataPosibleLocationsToGo();
    if (isset($arr_poi) && is_array($arr_poi) && (count($arr_poi) > 0)) {
        $lastDialog[] = array('role' => 'user', 'content' => "# POIs - Points of Interest nearby \n## ". (implode("\n## ",$arr_poi)));
    }
    */
    if (!empty($followersV2)) {
        $lastFollower = array_pop($followersV2);
        if (!empty($followersV2)) {
            $followersString = implode(", ", $followersV2) . " and " . $lastFollower;
        } else {
            $followersString = $lastFollower;
        }
    } else {
        $followersString = "";
    }

	if ($followersString!=$GLOBALS["PLAYER_NAME"] && !empty($followersString)) {
	    if (!isset($GLOBALS["PROMPT_NEARBY_SECTIONS"])) {
	        $GLOBALS["PROMPT_NEARBY_SECTIONS"] = "";
	    }
	    $GLOBALS["PROMPT_NEARBY_SECTIONS"] .= "\n<adventuring_party>
        # ADVENTURING PARTY
	     $followersString are together as an **adventuring party**, acting as close companions.
	     - The others **can know each other**, but they are **not part** of {$followersString}'s group.
	     - Generally speaking, any mention of **plans, missions, or objectives** refers **only to the adventuring party**, never to the other NPCs.
	     </adventuring_party>";
	}
    $arr_poi = DataPosibleLocationsToGo();
    if (isset($arr_poi) && is_array($arr_poi) && (count($arr_poi) > 0)) {
        // Filter blacklisted locations
        if (isset($GLOBALS["LOCATION_BLACKLIST"]) && !empty($GLOBALS["LOCATION_BLACKLIST"])) {
            $blacklistedLocations = array_map('trim', explode(',', strtolower($GLOBALS["LOCATION_BLACKLIST"])));
            $arr_poi = array_filter($arr_poi, function($poi) use ($blacklistedLocations) {
                $poiLower = strtolower($poi);
                foreach ($blacklistedLocations as $blacklistedLocation) {
                    if (!empty($blacklistedLocation) && strpos($poiLower, $blacklistedLocation) !== false) {
                        return false;
                    }
                }
                return true;
            });
        }
        
        if (count($arr_poi) > 0) {
            if (!isset($GLOBALS["PROMPT_NEARBY_SECTIONS"])) {
                $GLOBALS["PROMPT_NEARBY_SECTIONS"] = "";
            }
            $GLOBALS["PROMPT_NEARBY_SECTIONS"] .= "\n<points_of_interest>\n# POIs - Points of Interest nearby \n## ". (implode("\n## ",$arr_poi))."\n</points_of_interest>";
        }
    }
    
    
 
    // Rolemaster notes
    
    $timeCut=time();
    $rolemasterNotes=$GLOBALS["db"]->fetchAll("SELECT data FROM rolemaster where type='scenenote' and localts+ttl>$timeCut order by localts asc");
    if (is_array($rolemasterNotes) && !empty($rolemasterNotes)) {
        $notes=[];
        foreach ($rolemasterNotes as $note)
            $notes[]= $note["data"];
        if (!isset($GLOBALS["PROMPT_NEARBY_SECTIONS"])) {
            $GLOBALS["PROMPT_NEARBY_SECTIONS"] = "";
        }
        $GLOBALS["PROMPT_NEARBY_SECTIONS"] .= "\n<scene_notes>\n# SCENE NOTES \n## ".implode(".",$notes)."</scene_notes>";
    }
        

    //$lastDialog[]=array('role' => 'user', 'content' => $GLOBALS["PROMPT_NEARBY_SECTIONS"]);
    // this is going to return nothing
    return $lastDialog;

}

function DataLocationsAround($current_location = "") {
    global $db;

    $s_res = "";

    if (strlen($current_location) > 0) {
        $s_loc = $db->escape(strtolower(trim($current_location))); 
        $s_sql = "SELECT data FROM eventlog WHERE (type in ('infoloc')) AND (data ILIKE '(Context location: {$s_loc}%') ORDER BY gamets DESC, ts DESC LIMIT 1";
    } else {
        $s_sql = "SELECT data FROM eventlog WHERE (type in ('infoloc')) AND (data ILIKE '(Context location:%') ORDER BY gamets DESC, ts DESC LIMIT 1";
    }
    $results = $db->fetchAll($s_sql);
    foreach ($results as $row) {
        $re = '/(to go:)(.+),,/';
        preg_match($re, $row["data"], $matches, PREG_OFFSET_CAPTURE, 0);
        if (isset($matches[2][0])) {
            $s_res .= $matches[2][0];
        }
        break;
    }
    
    return $s_res;
} 

function DataPosibleLocationsToGo()
{
    if (isset($GLOBALS["CACHE_POSIBLE_LOCATIONS_TO_GO"])) {
        return $GLOBALS["CACHE_POSIBLE_LOCATIONS_TO_GO"];
    }

    global $db;
    $lastDialogFull = array();
    $results = $db->fetchAll("select  a.data  as data  FROM  eventlog a 
    WHERE type in ('infoloc')  order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    $lastData = "";
    $retData = [];
    foreach ($results as $row) {
        //$row = $results->fetchArray();

        $re = '/(to go:)(.+),,/';

        preg_match($re, $row["data"], $matches, PREG_OFFSET_CAPTURE, 0);
        if (isset($matches[2])) {
            $retData = explode(",", $matches[2][0]);
        }
        ;
        break;
    }

    // Location blacklist // $LOCATION_BLACKLIST
    // --- BEGIN CACHED CONNECTOR FIX ---
    // Original: explode(",", $GLOBALS["LOCATION_BLACKLIST"] ?: [])
    // Bug: ?: [] returns array when undefined, causing explode() TypeError
    $LOCATION_BLACKLIST_ARRAY=explode(",", isset($GLOBALS["LOCATION_BLACKLIST"]) && is_string($GLOBALS["LOCATION_BLACKLIST"]) ? $GLOBALS["LOCATION_BLACKLIST"] : "");
    // --- END CACHED CONNECTOR FIX ---
    if (count($LOCATION_BLACKLIST_ARRAY) > 0) {
        foreach ($retData as $k => $v) {
            foreach ($LOCATION_BLACKLIST_ARRAY as $blacklistedLocation) {
                $blacklistedLocationTrimmed = trim($blacklistedLocation);
                if (!empty($blacklistedLocationTrimmed) && (stripos($v, $blacklistedLocationTrimmed) !== false)) {
                    unset($retData[$k]);
                    break; // No need to check other blacklisted locations
                }
            }
        }
    }
    foreach ($retData as $k => $v) {
        if ($v=="Skyrim") {
            $retData[$k].=" (exit)";
        }
    }
    //print_r($matches);
    // ? this part with 'Herika can see this beings in range:' seems outdated 
    /* $results = $db->fetchAll("select  a.data  as data  FROM  eventlog a 
    WHERE type in ('infonpc')  order by gamets desc,ts desc LIMIT 50 OFFSET 0");
    $lastData = "";
    $matches = [];
    foreach ($results as $row) {
        //$row = $results->fetchArray();

        $pattern = "/Herika can see this beings in range:(.*)/";
        preg_match_all($pattern, $row["data"], $matches);

        if (!empty($matches) && !empty($matches[1]) && isset($matches[1][0])) {
            $retData = array_merge($retData, explode(",", $matches[1][0]));
        }

        //print_r($matches);
        break;
    }

    foreach ($retData as $k => $v) {
        if (strlen($v) < 2) {
            unset($retData[$k]);
        } else {
            $retData[$k] = preg_replace("/\([^)]+\)/", '', $v);
            //$retData[$k]=$v;
            $retData[$k]=trim($retData[$k]);
        }
        
    }     */
    //return ["Goldenglow Estate","Faldar's Tooth","Goldenglow Estate Sewer","Pit Wolf(dead)","Pit Wolf(dead)","Herika"];
    //error_log("DataPosibleLocationsToGo: ".print_r($retData,true));
    $GLOBALS["CACHE_POSIBLE_LOCATIONS_TO_GO"] = array_values($retData);
    return $GLOBALS["CACHE_POSIBLE_LOCATIONS_TO_GO"];
}

function DataPosibleLocationsToGoWide()
{
    if (isset($GLOBALS["CACHE_POSIBLE_LOCATIONS_TO_GO_WIDE"])) {
        return $GLOBALS["CACHE_POSIBLE_LOCATIONS_TO_GO_WIDE"];
    }

    global $db;
    $lastDialogFull = array();
    $results = $db->fetchOne("select  a.data  as data  FROM  eventlog a 
    WHERE type in ('region')  order by gamets desc,ts desc LIMIT 1 OFFSET 0");

    if ($results) {
        $regCn=$db->escape(trim($results["data"]));
        error_log("select  name  FROM  locations where region ilike'{$regCn}'");
        $locs = $db->fetchAll("select  name,tags  FROM  locations where region ilike '{$regCn}'");
        $r=[];
        foreach ($locs as $loc) {
            if ($loc["tags"])
                $r[$loc["name"]]=$loc["tags"];
            else
                $r[$loc["name"]]="";

        }
        $GLOBALS["CACHE_POSIBLE_LOCATIONS_TO_GO_WIDE"] = $r;
        return $r;
    }

    $GLOBALS["CACHE_POSIBLE_LOCATIONS_TO_GO_WIDE"] = [];
    return [];

}

function DataPosibleInspectTargets($pack=true)
{
    if (isset($GLOBALS["CACHE_POSIBLE_INSPECT_TARGETS"][(int)$pack])) {
        return $GLOBALS["CACHE_POSIBLE_INSPECT_TARGETS"][(int)$pack];
    }

    global $db;
    $results = $db->fetchAll("select  a.data  as data  FROM  eventlog a 
    WHERE type in ('infonpc')  order by gamets desc,ts desc LIMIT 50 OFFSET 0");
    $lastData = "";
    $matches = [];
    foreach ($results as $row) {
        //$row = $results->fetchArray();

        $pattern = "/beings in range:(.*)/";
        preg_match_all($pattern, $row["data"], $matches);

        if (!empty($matches) && !empty($matches[1]) && isset($matches[1][0])) {
            $retData = explode(",", $matches[1][0]);
        }


        break;
    }

    
    
    if (!isset($retData)||!is_array($retData)) {
        $retData = [];
    }

    $compData=[];

    if ($pack) {
        foreach ($retData as $k => $v) {
            if (strlen($v) < 2) {
                unset($retData[$k]);
            } else {
                $retData[$k] = preg_replace("/\([^)]+\)/", '', $v);
                $retData[$k] = $v;
                if (!isset($compData[$v]))
                    $compData[$v]=0;
                $compData[$v]++; // Reduce same names (Chicken, Chicken -> Chicken)
                //$retData[$k]=$v;

            }

        }
        $retData=[];
        foreach ($compData as $l=>$n) {
            if ($n==1)
                $retData[]="$l";
            else
                $retData[]="$n $l";
        }

        
    }

    $GLOBALS["CACHE_POSIBLE_INSPECT_TARGETS"][(int)$pack] = array_values($retData);
    return $GLOBALS["CACHE_POSIBLE_INSPECT_TARGETS"][(int)$pack];
}

function DataQuestJournal($quest)
{
    global $db;
    if (empty($quest)||($quest=="None")||true) {
        
        $results = $db->fetchAll("SElECT name,id_quest,briefing,briefing2 as notes, 'pending' as status FROM quests");
        $finalRow = [];
        foreach ($results as $row) {
            if (isset($finalRow[$row["id_quest"]])) {
                continue;
            } else {
                $finalRow[$row["id_quest"]] = ["name"=>$row["name"],"briefing"=>$row["briefing"],"personal notes"=>$row["notes"]];
            }
        }

        if (sizeof($finalRow) == 0) {
            $data[] = "no active quests";
        } else {
            $data = array_values($finalRow);
        }

        $extraData = DataGetCurrentTask();

        $data[] = ["side note" => "$extraData"];

        return json_encode($data);

    } else {
        $lastDialogFull = array();
        $results = $db->fetchAll("SElECT  name,id_quest,briefing,data
      FROM quests where lower(id_quest)=lower('$quest') or lower(name)=lower('$quest') ");
        $lastOne = -1;
        $data = array();
        if (!$results) {
            $data["error"] = "quest not found, make sure you use id_quest";
            return json_encode($data);

        }
        foreach ($results as $row) {
            $lastOne++;
            $data[] = $row;
        }
        if ($lastOne >= 0) {
            $data[$lastOne]["stage_completed"] = "no";
        }

        if (sizeof($data) == 0) {
            $data["error"] = "quest not found, make sure you use id_quest";

        }

        return json_encode($data);

    }
}

function removeTalkingToOccurrences($input) {
    $pattern = '/\(talking to [^()]+\)/i';
    preg_match_all($pattern, $input, $matches, PREG_OFFSET_CAPTURE);

    // Get all positions of the matches
    $positions = $matches[0];

    // If there are no matches or only one match, return the input string as it is
    if (count($positions) <= 1) {
        return $input;
    }

    // Remove all but the last occurrence
    for ($i = 0; $i < count($positions) - 1; $i++) {
        $pos = $positions[$i][1];
        $input = substr_replace($input, '', $pos, strlen($positions[$i][0]));
        
        // After each removal, adjust the positions of subsequent matches
        for ($j = $i + 1; $j < count($positions); $j++) {
            $positions[$j][1] -= strlen($positions[$i][0]);
        }
    }

    return $input;
}


function DataLastDataExpandedForNPC($actor, $lastNelements = -10,$sqlfilter="") {

        global $db;

        $actorcn=$db->escape($actor);
        $results = $db->fetchAll("SELECT speaker,speech,listener,gamets,localts,'speech',gamets - LAG(gamets) OVER (ORDER BY gamets ASC) AS gamets_diff,location,ts
        FROM speech where companions like '%$actorcn%' order by ts desc LIMIT 1000 OFFSET 0");    
         $rawData=[];
        foreach ($results as $row) {
            $rawData[] = $row;
        }


        $orderedData = array_reverse($rawData);
        
        $lastDialogFull=[];
        
        $lastlocation="";
        $lastSpeaker=null;
        $lastListener=null;
        $buffer="";
        foreach ($orderedData as $speechEvent)  {
            
            if (($speechEvent["gamets_diff"] * 0.0000024) > 1.0) { // more than one hour
                $lastDialogFull[$speechEvent["ts"]] = array('role' => "user", 'content' => "The Narrator: about ".number_format(floor($speechEvent["gamets_diff"]*0.0000024),0)." hours later...");
            }

            
            if ($lastlocation!=$speechEvent["location"]) {
                $lastlocation=$speechEvent["location"];
                $lastDialogFull[$speechEvent["ts"]] = array('role' => "user", 'content' => "The Narrator: action moved to new location: $lastlocation");
            }

            $currentSpeaker="user";
            
            
            if ($lastSpeaker==$actor)
                $currentSpeaker="assistant";
            else if ($speechEvent["speaker"]=="The Narrator")
                continue;
            
            $talkingto="";
            if ($lastListener!="The Narrator")
                $talkingto="(talking to {$lastListener})";
            
            if ($lastSpeaker==$GLOBALS["PLAYER_NAME"])
                $talkingto="";
            
            if (($lastSpeaker!=$speechEvent["speaker"])&&($lastSpeaker!=null)) {
                $lastDialogFull[$speechEvent["ts"]] = array('role' => $currentSpeaker, 'content' => "$lastSpeaker: $buffer $talkingto");   
                $buffer="";
                $lastSpeaker=$speechEvent["speaker"];
            } else {
                $lastSpeaker=$speechEvent["speaker"];
            }
            $buffer.=$speechEvent["speech"];
            $lastListener=$speechEvent["listener"];

        }
        
        
        $results = $db->fetchAll("SELECT gamets,data,ts FROM eventlog where type in ('infoaction','itemfound') order by gamets desc LIMIT 10 OFFSET 0");    
        $rawData=[];
        foreach ($results as $row) {
            $lastDialogFull[$row["ts"]]= array('role' => 'user', 'content' => "The Narrator: {$row["data"]}");  
        }
        
        $results = $db->fetchAll("SELECT gamets,data,ts FROM eventlog where type in ('infoloc') order by gamets desc LIMIT 10 OFFSET 0");    
        $rawData=[];
        foreach ($results as $row) {
            $lastDialogFull[$row["ts"]]= array('role' => 'user', 'content' => "The Narrator: {$row["data"]}");  
        }

        ksort($lastDialogFull);
        
        $results = $db->fetchAll("SELECT gamets,data,ts FROM eventlog where type in ('inputtext','inputtext_s','ginputtext','ginputtext_s','narrator_inputtext')
            order by gamets desc LIMIT 1 OFFSET 0");    
        $rawData=[];
        foreach ($results as $row) {
            $lastDialogFull[]= array('role' => 'user', 'content' => "{$row["data"]}");  
        }

       
                
        $orderedData = array_slice($lastDialogFull, $lastNelements);
        
        Logger::info("Using NPC data retriever");
        
        
        return $orderedData;
}

function removeEmptyElements(array $array): array {
    return array_filter($array, function($value) {
        return !empty($value) || $value === 0 || $value === "0"; 
    });
}

/**
 * Consolidate repeated similar events
 * 
 * @param array $events Array of event entries with role, content, subtype, type, gamets
 * @return array Consolidated array of events
 */
function consolidateEvents(array $events): array {
    // Hardcoded defaults - always enabled for efficiency
    $timeWindow = 300; // 5 minutes game time
    $typesToConsolidate = ["death", "itemfound", "rpg_word", "spellcast", "npcspellcast", "infoaction"];
    
    $consolidated = [];
    $consolidationBuffer = [];
    
    foreach ($events as $event) {
        if (!isset($event['type']) || !in_array($event['type'], $typesToConsolidate)) {
            // Flush buffer if we hit a non-consolidatable event
            if (!empty($consolidationBuffer)) {
                $consolidated = array_merge($consolidated, flushConsolidationBuffer($consolidationBuffer));
                $consolidationBuffer = [];
            }
            $consolidated[] = $event;
            continue;
        }
        
        // Extract pattern from event content
        $pattern = extractEventPattern($event);
        if ($pattern === null) {
            // Can't extract pattern, add as-is
            if (!empty($consolidationBuffer)) {
                $consolidated = array_merge($consolidated, flushConsolidationBuffer($consolidationBuffer));
                $consolidationBuffer = [];
            }
            $consolidated[] = $event;
            continue;
        }
        
        // Check if this event can be merged with buffer
        $merged = false;
        $actorName = extractActorName($event['content']);
        
        foreach ($consolidationBuffer as $key => &$buffered) {
            if ($buffered['pattern'] === $pattern) {
                // Check time window
                $timeDiff = abs(($event['gamets'] ?? 0) - ($buffered['first_gamets'] ?? 0));
                if ($timeDiff <= $timeWindow) {
                    // Check if this is a different actor doing the same action (e.g., combat engagement)
                    $isMultiActorPattern = (strpos($pattern, 'combat:') === 0 || strpos($pattern, 'activate:') === 0);
                    
                    if ($isMultiActorPattern && $actorName) {
                        // Multi-actor pattern: collect actor names
                        if (!isset($buffered['actors'])) {
                            $buffered['actors'] = [extractActorName($buffered['event']['content'])];
                        }
                        if (!in_array($actorName, $buffered['actors'])) {
                            $buffered['actors'][] = $actorName;
                        }
                    } elseif (strpos($pattern, 'itemfound:') === 0) {
                        // Item collection pattern: collect items
                        if (!isset($buffered['items'])) {
                            $buffered['items'] = [extractItemInfo($buffered['event']['content'])];
                        }
                        $buffered['items'][] = extractItemInfo($event['content']);
                    } else {
                        // Same actor repeating: increment count
                        $buffered['count']++;
                    }
                    
                    $buffered['last_gamets'] = $event['gamets'] ?? 0;
                    $merged = true;
                    break;
                }
            }
        }
        unset($buffered);
        
        if (!$merged) {
            // Flush older patterns and start new buffer entry
            $consolidationBuffer[] = [
                'event' => $event,
                'pattern' => $pattern,
                'count' => 1,
                'first_gamets' => $event['gamets'] ?? 0,
                'last_gamets' => $event['gamets'] ?? 0,
                'actors' => $actorName ? [$actorName] : null,
                'items' => (strpos($pattern, 'itemfound:') === 0) ? [extractItemInfo($event['content'])] : null
            ];
        }
    }
    
    // Flush remaining buffer
    if (!empty($consolidationBuffer)) {
        $consolidated = array_merge($consolidated, flushConsolidationBuffer($consolidationBuffer));
    }
    
    return $consolidated;
}

/**
 * Extract actor name from event content
 * 
 * @param string $content Event content
 * @return string|null Actor name or null if not extractable
 */
function extractActorName(string $content): ?string {
    // Extract actor from patterns like "ActorName does something"
    if (preg_match('/^([^:]+?)(?:\s+(?:engages combat with|activates|uses|casts|has defeated|found|took|looted|gave)\s+.+)$/i', $content, $matches)) {
        return trim($matches[1]);
    }
    return null;
}

/**
 * Extract item information from item pickup event
 * 
 * @param string $content Event content
 * @return string|null Item description with quantity
 */
function extractItemInfo(string $content): ?string {
    // Extract "N ItemName from/in X" or just "N ItemName"
    if (preg_match('/(?:found|took|looted|traded|gave)\s+(.+?)(?:,\(value.+\))?$/i', $content, $matches)) {
        $itemInfo = trim($matches[1]);
        
        // Extract just the item name (remove quantity) for blacklist check
        // Pattern: "2 Iron Sword" or "Iron Sword" or "an Iron Sword"
        if (preg_match('/^(?:\d+\s+|an?\s+)?(.+?)$/i', $itemInfo, $nameMatches)) {
            $itemName = trim($nameMatches[1]);
            
            // Check if item is blacklisted
            if (isItemBlacklisted($itemName)) {
                return null; // Filter out blacklisted items
            }
        }
        
        return $itemInfo;
    }
    return null;
}

/**
 * Extract consolidation pattern from event
 * 
 * @param array $event Event data
 * @return string|null Pattern identifier or null if not extractable
 */
function extractEventPattern(array $event): ?string {
    $content = $event['content'] ?? '';
    $type = $event['type'] ?? '';
    
    if ($type === 'death') {
        // Pattern: "X DIED" (just death announcement)
        if (preg_match('/^(.+?)\s+died\s*$/i', $content, $matches)) {
            $victim = trim($matches[1]);
            return "death_announce:{$victim}";
        }
        // Pattern: "X has defeated Y" or "X killed Y" etc
        // Extract: actor + victim
        if (preg_match('/^(.+?)\s+(?:has defeated|defeated|killed|slain)\s+(.+?)(?:\s+with\s+.+)?(?:\s+in an awesome move)?$/i', $content, $matches)) {
            $actor = trim($matches[1]);
            $victim = trim($matches[2]);
            return "death:{$actor}→{$victim}";
        }
    } elseif ($type === 'itemfound') {
        // Pattern: "X found/took/looted N Y" or "X found/took/looted Y"
        // Group by actor only for multi-item consolidation
        if (preg_match('/^(.+?)\s+(found|took|looted|traded|gave)\s+(.+)$/i', $content, $matches)) {
            $actor = trim($matches[1]);
            $action = trim($matches[2]);
            return "itemfound:{$actor}→{$action}"; // Only actor+action, group all items together
        }
    } elseif ($type === 'rpg_word') {
        // Generic combat shouts - consolidate identical ones
        return "rpg_word:" . md5($content);
    } elseif ($type === 'spellcast' || $type === 'npcspellcast') {
        // Pattern: "X casts Y" or "X uses Y"
        if (preg_match('/^(.+?)\s+(?:casts|uses)\s+(.+?)$/i', $content, $matches)) {
            $actor = trim($matches[1]);
            $spell = trim($matches[2]);
            return "spell:{$actor}→{$spell}";
        }
    } elseif ($type === 'infoaction') {
        // Pattern: "X engages combat with Y" - group by enemy only (multi-actor consolidation)
        if (preg_match('/^(.+?)\s+engages combat with\s+(.+?)$/i', $content, $matches)) {
            $enemy = trim($matches[2]);
            return "combat:{$enemy}"; // Only enemy in pattern, so multiple actors get grouped
        }
        // Pattern: "X activates Y" - group by object only (multi-actor consolidation)
        if (preg_match('/^(.+?)\s+activates\s+(.+?)$/i', $content, $matches)) {
            $object = trim($matches[2]);
            return "activate:{$object}"; // Only object in pattern
        }
    }
    
    return null;
}

/**
 * Flush consolidation buffer and format consolidated entries
 * 
 * @param array $buffer Consolidation buffer
 * @return array Formatted events
 */
function flushConsolidationBuffer(array $buffer): array {
    $result = [];
    
    foreach ($buffer as $buffered) {
        $event = $buffered['event'];
        
        // Check if this is an item event (single or multi) and filter blacklisted items
        if (isset($buffered['items'])) {
            // Filter out null entries (blacklisted items)
            $filteredItems = array_filter($buffered['items']);
            
            // If all items were filtered out, skip this event entirely
            if (empty($filteredItems)) {
                continue;
            }
            
            // Check if this is a multi-item consolidation
            if (count($filteredItems) > 1) {
                // Multiple items picked up by same actor - list them
                $content = $event['content'];
                
                if (preg_match('/^(.+?)\s+(found|took|looted|traded|gave)\s+/i', $content, $matches)) {
                    $actor = trim($matches[1]);
                    $action = trim($matches[2]);
                    
                    // Build item list from filtered items
                    $itemList = implode(', ', $filteredItems);
                    $event['content'] = "{$actor} {$action} {$itemList}";
                }
            }
            // Single item events will keep their original content (already filtered by extractItemInfo)
        } elseif (isset($buffered['actors']) && count($buffered['actors']) > 1) {
            // Multiple actors doing the same action - list them
            $actorList = implode(', ', $buffered['actors']);
            $content = $event['content'];
            
            // Replace single actor name with list and adjust verb to plural
            if (preg_match('/^(.+?)\s+(engages combat with|activates|uses|casts)\s+(.+?)$/i', $content, $matches)) {
                $action = trim($matches[2]);
                $target = trim($matches[3]);
                
                // Convert verb to plural form
                if (stripos($action, 'engages') !== false) {
                    $action = 'engage combat with';
                } elseif (stripos($action, 'activates') !== false) {
                    $action = 'activate';
                } elseif (stripos($action, 'uses') !== false) {
                    $action = 'use';
                } elseif (stripos($action, 'casts') !== false) {
                    $action = 'cast';
                }
                
                $event['content'] = "{$actorList} {$action} {$target}";
            }
        } elseif ($buffered['count'] > 1) {
            // Same event repeating - add count prefix for clarity (e.g., "2x SKEEVER DIED")
            $event['content'] = "{$buffered['count']}x " . trim($event['content']);
        }
        
        $result[] = $event;
    }
    
    return $result;
}

/**
 * Convert time difference in hours to a human-readable time category
 * 
 * @param float $hoursAgo Number of in-game hours since the event
 * @return string Human-readable time category
 */
function getTimeCategory($hoursAgo) {
    if ($hoursAgo < 0.02) return "Happened Recently";
    if ($hoursAgo < 0.1) return "Moments Ago";
    if ($hoursAgo < 0.25) return "A few minutes ago";
    if ($hoursAgo < 0.5) return "A while ago";
    if ($hoursAgo < 1.5) return "About an hour ago";
    if ($hoursAgo < 4) return "A couple of hours ago";
    if ($hoursAgo < 12) return "Earlier in the day";
    if ($hoursAgo < 36) return "A day ago";
    return "Days ago";
}


function buildHistoricContext($actor, $lastNelements = -10,$sqlfilter="") {

    global $db;

    if ($lastNelements == 0) { // if context_history is 0, all records will be retrieved
        $lastNelements = -1;
    }

    $nRecordsLimit = 32 + (2 * abs($lastNelements)); // reduce the default 1000 recs loaded from db to a number proportional to context_history 

    if (isset($GLOBALS["gameRequest"][2])) { 
        $currentGameTs=intval($GLOBALS["gameRequest"][2]);
    } else {
        $currentGameTs=intval(DataLastKnownGameTS());
    }

    if ($GLOBALS["gameRequest"][0]=="chatnf_book") {
        $removeBooks="";
    } else {
        $removeBooks ="and type<>'contentbook' " ;
    }
    
    $lastDialogFull = array();
    $actorEscaped=$db->escape($actor);
    $playerEscaped=$db->escape($GLOBALS["PLAYER_NAME"]);
    
    if (empty($actorEscaped))
        $actorEscaped="%";

    $query="select  
    case 
      when type='infoaction' and a.data like '#%MEMORY%' then 'MEMORY'
      when type like 'info%' or type like 'funcret%' or type like 'location%' then 'CONTEXTI'
      when a.data like '%background chat%' then 'BACKDIAG'
      when type='book' then 'BOOKEVT' 
      when type='quest' then 'QUEST' 
      when type='itemfound' then 'ITEM' 
      when type='rpg_word' then 'RPG_WORD' 
      when type='rpg_lvl' then 'RPG_LVL' 
      when type='rpg_shout' then 'RPG_SHOUT' 
      when type='death' then 'RPG_DEATH' 
      when type='welcome' then 'RPG_SPAWN' 
      when type='bleedout' then 'RPG_DEFEAT' 
      when type='waitstart' then 'CONTEXTI' 
      when type='waitstop' then 'CONTEXTI' 
      when type='spellcast' then 'CONTEXTI' 
      when type='npcspellcast' then 'CONTEXTI' 
      when type='reanimate' then 'CONTEXTI' 
      when type='info_timeforward' then 'TIMELAPSE' 
      when type='backgroundaction' then 'CONTEXTI' 
      when type='innerchat' then 'BGLCHAT' 
      when type like 'ext_%' then 'PLUGIN'
      else '' 
    end as subtype,a.data  as data , gamets,localts,type,location
    FROM  eventlog a WHERE 1=1
    and type<>'combatend'  
    and type<>'bored' and type<>'init' and type<>'infoloc' and type<>'info' and type<>'funcret' and type<>'book' and type<>'addnpc' and type<>'infonpc' and type<>'infoitems'  
    and type<>'updateprofile' and type<>'rechat' and type<>'setconf' and  type<>'status_msg'  and type<>'user_input'  and type<>'infonpc_close' and type<>'instruction'
    and type<>'request' and type<>'playerinfo' and type<>'im_alive' and type<>'region' and type<>'named_cell' and type<>'narrator_inputtext'
    ".(($actorEscaped)?" 
    and (
     people like '%|$actorEscaped|%' 
     or people like '$actorEscaped' 
     or people like '%|$actorEscaped (busy)|%'
     OR people LIKE '%|$actorEscaped (hostile)|%' 
     or type='info_timeforward' )
    ":"")." 
    and type<>'funccall' $removeBooks  and type<>'togglemodel' $sqlfilter  ".
    ((false)?" and gamets>".($currentGameTs-(60*60*60*60)):"").
    " order by gamets desc, ts desc, rowid desc LIMIT $nRecordsLimit OFFSET 0";  
    
    // OR people LIKE '%|$actorEscaped (far away)|%') this can be confusing in whisper mode
    $results = $db->fetchAll($query);

    // Filter blacklisted event types
    if (isset($GLOBALS["EVENT_TYPE_FILTER"]) && !empty($GLOBALS["EVENT_TYPE_FILTER"])) {
        $blacklistedEventTypes = array_map('trim', explode(',', strtolower($GLOBALS["EVENT_TYPE_FILTER"])));
        $results = array_filter($results, function($row) use ($blacklistedEventTypes) {
            $eventType = strtolower($row["type"] ?? '');
            foreach ($blacklistedEventTypes as $blacklistedType) {
                if (!empty($blacklistedType) && $eventType === $blacklistedType) {
                    return false;
                }
            }
            return true;
        });
    }

    //error_log($query);
    $rawData=[];
    foreach ($results as $row) {
        $rawData[md5($row["data"].$row["localts"])] = $row;
    }

    
    $orderedData = array_reverse($rawData);

    //$orderedData = array_slice($orderedData, $lastNelements);

    
    $currentLocation = "";
    $writeLocation = true;

    $lastSpeaker = "";
    $buffer = [];
    $timeStampBuffer = [];

    $beingsPresent=null;
    $lastlocation="";
    $lastGameTs=0;
    $memoryLogToRemove=[];
    
    $lastTimeCategory = null; // Track last timestamp category for PROMPT_TIMESTAMP feature

    $focusOnChat=($GLOBALS["CLEAN_CONTEXT_FOCUS_CHAT"] ?? false);


    foreach ($orderedData as $n=>$row) {
        $rowData = $row["data"];
        
        if ($rowData==="The Narrator:") // Hunt empty rows
            continue;
        
        // Remove Context location from data
        $pattern = '/\s*\(Context location: .*?\)/';
        if ($rowData)
            $rowData = preg_replace($pattern, "", $rowData); 

        // Figure out location form location field, and only add to context if changed    
        $printLocation=false;
        $string = $row["location"];
        if (!empty($string)) {
            preg_match('/Context\s*(?:new\s*)?location:\s*([^,]+?)(?:,|$)/u', $string, $locationMatch);
            preg_match('/Hold:\s*([^,\)]+?)(?:,|\)|$)/u', $string, $holdMatch);
        }
        
        if (!isset($holdMatch[1])) {
            //error_log(print_r($string,true));
            $locationFinal=$lastlocation;
        } else {
            $hold = trim($holdMatch[1]);
            $location = trim($locationMatch[1]);
            $locationFinal="$location, hold: $hold";
        }
        
        if ($lastlocation!=$locationFinal) {
            $lastlocation=$locationFinal;
            if ($row["type"]!="location")
                $printLocation=true;
            $currentLocation=$lastlocation;
        }
        
        // Special case, logaction is the return data of an action call.
        if ($row["type"]=="logaction") {
            $logactionData=json_decode($rowData,true);
            if (is_array($logactionData)) {
                if ($logactionData["character"]!=$GLOBALS["HERIKA_NAME"])
                    continue;
            }
        }
        
        // Skip empty rows
        if (!$rowData)
            $rowData="";
        

        // Figure out real speaker
        if (($row["type"]=="logaction") && (strpos($rowData, "{$GLOBALS["HERIKA_NAME"]}") !== false))  {
            $speaker = "assistant";
            
        } else if ($row["type"]=="vision") {
            $speaker = "user";
            
        } else if ($row["subtype"]=="MEMORY") {
            $speaker = "memory";
            
        } else if ((strpos($rowData, "{$GLOBALS["HERIKA_NAME"]}:") !== false) && (strpos($rowData, "The Narrator:") === false)) {
            $speaker = "assistant";
            
        } else if ((strpos($rowData, "{$GLOBALS["PLAYER_NAME"]}:") === 0)) {
            $speaker = "player";
            
        } else if ((strpos($rowData, "The Narrator:") === 0) && $row["type"]=="chat") {
            $speaker = "narratorchat";
            
        } else if ($row["subtype"]=="BACKDIAG") {
            if ($focusOnChat)
                continue;
            $speaker = "backgroundchat";
            
        } else if ($row["subtype"]=="BGLCHAT") {
            $speaker = "backgroundchat";
            
        } else if ($row["subtype"]=="BOOKEVT") {
            if ($focusOnChat)
                continue;
            $speaker = "narratorci";
            
        } else if ($row["subtype"]=="CONTEXTI") {
            if (strpos($rowData,"should not be visible")!==false)
                continue;
            if ($focusOnChat) {
                if (strpos($rowData," uses ")!==false) 
                    continue;
                if (strpos($rowData," casts ")!==false) 
                    continue;
                if (strpos($rowData," engages combat ")!==false) 
                    continue;
                if (strpos($rowData," has defeated ")!==false) 
                    continue;
                if (strpos($rowData," activates ")!==false) 
                    continue;
            }
            
         
            $speaker = "narratorci";
            
        } else if ($row["subtype"]=="QUEST") {
            if ($focusOnChat)
                continue;
            $speaker = "narratorci";
            
        } else if ($row["subtype"]=="ITEM") {
            if ($focusOnChat) {
                if (strpos($rowData,"{$GLOBALS["HERIKA_NAME"]}")===false) // This NPC's item transactions conserved
                    continue;
            }
            $speaker = "narratorci";
            
        } else if ($row["subtype"]=="RPG_WORD") {
            if ($focusOnChat)
                continue;
            $speaker = "narratorci";
            
        } else if ($row["subtype"]=="RPG_LVL") {
            if ($focusOnChat)
                continue;
            $speaker = "narratorci";
            
        } else if ($row["subtype"]=="RPG_SPAWN") {
            if ($focusOnChat)
                continue;
            $speaker = "narratorci";
            
        } else if ($row["subtype"]=="RPG_SHOUT") {
            if ($focusOnChat)
                continue;
            $speaker = "narratorci";
            
        } else if ($row["subtype"]=="RPG_DEATH") {
            if ($focusOnChat)
                continue;
            $speaker = "narratorci";
            $rowData = strtoupper($rowData);
            
        } else if ($row["subtype"]=="RPG_DEFEAT") {
            if ($focusOnChat)
                continue;
            $speaker = "narratorci";
            $rowData = strtoupper($rowData);
            
        } else if ($row["subtype"]=="TIMELAPSE") {
            $rowData = strtoupper($rowData);
            
        }  else if ($row["subtype"]=="PLUGIN") {
            $speaker = $row["type"];
            
        } else {
            
            $speaker = "npc";
            
        }

        // Compact info_timeforward events
        if ($row["type"] == "info_timeforward") {
            if (isset($previousRow) && $previousRow["type"] == "info_timeforward") {
                // Extract hours passed from the current row and the current date/time portion
                preg_match('/([\d.]+)\s*hours have passed\.?/i', $row["data"], $currentMatch);
                $currentHours = isset($currentMatch[1]) ? (float)$currentMatch[1] : 0;
                preg_match('/(Current date\/time: .+)$/i', $row["data"], $currentDateMatch);
                $currentDateTime = isset($currentDateMatch[1]) ? trim($currentDateMatch[1]) : '';

                // Extract hours passed from the previous row (if present)
                preg_match('/([\d.]+)\s*hours have passed\.?/i', $previousRow["content"], $previousMatch);
                $previousHours = isset($previousMatch[1]) ? (float)$previousMatch[1] : 0;

                // Sum the hours
                $totalHours = $currentHours + $previousHours;

                // error_log("[TIMEFORWARD] $totalHours = $currentHours + $previousHours ");

                // Build a normalized single-line content: "<hours> hours have passed. Current date/time: ..."
                if ($currentDateTime !== '') {
                    $previousRow["content"] = "{$totalHours} hours have passed. {$currentDateTime}";
                } else {
                    // Fallback: use the trimmed current row data if date/time portion wasn't found
                    $previousRow["content"] = "{$totalHours} hours have passed. " . trim($row["data"]);
                }

                continue; // Skip adding this row to the context
            } else {
                $row["role"]="narratorci";
                $row["content"]=trim($rowData);
                $row["gamets"]=$lastGameTs;// gamets will be previous record gamets

                $previousRow=$row;
                continue; // Skip adding this row to the context
            }
        } else if (isset($previousRow) && $previousRow["type"] == "info_timeforward") {
            $lastDialogFull[]=$previousRow;
            unset($previousRow);
        }

        //if (($GLOBALS["FEATURES"]["MISC"]["ADD_TIME_MARKS"])&&(true) && $row["type"] != "info_timeforward") {
        if ($row["type"] != "info_timeforward") {
    
            
            if ($lastGameTs==0)
                $lastGameTs=$row["gamets"];
            else {
                $timeGapInHours=round(($row["gamets"]-$lastGameTs) * 0.0000024, 0);
                
                if ($timeGapInHours>36) {
                    $timeGapInDays=round($timeGapInHours/24,1);
                    $lastDialogFull[] = array('role' => "narratorci", 'content' => "!!! IMPORTANT CONTEXT !!!
A MAJOR TIME JUMP HAS OCCURRED.
Elapsed time since last interaction: ~$timeGapInDays days
New setting: $currentLocation
!!! END CONTEXT !!! ");
                } else if ($timeGapInHours>5) {
                    $timeGapInDays=round($timeGapInHours/24,1);
                    $lastDialogFull[] = array('role' => "narratorci", 'content' => "(minor timelapse of about $timeGapInHours hours)");
                }
                $lastGameTs=$row["gamets"];
            }

            if ($printLocation ) {
                $hoursAgo=round(($currentGameTs-$row["gamets"]) * 0.0000024, 0);
                if (!isset($timeStampBuffer[$hoursAgo])) {
                    if ($currentLocation) {
                        if (DataLastKnownLocationHuman(false,true)==$currentLocation)   // Enforce current location.
                            $lastDialogFull[] = array('role' => "narratorci", 'content' => "LOCATION CHANGE, THIS IS THE CURRENT LOCATION: $currentLocation");
                        
                        else
                            $lastDialogFull[] = array('role' => "narratorci", 'content' => "LOCATION CHANGE to $currentLocation, timeline mark: $hoursAgo hours ago  ");
                    }
                }
            } else {
               

            }
        }

        $lastSpeaker = $speaker;
        
        // Insert timestamp subdividers if PROMPT_TIMESTAMP is enabled
        if (!empty($GLOBALS["PROMPT_TIMESTAMP"]) && $row["type"] != "info_timeforward") {
            $hoursAgo = ($currentGameTs - $row["gamets"]) * 0.0000024;
            $currentTimeCategory = getTimeCategory($hoursAgo);
            
            // If category changed, insert a subdivider
            if ($lastTimeCategory !== null && $currentTimeCategory !== $lastTimeCategory) {
                $lastDialogFull[] = array('role' => "narratorci", 'content' => "--- {$currentTimeCategory} ---");
            }
            
            $lastTimeCategory = $currentTimeCategory;
        }
        
        $row= array('role' => $lastSpeaker, 'content' => trim($rowData),'subtype'=>$row["subtype"]?:strtoupper($lastSpeaker),'type'=>$row["type"]);
        $lastDialogFull[] = $row;
        $previousRow=$row;

    }

    if (isset($previousRow)) {
        if (sizeof($previousRow)>0) {
            if (sizeof($lastDialogFull) === 0 || $previousRow !== end($lastDialogFull)) {
                $lastDialogFull[]=$previousRow;
            }
            
        }
    }

    file_put_contents(__DIR__."/../log/context_for_{$actor}_stage_1_.txt",print_r($lastDialogFull,true));

    // Remove memory logs, only leave last one.
    $lastDialogFullOnlyLastMemory=[];
    $localFlag=0;
    foreach (array_reverse($lastDialogFull) as $element) {
        if ($element["role"]=="memory") {
            if ($localFlag==0) {
                $element["role"]="narratorci";
                $lastDialogFullOnlyLastMemory[]=$element;
                $localFlag++;
            } else {
                $localFlag++;
            }
        } else {
            $lastDialogFullOnlyLastMemory[]=$element;
        }
    }

    error_log("[buildHistoricContext] $localFlag memories removed");
    $lastDialogFull=array_reverse($lastDialogFullOnlyLastMemory);
    // End of memory logs cleaning
    
    // Consolidate repeated events to reduce context size
    $eventCountBefore = count($lastDialogFull);
    $lastDialogFull = consolidateEvents($lastDialogFull);
    $eventCountAfter = count($lastDialogFull);
    if ($eventCountBefore > $eventCountAfter) {
        error_log("[buildHistoricContext] Consolidated events: {$eventCountBefore} → {$eventCountAfter} (saved " . ($eventCountBefore - $eventCountAfter) . " slots)");
    }

    // Filter ambient combat deaths if configured
    if (!empty($GLOBALS["HIDE_AMBIENT_COMBAT"])) {
        $beforeFilter = count($lastDialogFull);
        $lastDialogFull = array_values(array_filter($lastDialogFull, function($event) {
            // Keep non-death events
            if (!isset($event['type']) || $event['type'] !== 'death') {
                return true;
            }
            
            // Keep death events that don't contain "has killed" (i.e., keep "has defeated")
            $content = $event['content'] ?? '';
            if (stripos($content, 'has killed') !== false) {
                return false; // Filter out ambient combat
            }
            
            return true; // Keep significant combat events
        }));
        $afterFilter = count($lastDialogFull);
        if ($beforeFilter > $afterFilter) {
            error_log("[buildHistoricContext] Filtered ambient combat: {$beforeFilter} → {$afterFilter} (removed " . ($beforeFilter - $afterFilter) . " events)");
        }
    }

    file_put_contents(__DIR__."/../log/context_for_{$actor}_stage_1_.txt",print_r($query,true),FILE_APPEND);
    
    return $lastDialogFull;

}

function compactHistoricContext($lastDialogFull,$actor,$compactContextInfo=false) {

    $lastrole="";
    $bufferHerika=[];
    $lastDialogFullCopy=[];
    $compactedBuffer = "";
 
    foreach ($lastDialogFull as $n => $line) {
        if (($line["role"] == "assistant")) {
            $isJson=json_decode($line["content"],true);
            if (is_array($isJson)) {
                $lastDialogFullCopy[]=$line;
                continue;
            }
            $cleanedText=$line["content"];
           
            $bufferHerika[]=$cleanedText;

            
        } else {
            if ($lastrole=="assistant") {
                // This breaks with spaces?
                $compactedBuffer="";
                foreach ($bufferHerika as $m=>$singleline) {
                    $compactedBuffer .=" ";
                    if ($m>0) {
                        //$regexpNpcName = strtr($GLOBALS["HERIKA_NAME"],["-"=>'\-', "["=>"\[", "]"=>"\]"]);
                        // Capture spoken text after a leading "Name:" (supports names with brackets and dashes)
                        // and optionally strip a trailing parenthetical note like "(talking to X)".
                        preg_match('/^\s*[^:]+:\s*(.*?)\s*(?:\([^)]*\))?\s*$/s', $singleline, $matches);
                        $extracted=$matches[1] ?? $singleline;
                        $compactedBuffer .= trim(removeTalkingToOccurrences($extracted));
                        $compactedBuffer=str_replace("{$GLOBALS["HERIKA_NAME"]};","",$compactedBuffer);

                    } else {
                        $compactedBuffer .= trim(removeTalkingToOccurrences($singleline));
                        $compactedBuffer=str_replace("{$GLOBALS["HERIKA_NAME"]}:","",$compactedBuffer);
                    }


                }
                $lastDialogFullCopy[] = ["role"=>"assistant","content"=>trim($compactedBuffer)];

            }
            $bufferHerika=[];
            $compactedBuffer="";
            $lastDialogFullCopy[]=$line;
        } 

        
        
        $lastrole=$line["role"];
    }

    // Last entry
    if (sizeof($bufferHerika)>0) {
        foreach ($bufferHerika as $m=>$singleline) {
            $compactedBuffer .=" ";
            if ($m>0) {
                //$regexpNpcName = strtr($GLOBALS["HERIKA_NAME"],["-"=>'\-', "["=>"\[", "]"=>"\]"]);
                // Same robust extraction for subsequent lines in the buffer
                preg_match('/^\s*[^:]+:\s*(.*?)\s*(?:\([^)]*\))?\s*$/s', $singleline, $matches);
                $extracted=$matches[1] ?? $singleline;
                $compactedBuffer .= trim(removeTalkingToOccurrences($extracted));
                $compactedBuffer=str_replace("{$GLOBALS["HERIKA_NAME"]};","",$compactedBuffer);

            } else {
                $compactedBuffer .= trim(removeTalkingToOccurrences($singleline));
                $compactedBuffer=str_replace("{$GLOBALS["HERIKA_NAME"]};","",$compactedBuffer);
            }



        }
        $lastDialogFullCopy[] = ["role"=>"assistant","content"=>trim($compactedBuffer)];
        $bufferHerika=[];
    }

    // file_put_contents(__DIR__."/../log/context_for_{$actor}_stage_1_5_.txt",print_r($lastDialogFullCopy,true));

    
    // Compact other info
    $lastSpeaker = "";
    $buffer = [];
    $lastDialogFull=[];


    foreach ($lastDialogFullCopy as $n => $line) {
        $speaker=$line["role"];
        
        if ($speaker=="npc") { // Tricky, npc could be any char
            preg_match('/^([^:]+):/', $line["content"], $matches);
            // Output the extracted name
            $speakerNPC=$matches[1] ?? "";
            $speaker="npc_$speakerNPC";
        }
        

        if ($lastSpeaker == $speaker) {
            // Same speaker as last iteration, remove extra text
            if (strpos($speaker,"npc") === 0 || $speaker == "narratorchat") {
                $matches = [];
                
                // Clean talking to and npc name , only leave it on first line
                $matches = [];
                // And for compacting other dialog lines: capture content after the speaker name
                preg_match('/^\s*[^:]+:\s*(.*?)\s*(?:\([^)]*\))?\s*$/s', $line["content"], $matches);
                $buffer[]=$matches[1] ?? $line["content"];
            } else {

                if (!$compactContextInfo) {
                    $lastDialogFull[]=array('role' => $lastSpeaker, 'content' => trim(isset($buffer[0])?$buffer[0]:$line["content"]));
                    if (isset($buffer[0])) {
                        $buffer = [];
                        $buffer[] = $line["content"];
                    } else
                        $buffer = [];
                } else {
                    $buffer[] = strtr($line["content"],["The Narrator:"=>"","{$GLOBALS["HERIKA_NAME"]}:"=>""]);
                }
                
            }
        } else {

            if (sizeof($buffer) > 0) {
                if ($lastSpeaker=="narratorci" || $lastSpeaker=="narratorloc") {
                    if (!$compactContextInfo) {
                        $lastDialogFull[] = array('role' => $lastSpeaker, 'content' => "".implode(" ", removeEmptyElements($buffer)));  // Should be only one line
                    } else {
                        $lastDialogFull[] = array('role' => $lastSpeaker, 'content' => "* ".implode("\n* ", removeEmptyElements($buffer))); 
                    }

                }
                else if ($lastSpeaker=="backgroundchat")
                    $lastDialogFull[] = array('role' => $lastSpeaker, 'content' => implode("\n", removeEmptyElements($buffer)));
                else 
                    $lastDialogFull[] = array('role' => $lastSpeaker, 'content' => implode(" ", removeEmptyElements($buffer)));
            }
            $buffer = [];
            $buffer[] = $line["content"];
            $lastSpeaker = $speaker;

            if ($speaker=="assistant") {    //Leave as is
                $lastDialogFull[] = $line;
                $lastSpeaker = "";
                $buffer = [];
                continue;
            }
        }

    }

    // Clean empty entries
    $bufferCopy=[];
    foreach ($buffer as $n=>$bufferEntry) {
        if (!empty(trim($bufferEntry)))
            $bufferCopy[]=$bufferEntry;

    }

    // Last buffer, probably user input.
    if (sizeof($bufferCopy)) {
        if ($lastSpeaker=="narratorci" || $lastSpeaker=="narratorloc") 
            $lastDialogFull[] = array('role' => $lastSpeaker, 'content' => implode("\n* ", $bufferCopy));
        else if ($lastSpeaker=="backgroundchat")
            $lastDialogFull[] = array('role' => $lastSpeaker, 'content' => implode("\n", $bufferCopy));
        else 
            $lastDialogFull[] = array('role' => $lastSpeaker, 'content' => implode(" ", $bufferCopy));
    }

    $contextDataHistory=[];
    foreach ($lastDialogFull as $n=>$lastDialogFullEntry) {
        if (!empty(trim($lastDialogFullEntry["content"])))
                $contextDataHistory[]=$lastDialogFullEntry;

    }

    file_put_contents(__DIR__."/../log/context_for_{$actor}_stage_2_.txt",print_r($contextDataHistory,true));
    return $contextDataHistory;
}

function replaceRoles($lastDialogFull,$actor,$lastNelements) {

     // Replace roles for user.
     foreach ($lastDialogFull as $n => $line) {
        if ($line["role"] == "player") {
            $lastDialogFull[$n]["role"] = "user";
        } else if (strpos($line["role"],"npc")===0) {
        
            $lastDialogFull[$n]["role"] = "user";
        
        } else if ($line["role"] == "backgroundchat") {
        
            $lastDialogFull[$n]["role"] = "user";
            if (strlen(trim($lastDialogFull[$n]["content"])) > 0) {
                $lastDialogFull[$n]["content"] = " (... ".PHP_EOL.$lastDialogFull[$n]["content"]."\n...)";
            }
            
        } else if ($line["role"] == "narratorci") {
        
            $lastDialogFull[$n]["role"] = "user";
            $lastDialogFull[$n]["content"] = $lastDialogFull[$n]["content"]."\n";
        
        } else if ($line["role"] == "narratorchat") {

            $lastDialogFull[$n]["role"] = "user";

        } else if ($line["role"] == "narratorloc") {

            $lastDialogFull[$n]["role"] = "user";

        }
    }

    // Date issues

    foreach ($lastDialogFull as $n => $line) {

        $pattern = '/(\w+), (\d{1,2}:\d{2} (?:AM|PM)), (\d{1,2})(?:st|nd|rd|th) of ([A-Za-z\'\ ]+), 4E (\d+)/'; //extract also for months with aphostrophe like Sun's Something
        $replacement = 'Day name: $1, Hour: $2, Day Number: $3, Month: $4, 4th Era, Year: $5';
        $result = preg_replace($pattern, $replacement, $line["content"]);
        $lastDialogFull[$n]["content"] = $result;
    }



    error_log("[CHIM] Using effective context limit of : $lastNelements");
    $orderedData = array_slice($lastDialogFull, $lastNelements);

    file_put_contents(__DIR__."/../log/context_for_$actor.txt",print_r($orderedData,true));
    $GLOBALS["CONTEXT_BUILDING_DATA"]=$orderedData;
    requireFilesRecursively(__DIR__."/../ext/","context_building.php");

    file_put_contents(__DIR__."/../log/context_for_{$actor}_ext.txt",print_r($GLOBALS["CONTEXT_BUILDING_DATA"],true));

    return $GLOBALS["CONTEXT_BUILDING_DATA"];

}

function DataLastDataExpandedFor($actor, $lastNelements = -10,$sqlfilter="")
{

    $localStartTime=microtime(true);

    $ctx1=buildHistoricContext($actor, $lastNelements ,$sqlfilter);    
    //error_log("[buildHistoricContext] Elapsed time: " . (microtime(true) - $localStartTime) . " seconds");


    $ctx2=compactHistoricContext($ctx1,$actor,false);  // Don't compact Context Info

    //error_log("[compactHistoricContext] Elapsed time: " . (microtime(true) - $localStartTime) . " seconds");

    $ctx3=replaceRoles($ctx2,$actor,$lastNelements);
      
    //error_log("[replaceRoles] Elapsed time: " . (microtime(true) - $localStartTime) . " seconds");

    // Cases of self rechat
    if ((sizeof($ctx3)>3)&&(($GLOBALS["gameRequest"][3] ?? "")=="rechat")) {
        $lastElement = $ctx3[sizeof($ctx3)-1];
        // Last element is assistant
        if ($lastElement["role"]=="assistant") {
            if ($GLOBALS["gameRequest"][3]=="rechat") {
                // NPC is rechatting himself
                
                Logger::warn("[RECHAT] actor is replying itself, case 1, aborting");

                echo 'X-CUSTOM-CLOSE'.PHP_EOL;
                if (!getenv("PHPUNIT_TEST")) {
                    @ob_end_flush();
                    @flush();
                }
            }

        }

        $preLastElement = $ctx3[sizeof($ctx3)-2];
        // Pre last element is assistant, and last is a memory.
        if (($preLastElement["role"]=="assistant")&&(strpos($lastElement["content"],"MEMORY")!==false)) {
            if ($GLOBALS["gameRequest"][3]=="rechat") {
                // NPC is rechatting himself
                
                Logger::warn("[RECHAT] actor is replying itself,case 2, aborting");

                echo 'X-CUSTOM-CLOSE'.PHP_EOL;
                if (!getenv("PHPUNIT_TEST")) {
                    @ob_end_flush();
                    @flush();
                }
            }

        }
    }

    //error_log("[DataLastDataExpandedFor end] Elapsed time: " . (microtime(true) - $localStartTime) . " seconds");

    return $ctx3;

}

function DataLastDataExpandedForBak($actor, $lastNelements = -10,$sqlfilter="")
{

    global $db;

    $currentGameTs=$GLOBALS["gameRequest"][2]+0;
    if ($GLOBALS["gameRequest"][0]=="chatnf_book") {
        $removeBooks="";
    } else {
        $removeBooks ="and type<>'contentbook' " ;
    }
    
    $lastDialogFull = array();
    
    $results = $db->fetchAll("select  
    case 
    when type like 'info%' or type like 'death%' or  type like 'funcret%' or type like 'location%'  then 'The Narrator:'
    when a.data like '%background chat%' then 'The Narrator: background dialogue: '
    when type='book' then 'The Narrator: ({$GLOBALS["PLAYER_NAME"]} took the book ' 
    else '' 
    end||a.data  as data , gamets,localts,type
    FROM  eventlog a WHERE 1=1
    and type<>'combatend'  
    and type<>'bored' and type<>'init' and type<>'infoloc' and type<>'info' and type<>'funcret' and type<>'book' and type<>'addnpc' and type<>'infoitems' 
    and type<>'updateprofile' and type<>'rechat' and type<>'narration' and type<>'setconf' and type<>'backgroundaction'
    and type<>'funccall' $removeBooks  and type<>'togglemodel' $sqlfilter  
    and gamets>".($currentGameTs-(60*60*60*60))."
    order by gamets desc,ts desc,rowid desc LIMIT 1000 OFFSET 0");
    

    
 
    $rawData=[];
    foreach ($results as $row) {
        $rawData[md5($row["data"].$row["localts"])] = $row;
    }

    
    $orderedData = array_reverse($rawData);

    
    //$orderedData = array_slice($orderedData, $lastNelements);

    $currentLocation = "";
    $writeLocation = true;

    $currentSpeaker = "user";
    $buffer = [];
    $timeStampBuffer = [];

    $beingsPresent=null;
    
    foreach ($orderedData as $row) {
        $rowData = $row["data"];
        // Extract location
        $pattern = '/\(Context location: (.*?),(.*?)\)/';

        if (preg_match($pattern, str_replace(" background dialogue", "", $rowData), $matches)) {

            $contextLocation = $matches[0];
            if ($currentLocation != $contextLocation) {
                $currentLocation = $contextLocation;
                $writeLocation = true;
            } else {
                $writeLocation = false;
            }

        } else {

        }

        if (!$writeLocation) {
            $pattern = "/\([^)]*Context location[^)]*?\)/";
            $rowData = preg_replace($pattern, "", $rowData); // Remove context location if repeated
        }

        
        // This is used for compacting.
        
        if (($row["type"]=="logaction") && (strpos($rowData, "{$GLOBALS["HERIKA_NAME"]}") !== false))  {
            $speaker = "assistant";
            
        } else if ($row["type"]=="vision") {
            $speaker = "user";
            
        } else if ((strpos($rowData, "{$GLOBALS["HERIKA_NAME"]}:") !== false)) {
            $speaker = "assistant";
            
        } 
         else if ((strpos($rowData, "{$GLOBALS["PLAYER_NAME"]}:") !== false)) {
            $speaker = "player";
            
        } else {
            $speaker = "user";
            
        }
        
        if (!empty($actor)) {
            if ( $row["type"]=="infonpc") {
                $beingsPresent=$rowData;
                continue;
            }
            if (empty($beingsPresent)) {
                continue;
            }
         
            if (strpos($beingsPresent,$actor)===false) {
                continue;
            }
        } else {
            if ( $row["type"]=="infonpc")   
                continue;
        }



        if (($currentSpeaker == $speaker) && ($speaker == "assistant") && $row["type"]!="logaction") {
            $buffer[] = $rowData;
        } else {
            if (sizeof($buffer) > 0) {
                $lastDialogFull[] = array('role' => $currentSpeaker, 'content' => implode("\n", $buffer));
            }
            $buffer = [];
            $buffer[] = $rowData;
            $currentSpeaker = $speaker;
        }

        if ($GLOBALS["FEATURES"]["MISC"]["ADD_TIME_MARKS"]) {
            $hoursAgo=round(($currentGameTs-$row["gamets"]) * 0.0000024, 0);
            if ($hoursAgo>12) {
                if (!isset($timeStampBuffer[$hoursAgo])) {
                    if ($currentLocation) {
                        $timeStampBuffer[$hoursAgo]="set";
                        $lastDialogFull[] = array('role' => "user", 'content' => "The Narrator: SCENARIO CHANGE, $currentLocation, timeline mark: $hoursAgo hours ago  ");
                    }
                }
            }
        }

    }

 
    // if (($currentGameTs-$row["gamets"])>600) {


    //}

       
    print_r($lastDialogFull);
    die();
    
    $lastDialogFull[] = array('role' => $currentSpeaker, 'content' => implode("\n", $buffer));

    // Compact Herika's lines
    foreach ($lastDialogFull as $n => $line) {
        if ($line["role"] == "assistant") {
            $pattern = "/\(Context location:[^)]+?\)/";
            $cleanedText = trim(preg_replace($pattern, "", $line["content"])); // Remove context location always for assistant
            // This breaks with spaces?
            $re = '/[^(' . strtr($GLOBALS["HERIKA_NAME"],["-"=>'\-']) . ':)].*(' . strtr($GLOBALS["HERIKA_NAME"],["-"=>'\-']) . ':)/m';
            $subst = "";
            $cleanedText = preg_replace($re, $subst, $cleanedText);
            
            
            $cleanedText = removeTalkingToOccurrences($cleanedText);
            
            $lastDialogFull[$n]["content"] = $cleanedText;
        }

    }

    // Replace player for user.
    foreach ($lastDialogFull as $n => $line) {
        if ($line["role"] == "player") {
            $lastDialogFull[$n]["role"] = "user";
        }
    }

    // Date issues

    foreach ($lastDialogFull as $n => $line) {

        $pattern = '/(\w+), (\d{1,2}:\d{2} (?:AM|PM)), (\d{1,2})(?:st|nd|rd|th) of ([A-Za-z\'\ ]+), 4E (\d+)/'; //extract also for months with aphostrophe like Sun's Something
        $replacement = 'Day name: $1, Hour: $2, Day Number: $3, Month: $4, 4th Era, Year: $5';
        $result = preg_replace($pattern, $replacement, $line["content"]);
        $lastDialogFull[$n]["content"] = $result;
    }


    $orderedData = array_slice($lastDialogFull, $lastNelements);

   
    return $orderedData;

}

function DataSpeechJournal($topic,$limit=50) 
{

    global $db;

    $lastDialogFull = [];
    $tn=$db->escape($topic);
    $results = $db->fetchAll("SElECT  speaker,speech,location,listener,topic as quest, convert_gamets2skyrim_date(gamets) AS sk_date, gamets FROM speech
      where (speaker like '%$tn%' or  listener like '%$tn%' or location like '%$tn%' or  
      companions like '%|$tn|%' or  companions like '%$tn%' OR companions LIKE '%|$tn (busy)|%' 
      OR companions LIKE '%|$tn (hostile)|%' ) 
      and listener<>'unknown' 
      order by rowid desc");
    if (!$results) {
        return json_encode([]);
    }

    $data = [];

    foreach ($results as $row) {
        $data[] = $row;
    }

    if (sizeof($data) == 0) {
        return json_encode([]);
    } elseif (sizeof($data) < $limit) {
        $dataReversed = array_reverse($data);
    } else {
        $smalldata = array_slice($data, 0,$limit);
        $dataReversed = array_reverse($smalldata);
    }


    return json_encode($dataReversed);

}

/*
 * Diary functions are attached to FTS queries, Should be driver agnostic. work on this
 * */
function DataDiaryLog($topic)
{

    global $db;
    /*
    $results = $db->query("SElECT  topic,content,tags,people  FROM diarylog
    where (tags like '%$topic%' or topic like '%$topic%' or people like '%$topic%') order by gamets asc");
    */
    $topicTok = explode(" ", strtr($topic, array("'" => "")));
    $topicFmt = implode(" OR ", $topicTok);
    $results = $db->fetchAll(SQLite3::escapeString("SElECT  topic as page,content,tags,people  FROM diarylogv2
      where (tags MATCH \"$topicFmt\" or topic MATCH \"$topicFmt\" or content MATCH \"$topicFmt\" or people MATCH \"$topicFmt\") ORDER BY rank"));


    if (!$results) { // No match, will return a list of current memories
        $results = $db->fetchAll(SQLite3::escapeString("SElECT  topic as page,tags  FROM diarylogv2 order by rowid asc"));

        if (!$results) {
            return json_encode([]);
        }

        $data = [];

        foreach ($results as $row) {
            $data[] = $row;
        }

        return json_encode(["return value" => "Page not found", "similar pages" => $data]);


    } else { // Return best matching memory

        file_put_contents(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR . "data". DIRECTORY_SEPARATOR ."logquery.txt", SQLite3::escapeString("\nSElECT  topic,content,tags,people  FROM diarylogv2
        where (tags MATCH \"$topicFmt\" or topic MATCH \"$topicFmt\" or content MATCH \"$topicFmt\" or people MATCH \"$topicFmt\") ORDER BY rank"), FILE_APPEND);

        $data = [];
        foreach ($results as $row) {
            $data[] = $row;
            break; // Only space for one memory
        }

    }

    if (sizeof($data) == 0) { // No match, will return a list of current memories. Revise limits

        $results = $db->fetchAll(SQLite3::escapeString("SElECT  topic as page  FROM diarylogv2 order by rowid asc"));

        $data = [];

        foreach ($results as $row) {
            $data[] = $row;
        }

        return json_encode(["return value" => "Page not found", "available pages" => $data]);
    }

    return json_encode($data);


}


function DataDiaryLogIndex($topic)
{

    global $db;
    //$results = $db->query('SElECT  topic,tags  FROM diarylogv2 where tags  MATCH NEAR(\'one two\' \'three four\', 10) order by rank');
    $preData = $db->fetchAll("SElECT  topic as page,tags,people  FROM diarylogv2 where tags  MATCH 'NEAR(\"$topic\")' or topic  MATCH 'NEAR(\"$topic\")' or people  MATCH 'NEAR(\"$topic\")'  order by rank");
    //$preData=  self::fetchAll("SElECT  topic,tags,people  FROM diarylogv2 where tags  MATCH \"$topic\" order by rank");
    if (sizeof($preData) == 0) {
        $preData = $db->fetchAll("SElECT  topic as page,tags,people  FROM diarylogv2 where tags  like '%$topic%'  or topic  like '%$topic%' or people  like '%$topic%'");
        if (sizeof($preData) == 0) {
            $results = $db->fetchAll(SQLite3::escapeString("SElECT  topic as page,tags,people  FROM diarylogv2 order by rowid asc"));
            $data = [];

            foreach ($results as $row) {
                $data[] = $row;
            }
        } else {
            $data = $preData;
        }

    } else {

        $data = $preData;

    }


    return json_encode($data);

}


function DataGetCurrentTask()
{
    global $db;

    $hourThreshold= DataLastKnownGameTS()-(2/ 0.0000024);

    $results = $db->fetchAll("SElECT  distinct description as description,gamets FROM currentmission where sess='ephemeral' and gamets>$hourThreshold order by gamets desc");
    error_log("SElECT  distinct description as description,gamets FROM currentmission where sess='ephemeral' and gamets>$hourThreshold order by gamets desc");

    if (!empty($results)) {
        // couldnt find usages of ephemeral quests so didnt modify this apart from new lines
        return "\n{$results[0]["description"]}\n";
    }

    $data = "";
    $results = $db->fetchAll("SELECT distinct description as description,gamets FROM currentmission where sess<>'ephemeral' and gamets>$hourThreshold order by gamets desc LIMIT 5 ");
    if (!empty($results)) {
        $data = "\n\n<current_plans>\n#Current Plans\n";
        $n = 0;
        foreach ($results as $row) {
            if ($n == 0) {
                $data .= "## Current: {$row["description"]}.\n";
            } elseif ($n == 1) {
                $data .= "## Previous: {$row["description"]}.\n";
            } else {
                break;
            }
            $n++;
        }
        $data .="</current_plans>\n";
    }

    // quests are an unordered list (because of how the aiagent plugin works - delete current, bulk update)
    // we would need to get clever with ignoring _questreset or expiring untouched quests, and using upserts on _quest
    // quests, and making "current" if _questdata updates after initial insert
    // for now lets just list all active quests rather than saying Current: xxx Previous: yyy
    // ! listing all quests could generate thousands tokens in prompt, let's limit
    $results = $db->fetchAll("SElECT  distinct name, briefing as description,gamets FROM quests order by gamets desc LIMIT 8"); 
    if (!$results) {
        Logger::info("No quests ".__FILE__." ".__LINE__." ".__FUNCTION__);
        return $data;
    }

    // dont think we need to limit it now since we dont require exactly two to format Current: xxx Previous: yyy
    //    if (sizeof($results)>2) {
    //        Logger::info("Too much quests ".__FILE__);
    //        return $data;
    //    }

    $data .= "\n\n<active_quests>\n#Active Quests\n";
    foreach ($results as $row) {
        $questDesc = trim($row["description"]);
        if (!empty($questDesc)) {
            $data .= "## {$row["name"]}: $questDesc\n";
        } else {
            $data .= "## {$row["name"]}\n";
        }
    }
    $data .="</active_quests>\n";
    return $data;
}


function DataLastRetFunc($actor, $lastNelements = -2)
{
    global $db;
    $lastDialogFull = array();
    $results = $db->fetchAll("select  a.data  as data  FROM  eventlog a 
    WHERE data like '%$actor%' and type in ('funcret')  order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    $lastData = "";
    foreach ($results as $row) {
        $pattern = "/\{(.*?)\(/";
        preg_match($pattern, $row["data"], $matches);
        $functionName = $matches[1];
        $lastDialogFull[] = array('role' => 'function', 'name' => $functionName, 'content' => $row["data"]);

    }

    $lastDialogFullReversed = array_reverse($lastDialogFull);
    $lastDialog = array_slice($lastDialogFullReversed, $lastNelements);
    $last_location = null;

    // Remove Context Location part when repeated
    foreach ($lastDialog as $k => $message) {
        preg_match('/\(Context location: [^)]+?\)/', $message['content'], $matches);
        $current_location = isset($matches[1]) ? $matches[1] : null;
        if ($current_location === $last_location) {
            $message['content'] = preg_replace('/\(Context location: [^)]+?\)/', '', $message['content']);
        } else {
            $last_location = $current_location;
        }
        $lastDialog[$k]["content"] = $message['content'];
    }


    return $lastDialog;

}

function DataLastAction($actor)
{
    global $db;
    
    $lastDialogFull = array();
    $cnActor = $db->escape($actor);
    $results = $db->fetchOne("select  *  FROM public.actions_issued
    WHERE actorname='$cnActor' order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    
    return $results;

}

function DataActorHasDied($actor)
{
    global $db;
    
    $lastDialogFull = array();
    $cnActor = $db->escape($actor);
    
    $rows = $GLOBALS["db"]->fetchAll("select 1 as n,gamets from eventlog where type='death'
        and (data like '%defeated $cnActor%' or data like '%killed $cnActor%')
        order by gamets desc limit 1");
    if ($rows)
        return true;
    
    return false;

}

function DataLastKnowDate() 
{
    if (isset($GLOBALS["CACHE_LAST_KNOW_DATE"])) {
        return $GLOBALS["CACHE_LAST_KNOW_DATE"];
    }

    global $db;
    
    // Get gamets and use PHP conversion function (skip SQL function to avoid PostgreSQL errors)
    $lastLoc=$db->fetchAll("SELECT a.gamets FROM eventlog a WHERE (type in ('infoloc')) ORDER BY gamets desc, ts desc LIMIT 1");
    if (is_array($lastLoc) && sizeof($lastLoc) > 0 && !empty($lastLoc[0]["gamets"])) {
        require_once(__DIR__ . "/utils_game_timestamp.php");
        $GLOBALS["CACHE_LAST_KNOW_DATE"] = convert_gamets2skyrim_long_date($lastLoc[0]["gamets"]);
        return $GLOBALS["CACHE_LAST_KNOW_DATE"];
    }
    
    // Fall back to parsing data field
    $lastLoc=$db->fetchAll("select  a.data  as data  FROM  eventlog a  WHERE (type in ('infoloc')) and (data like '%Current Date%')  order by gamets desc, ts desc LIMIT 1"); //make sure record has datetime
    if (!is_array($lastLoc) || sizeof($lastLoc)==0) {
        $GLOBALS["CACHE_LAST_KNOW_DATE"] = "";
        return "";
    }
    $re = '/(\w+), (\d{1,2}:\d{2} (?:AM|PM)), (\d{1,2})(?:st|nd|rd|th) of ([A-Za-z\'\ ]+), 4E (\d+)/'; //extract also for months with apostrophe like Sun's Something
    if (preg_match($re, $lastLoc[0]["data"], $matches, PREG_OFFSET_CAPTURE, 0)) {
        $GLOBALS["CACHE_LAST_KNOW_DATE"] = $matches[0][0];
        return $GLOBALS["CACHE_LAST_KNOW_DATE"];
    } else {
        Logger::info("DataLastKnowDate: NO match found");
        $GLOBALS["CACHE_LAST_KNOW_DATE"] = "";
        return "";
    }
}


function DataLastKnownLocation()
{
    if (isset($GLOBALS["CACHE_LAST_KNOWN_LOCATION"])) {
        return $GLOBALS["CACHE_LAST_KNOWN_LOCATION"];
    }

    global $db;

    $lastLoc=$db->fetchAll("select  a.data  as data  FROM  eventlog a  WHERE type in ('infoloc','location') and data like '%(Context%'  order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    if (!is_array($lastLoc) || sizeof($lastLoc)==0) {
        $GLOBALS["CACHE_LAST_KNOWN_LOCATION"] = "";
        return "";
    }
    /*
    $re = '/Context location: ([\w\ \']*)/';
    preg_match($re, $lastLoc[0]["data"], $matches, PREG_OFFSET_CAPTURE, 0);
    */
    $GLOBALS["CACHE_LAST_KNOWN_LOCATION"] = $lastLoc[0]["data"];
    return $GLOBALS["CACHE_LAST_KNOWN_LOCATION"];

}

function DataLastKnownLocationHuman($hold=false,$cached=false)
{

    global $db;
    
    $cache_key = $hold ? "HOLD" : "LOC";
    if (isset($GLOBALS["CACHE_LAST_KNOWN_LOCATION_HUMAN"][$cache_key]))
        return $GLOBALS["CACHE_LAST_KNOWN_LOCATION_HUMAN"][$cache_key];

    $lastLoc=$db->fetchAll("select  a.data  as data  FROM  eventlog a  WHERE type in ('infoloc','location','request') and data like '%(Context%'  order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    if (!is_array($lastLoc) || sizeof($lastLoc)==0) {
        $GLOBALS["CACHE_LAST_KNOWN_LOCATION_HUMAN"][$cache_key] = "";
        return "";
    }
    
    if (!$hold) {
        $re = '/Context (?:new )?location: ([\w\ \']*)/';
        preg_match($re, $lastLoc[0]["data"], $matches, PREG_OFFSET_CAPTURE, 0);
        $GLOBALS["CACHE_LAST_KNOWN_LOCATION_HUMAN"][$cache_key]=$matches[1][0];
        return $matches[1][0];
    } else {
        preg_match('/Hold:\s*(\w+)/', $lastLoc[0]["data"], $matches);
        if (isset($matches[1])) {
            $val = $matches[1];
        }
        else 
            $val = "";
        
        $GLOBALS["CACHE_LAST_KNOWN_LOCATION_HUMAN"][$cache_key] = $val;
        return $val;
    }

}


function PackIntoSummary($onlyMissingDiary=false)
{

    global $db;
    
    if ($onlyMissingDiary) {
        $results = $db->query("insert into memory_summary (gamets_truncated,n,packed_message,summary,classifier,uid,companions)
        select gamets,1,message,message,'diary',uid,speaker
        from memory
        where event in ('diary','auto_diary','backgroundlife_diary')
        and uid not in (select uid from memory_summary where classifier in  ('diary','auto_diary','backgroundlife_diary'))");

        $maxRow=0;

    } else {
        $lastGameTsRecord = $GLOBALS["db"]->fetchOne("select gamets as gamets from eventlog order by gamets desc LIMIT 1"); // 2.1ms
        $results = $GLOBALS["db"]->fetchAll("select gamets_truncated from memory_summary order by gamets_truncated desc LIMIT 1"); // 0.5ms, faster 

        $maxRow = isset($results[0]["gamets_truncated"]) ? intval($results[0]["gamets_truncated"]) : 0;
        $minRow = intval($lastGameTsRecord["gamets"]);
        $minRowTs = intval($lastGameTsRecord["gamets"] -  ( 1 /0.0000024));
        
        $pfi = intval($GLOBALS["FEATURES"]["MEMORY_EMBEDDING"]["AUTO_CREATE_SUMMARY_INTERVAL"] ?? 10) * 100000;
        $query="insert into memory_summary select * from ( 
                                    select max(gamets) as gamets_truncated,count(*) as n,
                                    STRING_AGG(message, chr(13) || chr(10) || chr(13) || chr(10)) AS packed_message,
                                    NULL as summary,'dialogue' as classifier,max(uid) as uid
                                    from memory_v
                                    where 
                                    message not ilike 'Dear Diary%'
                                    and gamets>$maxRow 
                                    group by round(gamets/$pfi ,0)  HAVING count(*)>9 order by round(gamets/$pfi ,0) ASC
                                ) as T where gamets_truncated>$maxRow and gamets_truncated<$minRowTs";
        //error_log($query);

        $results = $db->query($query);
        
        $results = $db->query("insert into memory_summary (gamets_truncated,n,packed_message,summary,classifier,uid,companions)
                                    select gamets,1,message,message,'diary',uid,speaker
                                    from memory
                                    where event='diary'
                                    and gamets>$maxRow
                                ");

    }

    
    return $maxRow;
}

function DataRechatHistory()
{

    global $db;
    // Actually we don't need the data here, just an array which size must match the history size.
    // Include 'narration' type as it's an official part of rechat (random narrator interjections)
    $lastRechat=$db->fetchAll("select gamets FROM  eventlog a  WHERE type in ('rechat','narration','inputtext','inputtext_s') 
    and localts>".(time()-120)."  order by gamets desc,ts desc LIMIT 10 OFFSET 0");
    
    return $lastRechat;

}



function extractDialogueTarget($string) {
    // Check if the string contains "(talking to"
    if ($string && strpos($string, '(talking to') !== false) {
        // Extract the target's name using regular expression
        preg_match('/\(talking to ([^\)]+)\)/', $string, $matches);
        
        // Check if a match is found and extract the target's name
        if (isset($matches[1])) {
            $target = $matches[1];

            // Remove the "(talking to ...)" part from the original string
            $cleanedString = preg_replace('/\(talking to [^\)]+\)/', '', $string);
            if (strpos($cleanedString,"{$GLOBALS["HERIKA_NAME"]}:")===0) {
                $cleanedString=str_replace("{$GLOBALS["HERIKA_NAME"]}:","",$cleanedString);
            }
            
            return ['target' => $target, 'cleanedString' => trim($cleanedString)];
        }
    }

    // Return the original string if no target is found
    return ['target' => null, 'cleanedString' => $string];
}

function DataGetLastReadedBook() {
    global $db;
    
    
    // To push where the book was taken from.
    $results = $db->fetchAll("select data from eventlog where data is not null and type='itemfound' and data like '%book%' 
    order by gamets desc,ts desc,localts desc,rowid desc LIMIT 1 OFFSET 0");
    
    if ($results) {
        $bookOnlyContext[] = array('role' => "user", 'content' => $results[0]["data"]);
    }
    
    
    $lastData = "";
    $results = $db->fetchAll("select content from books where content is not null
    order by gamets desc,ts desc,localts desc,rowid desc LIMIT 1 OFFSET 0");
    $lastData = "";
    
    $bookOnlyContext[] = array('role' => "user", 'content' => $results[0]["content"]);

    return $bookOnlyContext;
    
}

function DataGetTrackedStat($stat) {
    global $db;
    
    // Try to get from core_player table first
    try {
        require_once(__DIR__ . DIRECTORY_SEPARATOR . "core" . DIRECTORY_SEPARATOR . "player.class.php");
        $player = new Player();
        $value = $player->get($stat);
        
        if ($value !== null) {
            return json_encode([['id' => $stat, 'value' => $value]]);
        }
    } catch (Exception $e) {
        Logger::debug("Could not read stat from core_player: " . $e->getMessage());
    }
    
    // Fallback to conf_opts
    $escapedStat = $db->escape($stat);
    $results = $db->fetchAll("select * from conf_opts where id='{$escapedStat}'");
    
    return json_encode($results);
}

function DataGetCurrentPartyConf() {
    global $db;

    $results = $db->fetchAll("select value from conf_opts where id='CurrentParty'");
    if (is_array($results) && sizeof($results)>0) {
        // The C++ code stores party data like: {"name":"Lydia"},{"name":"Serana"},
        // We need to wrap it in brackets and remove trailing comma to make valid JSON
        $partyData = trim($results[0]["value"]);
        if (empty($partyData)) {
            return json_encode([]);
        }
        
        // Remove trailing comma if present
        $partyData = rtrim($partyData, ',');
        
        // Wrap in brackets to make it a valid JSON array
        $jsonString = "[" . $partyData . "]";
        
        $guys = json_decode($jsonString, true);
        if (!is_array($guys)) {
            Logger::warn("DataGetCurrentPartyConf: Failed to parse party JSON: " . $jsonString);
            return json_encode([]);
        }
        
        $finalparty=[];
        foreach ($guys as $guy) {
            if (isset($guy["name"])) {
                $finalparty[$guy["name"]]=$guy;
                $npcMaster=new NpcMaster();
                $currentNpcData=$npcMaster->getByName($guy["name"]);
                if (isset($currentNpcData["core"])&&!empty($currentNpcData["core"]))
                    $finalparty[$guy["name"]]["core"]=$currentNpcData["core"];

            }
        }
    
        return json_encode($finalparty);
    } else
        return json_encode([]);
    
}

function DataBeingsInRange()
{
    if (isset($GLOBALS["CACHE_BEINGS_IN_RANGE"])) {
        return $GLOBALS["CACHE_BEINGS_IN_RANGE"];
    }

    global $db;

    $lastLoc=$db->fetchAll("select  a.data  as data  FROM  eventlog a  WHERE type in ('infonpc')  order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    if (!is_array($lastLoc) || sizeof($lastLoc)==0) {
        $GLOBALS["CACHE_BEINGS_IN_RANGE"] = "";
        return "";
    }
    
    $beings=strtr($lastLoc[0]["data"],["(beings in range:"=>""]);
    $beingsArray=explode(",",$beings);
    $beingsArrayNew=[];
    $beingsArrayNew[]="{$GLOBALS["PLAYER_NAME"]}";  // Add player to beings in range
    foreach ($beingsArray as $k=>$v) {
        if (strpos($v,"(")===false) 
            if (strpos($v,"Horse")!==0) 
                if (strpos($v,"Chicken")!==0) 
                    $beingsArrayNew[]=strtr($v,[")"=>""]);
            
        
    }
    $beingsFormatted=implode("|",$beingsArrayNew);
    
    $GLOBALS["CACHE_BEINGS_IN_RANGE"] = "|".$beingsFormatted."|";
    return $GLOBALS["CACHE_BEINGS_IN_RANGE"];
}

function DataBeingsInRangeExcluding($excludeNPC="", $excludePlayer=true)
{
    if (isset($GLOBALS["CACHE_BEINGS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer])) {
        return $GLOBALS["CACHE_BEINGS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer];
    }

    global $db;

    $lastLoc=$db->fetchAll("select  a.data  as data  FROM  eventlog a  WHERE type in ('infonpc')  order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    if (!is_array($lastLoc) || sizeof($lastLoc)==0) {
        $GLOBALS["CACHE_BEINGS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer] = "";
        return "";
    }
    if (trim($excludeNPC) > "")
        $exNPC = trim($excludeNPC);
    else
        $exNPC = "x_y_z";
            
    $beings=strtr($lastLoc[0]["data"],["(beings in range:"=>""]);
    $beingsArray=explode(",",$beings);
    $beingsArrayNew=[];
    if (!$excludePlayer)
        $beingsArrayNew[]="{$GLOBALS["PLAYER_NAME"]}";  // Add player to beings in range
    foreach ($beingsArray as $k=>$v) {
        if (strpos($v,")")===false) {
            if (strpos($v,"Horse")!==0) 
                if (strpos($v,"Chicken")!==0) 
                    if (strpos($v,$exNPC)!==0) 
                        $beingsArrayNew[]=$v;
        }
    }
    $beingsFormatted=implode("|",$beingsArrayNew);
    error_log("<{$lastLoc[0]["data"]}> $beingsFormatted");
    $GLOBALS["CACHE_BEINGS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer] = "|".$beingsFormatted."|";
    return $GLOBALS["CACHE_BEINGS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer];
}

function DataBeingsOrDeathsInRangeExcluding($excludeNPC="", $excludePlayer=true)
{
    if (isset($GLOBALS["CACHE_BEINGS_OR_DEATHS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer])) {
        return $GLOBALS["CACHE_BEINGS_OR_DEATHS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer];
    }

    global $db;

    $lastLoc=$db->fetchAll("select  a.data  as data  FROM  eventlog a  WHERE type in ('infonpc')  order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    if (!is_array($lastLoc) || sizeof($lastLoc)==0) {
        $GLOBALS["CACHE_BEINGS_OR_DEATHS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer] = "";
        return "";
    }
    if (trim($excludeNPC) > "")
        $exNPC = trim($excludeNPC);
    else
        $exNPC = "x_y_z";
            
    $beings=strtr($lastLoc[0]["data"],["(beings in range:"=>""]);
    $beingsArray=explode(",",$beings);
    $beingsArrayNew=[];
    if (!$excludePlayer)
        $beingsArrayNew[]="{$GLOBALS["PLAYER_NAME"]}";  // Add player to beings in range
    foreach ($beingsArray as $k=>$v) {
        if (strpos($v,")")!==0) {
            if (strpos($v,"Horse")!==0) 
                if (strpos($v,"Chicken")!==0) 
                    if (strpos($v,$exNPC)!==0) 
                        $beingsArrayNew[]=$v;
        }
    }
    $beingsFormatted=implode("|",$beingsArrayNew);
    error_log("<{$lastLoc[0]["data"]}> $beingsFormatted");
    $GLOBALS["CACHE_BEINGS_OR_DEATHS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer] = "|".$beingsFormatted."|";
    return $GLOBALS["CACHE_BEINGS_OR_DEATHS_IN_RANGE_EXCLUDING"][$excludeNPC][(int)$excludePlayer];
}

function DataBeingsInCloseRange($excludeFarAway=false)
{

    global $db;

    $s_res = "";
    
    $lastLoc=$db->fetchAll("SELECT a.data as data FROM eventlog a WHERE type in ('infonpc_close') order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    if (!is_array($lastLoc) || sizeof($lastLoc)==0) {
        return "";
    }
    
    $s_npcs = trim($lastLoc[0]["data"] ?? "");
    if (strlen($s_npcs) > 0) {
        if (stripos($s_npcs, "beings in range") !== false) {
            $beings=strtr($s_npcs,["beings in range:"=>""]);
        } else 
            $beings=$s_npcs;
        $beingsArray=explode("/",$beings);
        $beingsArrayNew=[];
        foreach ($beingsArray as $k=>$v) {
            if ($excludeFarAway && strpos($v,"(far away)")>0)
                continue;
            if (strpos($v,"(dead)")>0) //??
                continue;
            if (empty($v))
                continue;
            //if (strpos($v,")")===false) 
                if (strpos($v,"Horse")!==0) 
                    if (strpos($v,"Chicken")!==0) 
                    if (strpos($v,"Goat")!==0) 
                    if (strpos($v,"House Cat")!==0) 
                    if (strpos($v,"Stray Cat")!==0) 
                    if (strpos($v,"Cow")!==0) 
                    if (strpos($v,"Deer")!==0) 
                    if (strpos($v,"Elk")!==0) 
                    if (strpos($v,"Bear")!==0) 
                    if (strpos($v,"Rabbit")!==0) 
                    if (strpos($v,"Troll")!==0) 
                    if (strpos($v,"Fox")!==0) 
                        $beingsArrayNew[]=$v;
        }
        $beingsFormatted=implode("|",$beingsArrayNew);
        $s_res = "|".$beingsFormatted."|";
    }

    return $s_res;
}

function DataItemsInCloseRange()
{
    global $db;

    $lastItems = $db->fetchAll("SELECT a.data as data FROM eventlog a WHERE type in ('infoitems') order by gamets desc,ts desc LIMIT 1 OFFSET 0");
    
    if (!is_array($lastItems) || sizeof($lastItems) == 0) {
        return "";
    }
    
    $s_items = trim($lastItems[0]["data"] ?? "");
    
    if (strlen($s_items) > 0) {
        if (stripos($s_items, "items in range") !== false) {
            // Extract items from "(items in range:0x123:Item1,0x456:Item2)"
            // Use greedy match (.+) to capture everything including (STEALING) and (LOOKING AT) tags until the LAST closing paren
            if (preg_match('/\(items in range:(.+)\)/', $s_items, $matches)) {
                $items = $matches[1];
                
                // Translate (LOOKING AT) marker to natural language
                // Replace "(LOOKING AT)" with "{$GLOBALS['PLAYER_NAME']} is looking at"
                $playerName = $GLOBALS["PLAYER_NAME"] ?? "Player";
                $items = preg_replace_callback(
                    '/([^,]+)\s*\(LOOKING AT\)/',
                    function($match) use ($playerName) {
                        // $match[1] is the item (e.g., "0x123:0x456:Soul Gem (Grand)")
                        return trim($match[1]) . " ({$playerName} is looking at this)";
                    },
                    $items
                );
                
                return $items; // Return comma-separated list with translated markers
            }
        }
    }
    
    return "";
}

// Find actor name with closest name, useful to sanitize actions parameters
function FindClosestActorName($actorName)
{
    global $db;

    $lastLoc = $db->fetchAll("SELECT a.data AS data FROM eventlog a WHERE type IN ('infonpc_close') ORDER BY gamets DESC, ts DESC LIMIT 1 OFFSET 0");
    if (!is_array($lastLoc) || sizeof($lastLoc) == 0) {
        return "";
    }

    $beings = strtr($lastLoc[0]["data"], ["beings in range:" => ""]);
    $beingsArray = explode("/", $beings);
    $beingsArrayCleaned = [];

    foreach ($beingsArray as $v) {
        // Remove all text within parentheses and trim whitespace
        $v = trim(preg_replace('/\s*\([^)]*\)/', '', $v));
        if (empty($v))
            continue;
        // Exclude certain entities
        if (strpos($v, "Horse") !== 0 && strpos($v, "Chicken") !== 0) {
            $beingsArrayCleaned[] = $v;
        }
    }

    if (empty($beingsArrayCleaned)) {
        return "";
    }

    // Find the closest match using Levenshtein distance
    $closest = null;
    $shortest = -1;

    foreach ($beingsArrayCleaned as $name) {
        $lev = levenshtein($actorName, $name);

        if ($lev == 0) {
            return $name; // Exact match
        }

        if ($lev < $shortest || $shortest < 0) {
            $closest = $name;
            $shortest = $lev;
        }
    }

    return $closest;
}

function FindClosestNPCName($actorName)
{
    global $db;

    $lastLoc = $db->fetchAll("SELECT a.data as people FROM eventlog a WHERE type IN ('infonpc_close') ORDER BY gamets DESC, ts DESC LIMIT 1 OFFSET 0");
    if (!is_array($lastLoc) || sizeof($lastLoc) == 0) {
        error_log("Note: no FindClosestNPCName data");
        return "";
    }

    $beings = strtr($lastLoc[0]["people"], ["beings in range:" => ""]);
    $beingsArray = explode("/", $beings);
    $beingsArrayCleaned = [];

    foreach ($beingsArray as $v) {
        // Remove all text within parentheses and trim whitespace
        $v = trim(preg_replace('/\s*\([^)]*\)/', '', $v));

    }

    if (empty($beingsArrayCleaned)) {
        error_log("Note: empty(beingsArrayCleaned)");
        return $actorName;
    }

    // Find the closest match using Levenshtein distance
    $closest = null;
    $shortest = -1;

    foreach ($beingsArrayCleaned as $name) {
        $lev = levenshtein($actorName, $name);
        error_log("Comparing: $actorName, $name");

        if ($lev == 0) {
            return $name; // Exact match
        }

        if ($lev < $shortest || $shortest < 0) {
            $closest = $name;
            $shortest = $lev;
        }
    }

    return (!empty(trim($closest)))?$closest:$actorName;
}

function DirectConversationsWith($actor, $speaker="")
{

    global $db;
    $i_res = 0;
    
    if ($speaker=="")
        $speakerprmt=$db->escape(GetOriginalHerikaName());
    else 
        $speakerprmt=$db->escape($speaker);
    
    $listenerprmt=$db->escape($actor);
    $gametsLimit=round(($GLOBALS["gameRequest"][2]??0)-(getGametsLimitFor($actor)/0.0000024),0);
    $lastLoc=$db->fetchAll("SELECT count(*) as N FROM speech WHERE (speaker='$speakerprmt' and listener='$listenerprmt') OR (listener='$speakerprmt' and speaker='$listenerprmt') and gamets<$gametsLimit");
    
    if (!is_array($lastLoc) || sizeof($lastLoc)==0) {
        Logger::warn("DirectConversationsWith: zero interactions {$speakerprmt} - {$listenerprmt} ");
    } else {
        $i_res = intval($lastLoc[0]["n"]);
    }
    //error_log(" --- dbg DirectConversationsWith: |{$i_res}| {$speakerprmt} - {$listenerprmt} ");
    return $i_res;
    
}

function DataSearchMemory($rawstring,$npcfilter) {
    
    //$kw=explode(" ",($rawstring));
    if (is_array($rawstring)) {
        $kwStringAny=implode(" | ",$rawstring);
        $kwStringAll=implode(" & ",$rawstring);
        
    } else if ($GLOBALS["MINIME_T5"]) {
        // MiniMe keyword extraction
        Logger::info("Using minime-t5 context");
        $rawstring=strtr($rawstring,["{$GLOBALS["PLAYER_NAME"]}:"=>""]);
        $rawstring=strtr($rawstring,["Talking to The Narrator"=>""]);

        $pattern = "/\(Context location:[^)]+?\)/"; // Remove only the exact context location pattern
        $replacement = "";
        $TEST_TEXT = preg_replace($pattern, $replacement, $rawstring); 
                    
        $pattern = '/\(talking to [^()]+\)/i';
        $TEST_TEXT = preg_replace($pattern, '', $TEST_TEXT);

        $keywords=minimeExtract($TEST_TEXT);
        $reponse=json_decode($keywords,true);
        
        //print_r($reponse);
        
        if (isset($reponse["is_memory_recall"]) && $reponse["is_memory_recall"]=="No") {
             $GLOBALS["db"]->insert(
                'audit_memory',
                array(
                    'input' => $TEST_TEXT,
                    'keywords' =>'minibot declined',
                    'rank_any'=> -1,
                    'rank_all'=>-1,
                    'memory'=>'',
                    'time'=>$reponse["elapsed_time"]
                )
            );
            return "";
        } else  if (isset($reponse["is_memory_recall"])) {
        
            if (isset($reponse["version"]) && $reponse["version"]==2) {
                $altKeywords=explode(" ",lastNames(15,["inputtext"]));
                $altKeywords=[];
                $keywords=explode(" ",strtr($reponse["generated_tags"],["remember"=>"","Remember"=>""]));
                $kwStringAny=implode(" | ",$keywords);
                $kwStringAll=implode(" & ",$keywords);
                $result = array_unique($keywords);
            } else {
                $altKeywords=explode(" ",lastNames(15,["inputtext"]));
                $altKeywords=[];
                $keywords=explode("|",strtr($reponse["generated_tags"],["remember"=>"","Remember"=>""]));
                array_merge($keywords,$altKeywords);
                $kw=[];
            
                foreach ($keywords as $tag) {
                    if (strlen($tag)<4)
                        continue;

                    
                    $lkwPre="";
                    foreach (explode(" ",$tag) as $stag) {
                        $lkwPre.=ucfirst($stag);
                    }
                    
                    //$lkw=hashtagify($tag);    
                    $lkw="#$lkwPre";
                    
                    if ($lkw) {
                        $kw=array_merge($kw,explode(" ",$lkw));
                    }
                }
                $result = array_unique($kw);

                $kwStringAny=implode(" | ",$result);
                $kwStringAll=implode(" & ",$result);
            }
            Logger::debug("CONTEXT SEARCH KEYWORDS FROM MINIME: ".print_r($result,true));
        }
        
    } 

    if (empty($kwStringAll)) {
        Logger::info("Using dumb context");
        $rawstring=strtr($rawstring,["{$GLOBALS["PLAYER_NAME"]}:"=>""]);
        $rawstring=strtr($rawstring,["Talking to The Narrator"=>""]);

        $pattern = "/\(Context location:[^)]+?\)/"; // Remove only the exact context location pattern
        $replacement = "";
        $TEST_TEXT = preg_replace($pattern, $replacement, $rawstring); // // assistant vs user war
                    
        $pattern = '/\(talking to [^()]+\)/i';
        $TEST_TEXT = preg_replace($pattern, '', $TEST_TEXT);

        $keywords=hashtagifySentences($TEST_TEXT);
        $kw=[];
        
        //print_r($keywords);

        foreach (explode(" ",$keywords) as $tag) {
            if (strlen($tag)<4)
                continue;
            $lkw=hashtagify(strtr($tag,["remember"=>"","Remember"=>""]));    
            if ($lkw) {
                $kw=array_merge($kw,explode(" ",$lkw));
            }
        }
        $result = array_unique($kw);

        $kwStringAny=implode(" | ",$result);
        $kwStringAll=implode(" & ",$result);
        Logger::debug("CONTEXT SEARCH KEYWORDS FROM DUMB: ".print_r($result,true));
    }
        
    
    
    
    $memory=$GLOBALS["db"]->fetchAll("
        SELECT summary,gamets_truncated,
        ts_rank(native_vec, to_tsquery('$kwStringAny')) AS rank_any,
        ts_rank(native_vec, to_tsquery('$kwStringAll')) AS rank_all
        FROM memory_summary A
        where native_vec @@to_tsquery('$kwStringAny')
        and not (native_vec @@to_tsquery('#Reminiscence'))
        and companions like '|%{$GLOBALS["db"]->escape($npcfilter)}|%'

        ORDER BY rank_all DESC, rank_any DESC;
        ",true);
            
        if (!isset($memory[0]))
            $memory[0]=["rank_any"=>null,"rank_all"=>null,"summary"=>null];

        $GLOBALS["db"]->insert(
                'audit_memory',
                array(
                    'input' => $TEST_TEXT,
                    'keywords' =>$kwStringAny,
                    'rank_any'=> $memory[0]["rank_any"],
                    'rank_all'=>$memory[0]["rank_all"],
                    'memory'=>$memory[0]["summary"],
                    'time'=>isset($reponse["elapsed_time"])?$reponse["elapsed_time"]:"0 secs (internal)"
                )
            );
            
    
    return $memory;
    
}


function DataSearchMemoryByVector($rawstring,$npcfilter,$useContextKw=false,$timeThreshold=0) {
    
        $localStartTime=microtime(true);
        Logger::info("Using DataSearchMemoryByVector $rawstring,$npcfilter,$useContextKw=false,$timeThreshold=0");
        
        if (!$timeThreshold)
            $timeThreshold=0;
        
        $result=[];
        if (is_array($rawstring)) {
            $kwStringAny=implode(" ",$rawstring);
            $kwStringAll=implode(" ",$rawstring);
        
        } else if ($GLOBALS["MINIME_T5"]) {
            // MiniMe keyword extraction
            Logger::info("Using minime-t5 context");
            error_log("[DataSearchMemoryByVector] Using minime-t5 context");
            $rawstring=strtr($rawstring,["{$GLOBALS["PLAYER_NAME"]}:"=>""]);
            $rawstring=strtr($rawstring,["Talking to The Narrator"=>""]);

            $pattern = "/\(Context location:[^)]+?\)/"; // Remove only the exact context location pattern
            $replacement = "";
            $TEST_TEXT = preg_replace($pattern, $replacement, $rawstring); 
                        
            $pattern = '/\(talking to [^()]+\)/i';
            $TEST_TEXT = preg_replace($pattern, '', $TEST_TEXT);

            error_log("[DataSearchMemoryByVector start] minimeExtract : " . (microtime(true) - $localStartTime) . " seconds");
            $TEST_TEXT = preg_replace('/[(),;:!?."\'-]/', ' ', $TEST_TEXT);
            $TEST_TEXT = preg_replace('/\s+/', ' ', trim($TEST_TEXT));
            $TEST_TEXT=internalDumbTranslator($TEST_TEXT);
            
            if (isset($GLOBALS["PATCH_BYPASS_MINIME_EXTRACT"]) && $GLOBALS["PATCH_BYPASS_MINIME_EXTRACT"]) {
                error_log("[DataSearchMemoryByVector ] PATCH_BYPASS_MINIME_EXTRACT");
                $keywords=json_encode(["is_memory_recall"=>"Yes"]);
            } else {
                $keywords=minimeExtract($TEST_TEXT,true);// Only to check if memory is needed
            }

            error_log("[DataSearchMemoryByVector end] minimeExtract : " . (microtime(true) - $localStartTime) . " seconds");
            $reponse=json_decode($keywords,true);
            
            error_log("[DataSearchMemoryByVector end] minimeExtract : " .print_r($reponse,true));

            
            if (isset($reponse["is_memory_recall"]) && $reponse["is_memory_recall"]=="No") {
                $GLOBALS["db"]->insert(
                    'audit_memory',
                    array(
                        'input' => $TEST_TEXT,
                        'keywords' =>'minibot declined',
                        'rank_any'=> -1,
                        'rank_all'=>-1,
                        'memory'=>'',
                        'time'=>$reponse["elapsed_time"]
                    )
                );
                return null;

            }/* else  if (isset($reponse["is_memory_recall"])) {
            
                if (isset($reponse["version"]) && $reponse["version"]==2) {
                    $altKeywords=explode(" ",lastNames(15,["inputtext"]));
                    $altKeywords=[];
                    $keywords=explode(" ",strtr($reponse["generated_tags"],["remember"=>"","Remember"=>""]));
                    $result = array_unique($keywords);

                } else {
                    $altKeywords=explode(" ",lastNames(15,["inputtext"]));
                    $altKeywords=[];
                    $keywords=explode("|",strtr($reponse["generated_tags"],["remember"=>"","Remember"=>""]));
                    array_merge($keywords,$altKeywords);
                    $kw=[];
                
                    foreach ($keywords as $tag) {
                        if (strlen($tag)<4)
                            continue;

                        
                        $lkwPre="";
                        foreach (explode(" ",$tag) as $stag) {
                            $lkwPre.=ucfirst($stag);
                        }
                        
                        //$lkw=hashtagify($tag);    
                        $lkw="$lkwPre";
                        
                        if ($lkw) {
                            $kw=array_merge($kw,explode(" ",$lkw));
                        }
                    }
                    $result = array_unique($kw);

                   
                }
                Logger::debug("CONTEXT SEARCH KEYWORDS FROM MINIME: ".print_r($result,true));
            }*/
            
        } else {
            error_log("[DataSearchMemoryByVector] Minime-Disabled. what to do here?");
            return null;
        }

        if (sizeof($result)<1) {
            Logger::info("Using dumb context");
            $rawstring=strtr($rawstring,["{$GLOBALS["PLAYER_NAME"]}:"=>""]);
            $rawstring=strtr($rawstring,["Talking to The Narrator"=>""]);

            $pattern = "/\(Context location:[^)]+?\)/"; // Remove only the exact context location pattern
            $replacement = "";
            $TEST_TEXT = preg_replace($pattern, $replacement, $rawstring); // // assistant vs user war
                        
            $pattern = '/\(talking to [^()]+\)/i';
            $TEST_TEXT = preg_replace($pattern, '', $TEST_TEXT);

            $keywords=strtr($TEST_TEXT,["."=>" ",","=>" ","'"=>" "]);
            $kw=[];
            
            //print_r($keywords);

            foreach (explode(" ",$keywords) as $tag) {
                if (strlen($tag)<4)
                    continue;
                $lkw=$tag;
                if ($lkw) {
                    $kw=array_merge($kw,explode(" ",$lkw));
                }
            }
            $result = array_unique($kw);

            $resultEn=[];
            foreach ($result as $r) {
                $resultEn[]=internalDumbTranslator($r);
            }

            if (!sizeof($resultEn)<1) {
                $resultEn=$result;
            }

            $kwStringAny=implode(" | ",$resultEn);
            $kwStringAll=implode(" & ",$resultEn);

            Logger::debug("CONTEXT SEARCH KEYWORDS FROM DUMB: ".print_r($resultEn,true));
            error_log("CONTEXT SEARCH KEYWORDS FROM DUMB: <".implode("><",$resultEn).">");
        }

       
        if (empty($npcfilter)) {
            $npcfilter=$GLOBALS["HERIKA_NAME"];
        } else {
            if ($useContextKw)
                $result=array_merge($result,lastKeyWordsContext(5,$npcfilter));
        }

        $contextKeywords  = implode(" ", $result);
        $contextKeywords=strtr(internalDumbTranslator($contextKeywords),["remember"=>"","Remember"=>"","do you remember"=>""]);


        $url = $GLOBALS["FEATURES"]["MEMORY_EMBEDDING"]["TXTAI_URL"].'/embed';

        $data = [
            
            'text' => $contextKeywords   
        ];

        // Convert to JSON
        $options = [
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n" .
                            "Accept: application/json\r\n",
                'content' => json_encode($data),
                'ignore_errors' => true // to capture error messages if any
            ]
        ];

        // Create context and send the request
        $context  = stream_context_create($options);
        
        error_log("[DataSearchMemoryByVector Embedding start] Elapsed time: " . (microtime(true) - $localStartTime) . " seconds");
        $response = file_get_contents($url, false, $context);
        error_log("[DataSearchMemoryByVector Embedding end] Elapsed time: " . (microtime(true) - $localStartTime) . " seconds");

        // Output the response
        if ($response === false) {
            Logger::error("Request failed.\n");
        } else {
            Logger::info("Request done:\n");

        }

        $result = explode(" ",$contextKeywords);

        $resultNormalized=[];
        foreach ($result as $word) {
            if (strlen($word)<3)
                continue;
            if (!empty($word))
                $resultNormalized[]=$word;
        }

        
        $kwStringAny=implode(" | ",$resultNormalized);
        $kwStringAll=implode(" & ",$resultNormalized);
        error_log("[DataSearchMemoryByVector] Generated Tags: $kwStringAny" );
        $vector=json_decode($response,true);

        if (is_array($vector) && isset($vector["embedding"])) {
            $vectorString="'[".implode(",",$vector["embedding"])."]'";
   
            $finalQuery="
                SELECT summary, gamets_truncated,
                        embedding <-> $vectorString as distance,
                         ts_rank(native_vec, to_tsquery('$kwStringAny'))+ts_rank(native_vec, to_tsquery('$kwStringAll')) AS rank_any_fts,
                         ts_rank(native_vec, to_tsquery('$kwStringAll')) AS rank_all_fts,
                         (embedding <-> $vectorString) - ts_rank(native_vec, to_tsquery('$kwStringAny'))+ts_rank(native_vec, to_tsquery('$kwStringAll'))
                          AS mixed_distance
                    FROM public.memory_summary 
                    WHERE embedding IS NOT NULL
                    and companions like '|%{$GLOBALS["db"]->escape($npcfilter)}|%'
                    ORDER BY (embedding <-> $vectorString)
                    LIMIT 5 OFFSET 0
                ";

             $finalQuery="
                SELECT rowid,gamets_truncated,
                        embedding <-> $vectorString as distance,
                         ts_rank(native_vec, to_tsquery('$kwStringAny')) AS rank_any_fts_raw,
                         ts_rank(native_vec, to_tsquery('$kwStringAll')) AS rank_all_fts_raw,
                         ts_rank(native_vec, to_tsquery('$kwStringAny'))+ts_rank(native_vec, to_tsquery('$kwStringAll')) AS rank_any_fts,
                         ts_rank(native_vec, to_tsquery('$kwStringAny'))+ts_rank(native_vec, to_tsquery('$kwStringAll')) AS rank_all_fts,
                         (embedding <-> $vectorString) - (ts_rank(native_vec, to_tsquery('$kwStringAny'))+ts_rank(native_vec, to_tsquery('$kwStringAll')) ) AS mixed_distance,
                         summary
                    FROM public.memory_summary 
                    WHERE embedding IS NOT NULL
                    and companions like '|%{$GLOBALS["db"]->escape($npcfilter)}|%'
                    and (gamets_truncated<$timeThreshold or $timeThreshold=0)
                    
                    ORDER BY 
                        round((embedding <-> $vectorString)::numeric, 2) ASC,
                        (ts_rank(native_vec, to_tsquery('$kwStringAny'))+ts_rank(native_vec, to_tsquery('$kwStringAll'))) DESC
                    LIMIT 50 OFFSET 0
                ";    
            $memory=$GLOBALS["db"]->fetchAll($finalQuery);
            //error_log($finalQuery);
            $singleMemory = null;
            $maxRankAny = -INF;

            foreach ($memory as $entry) {
                if (isset($entry['rank_any_fts']) && $entry['rank_any_fts'] > $maxRankAny) {
                    $maxRankAny = $entry['rank_any_fts'];
                    $singleMemory = $entry;
                }
            }
         
            if (!isset($singleMemory)) {
                $singleMemory=["rank_any"=>null,"rank_all"=>null,"summary"=>null];
                $singleMemory["distance"]=1.4;
            }
            else {
                 $singleMemory['rank_any']=(($singleMemory["rank_any_fts"])+($singleMemory["rank_all_fts"])/2);
                 $singleMemory['rank_all']=($singleMemory["rank_all_fts"]);
            }
            
            /*error_log("
                 SELECT summary, gamets_truncated,
                        embedding <-> $vectorString as distance,
                         ts_rank(native_vec, to_tsquery('$kwStringAny')) AS rank_any_fts,
                         ts_rank(native_vec, to_tsquery('$kwStringAll')) AS rank_all_fts
                    FROM public.memory_summary 
                    WHERE embedding IS NOT NULL
                    and companions like '%{$GLOBALS["db"]->escape($npcfilter)}%'
                    ORDER BY (embedding <-> $vectorString)-ts_rank(native_vec, to_tsquery('$kwStringAny')) 
                    LIMIT 5 OFFSET 0
                ");*/

            $GLOBALS["db"]->insert(
                    'audit_memory',
                    array(
                        'input' => $TEST_TEXT,
                        'keywords' =>'text2vec search / (input plus "'.$contextKeywords.'"',
                        'rank_any'=> (1.40-$singleMemory["mixed_distance"]),// Try to mimic FTS query rank
                        'rank_all'=> (1.40-$singleMemory["distance"]),// Try to mimic FTS query rank
                        'memory'=>$singleMemory["summary"],
                        'time'=>isset($vector["timing"])?$vector["timing"]["generation_time_seconds"]:"0 secs (text2vec)"
                    )
                );
            
        } else {
            return null;
        }
            
    
    return [$singleMemory];
    
}

function DataSearchOghmaByVector($rawstring,$currentOghmaTopic,$locationCtx,$contextKeywords) {
//function DataSearchOghmaByVector($rawstring) {
    
    
    Logger::info("Using DataSearchOghmaByVector");
    $rawstring=strtr($rawstring,["{$GLOBALS["PLAYER_NAME"]}:"=>""]);
    $rawstring=strtr($rawstring,["Talking to The Narrator"=>""]);

    $pattern = "/\(Context location:[^)]+?\)/"; // Remove only the exact context location pattern
    $replacement = "";
    $TEST_TEXT = preg_replace($pattern, $replacement, $rawstring); 
                
    $pattern = '/\(talking to [^()]+\)/i';
    $TEST_TEXT = preg_replace($pattern, '', $TEST_TEXT);

   
    Logger::info("DataSearchOghmaByVector <$TEST_TEXT> Expanded keywords: <$currentOghmaTopic> <$locationCtx> <$contextKeywords>");
    /***/

    $embeddingFunction=function($text) {
        if (empty($text))
            return ["embedding"=>array_fill(0, 384, 0)];

        $url = $GLOBALS["FEATURES"]["MEMORY_EMBEDDING"]["TXTAI_URL"].'/embed';
        $data = [
            'text' => $text   // We add previous keywords
        ];

        // Convert to JSON
        $options = [
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n" .
                            "Accept: application/json\r\n",
                'content' => json_encode($data),
                'ignore_errors' => true // to capture error messages if any
            ]
        ];

        // Create context and send the request
        $context  = stream_context_create($options);
        $response = file_get_contents($url, false, $context);

        // Output the response
        if ($response === false) {
            Logger::error("Request failed.\n");
        } else {
            Logger::info("Request done: Searched: {$data["text"]}\n");

        }

        $vector=json_decode($response,true);
        return sizeof($vector)>0?$vector:["embedding"=>array_fill(0, 384, 0)];

    };

    $vector1=$embeddingFunction($TEST_TEXT);
    $vector2=$embeddingFunction($locationCtx);
    $vector3=$embeddingFunction($contextKeywords);
    $vector4=$embeddingFunction($currentOghmaTopic);
    
    

    if (is_array($vector1) && isset($vector1["embedding"])) {
        $vectorString1="'[".implode(",",$vector1["embedding"])."]'";
        $vectorString2="'[".implode(",",$vector2["embedding"])."]'";
        $vectorString3="'[".implode(",",$vector3["embedding"])."]'";
        $vectorString4="'[".implode(",",$vector4["embedding"])."]'";

        $memory=$GLOBALS["db"]->fetchAll("
            SELECT  topic_desc,
                                topic,
                                knowledge_class,
                                knowledge_class_basic,
                                topic_desc_basic, 
                    vector384 <-> $vectorString1 as distance1,
                    vector384 <-> $vectorString2 as distance2,
                    vector384 <-> $vectorString3 as distance3,
                    vector384 <-> $vectorString4 as distance4,
                    ((vector384 <-> $vectorString1) + (vector384 <-> $vectorString2)/4 + (vector384 <-> $vectorString3)/2 + (vector384 <-> $vectorString4)/2 )/2 as distance
                FROM public.oghma 
                WHERE vector384 IS NOT NULL
                ORDER BY ((vector384 <-> $vectorString1) + (vector384 <-> $vectorString2)/4 + (vector384 <-> $vectorString3)/2 + (vector384 <-> $vectorString4)/2 )/4 ASC
                LIMIT 5 OFFSET 0
            ");
        
        

        if (!isset($memory[0]))
            $memory[0]=["combined_rank"=>null];
        else {
             $memory[0]['combined_rank']=(7.95-$memory[0]["distance"]);
             $memory[0]['combined_rank']=(7.95-$memory[0]["distance"]);
        }
        
        $GLOBALS["db"]->insert(
                'audit_memory',
                array(
                    'input' => $TEST_TEXT,
                    'keywords' =>'text2vec oghma search /'.$contextKeywords,
                    'rank_any'=> (1.40-$memory[0]["distance"]),// Try to mimic FTS query rank
                    'rank_all'=> (1.40-$memory[0]["distance"]),// Try to mimic FTS query rank
                    'memory'=>$memory[0]["topic"],
                    'time'=>isset($vector1["timing"])?$vector1["timing"]["generation_time_seconds"]:"0 secs (text2vec)"
                )
            );
        
    } else {
        return null;
    }
        

    return $memory;

}

function FastCallOAI($question) {
    
    $call["messages"]=[
        [
            "role"=>"user",
            "content"=>"$question"
        ]
    ];


    $call["stream"]=false;
    $call["stop"]=["\n"];

    $headers = ['Content-Type: application/json'];

    $options = array(
        'http' => array(
            'method' => 'POST',
                'header' => implode("\r\n", $headers),
                'content' => json_encode($call),
            )
    );

    $netContext = stream_context_create($options);
    $response=file_get_contents('http://localhost:5001/v1/chat/completions', false,$netContext);
    $rawResponse=json_decode($response,true);
    
    if (isset($rawResponse["choices"][0]["message"]["content"]))
        return $rawResponse["choices"][0]["message"]["content"];
    else
        return null;
    
}

function call_llm() {
    global $contextData, $gameRequest, $receivedData, $startTime, $db;
    global $ERROR_TRIGGERED, $talkedSoFar, $alreadysent, $FUNCTIONS_ARE_ENABLED;
    global $overrideParameters, $request;
    
    // Call the internal function (which now handles fallback itself)
    return call_llm_internal();
}

function call_llm_internal() {
    global $contextData, $gameRequest, $receivedData, $startTime, $db;
    global $ERROR_TRIGGERED, $talkedSoFar, $alreadysent, $FUNCTIONS_ARE_ENABLED;
    global $overrideParameters, $request;
    
    $outputWasValid = true;
    

    if (isset($GLOBALS["CHIM_CORE_CURRENT_CONNECTOR_DATA"])) {
        $connector=new LLMConnector();
        $connectionHandler = $connector->getConnector($GLOBALS["CHIM_CORE_CURRENT_CONNECTOR_DATA"]);
        error_log("[CORE SYSTEM] Using new profile system {$GLOBALS["CHIM_CORE_CURRENT_CONNECTOR_DATA"]["driver"]}/{$GLOBALS["CHIM_CORE_CURRENT_CONNECTOR_DATA"]["model"]}");
    } else {
        error_log("No connector defined");
        Logger::error("No connector defined");
        terminate();
    }

    if (isset($GLOBALS["CLEAN_CONTEXT_FOCUS_CHAT"]) && $GLOBALS["CLEAN_CONTEXT_FOCUS_CHAT"]) {

         /* *****
        Player TTS

        Player TTS. We overwrite some confs an then restore them.
        */
        // Only process player TTS on the first attempt, not during fallback retry
        if (!isset($GLOBALS["IN_FALLBACK_MODE"]) && in_array($gameRequest[0],["inputtext","inputtext_s","ginputtext","ginputtext_s","narrator_inputtext"]) && !Translation::isSavePlayerTranslationEnabled()) {
            require(__DIR__."/../processor/player_tts.php");
        }
        $currentConnectorData=$GLOBALS["CHIM_CORE_CURRENT_CONNECTOR_DATA"];
        error_log("[CLEAN_CONTEXT_FOCUS_CHAT] Using 2-step schema, model: {$currentConnectorData["driver"]}/{$currentConnectorData["model"]}");


        $buffer=$connectionHandler->fast_request($contextData,$overrideParameters,'standard');
        $buffer = preg_replace('/\*([^*]*\s+[^*]*)\*/', '', $buffer);

        error_log("[STEP 1] Elapsed time: " . (microtime(true) - $startTime) . " seconds");

        if ($GLOBALS["FUNCTIONS_ARE_ENABLED"]) {
            require_once($GLOBALS["ENGINE_PATH"]."/functions".DIRECTORY_SEPARATOR."json_response.php");
            $GLOBALS["COMMAND_PROMPT"]="";

            setActions();
        } else {
            $GLOBALS["FUNC_LIST"][]="Talk";
            $GLOBALS["COMMAND_PROMPT"]="";

        }

        $jsonformat= json_encode(["character"=>$GLOBALS["HERIKA_NAME"],
        "listener"=>"specify who {$GLOBALS["HERIKA_NAME"]} is talking to, comma separated, max two listeners, in addressing order",
        "message"=>"lines of dialogue",
        "mood"=>"One of :".implode("|",explode(",",$GLOBALS["EMOTEMOODS"])),
        "action"=>"One of :".implode("|",$GLOBALS["FUNC_LIST"]),
        "target"=>"action target actor|action destination location name",
        "item"=>"item name (REQUIRED when action is GiveItemTo or PickupItem - use exact name from inventory or nearby_items)",
        "lang"=>"language used, (es|en|fr|...)"]);


        $minimalContextData = array_slice($contextData, -5);
        $minimalContext=[];
        foreach ($minimalContextData as $ele) {
            if (strpos($ele["content"],"#MEMORY")===false) {
                $minimalContext[]="{$ele["content"]}";
            }
        }
        array_pop($minimalContext);

        $minimalContext[]="$buffer";// Add whole generated content.

        $buffer=preg_replace('/\([^)]*\)/', '', $buffer);//Remove text between space.
        $contextData2=[
            array('role' => 'system', 'content' => "Create a JSON object with this format: $jsonformat , using a 'Generated dialogue line' as source. "),
            array('role' => 'user', 'content' => "* Available actions:\n".$GLOBALS["COMMAND_PROMPT"]),
            array('role' => 'user', 'content' => "* Historic context information:\n".implode("\n",$minimalContext)),
            array('role' => 'user', 'content' => "* Generated dialogue line: <$buffer>"),
            array('role' => 'user', 'content' => "Convert the '* Generated dialogue line' , and ONLY the  '* Generated dialogue line' section, to a JSON object with this format: $jsonformat\n.You must infer some properties like action (check Available actions list ) and mood from context"),
        ];

        $connector=new LLMConnector();
        $currentConnectorData=$connector->getById($GLOBALS["CHIM_CORE_CURRENT_PROFILE_DATA"]["llm_formatter_id"]); // Asuming primary id



        $connector->setOldGlobals($currentConnectorData);

        $connectionHandler = $connector->getConnector($currentConnectorData);

        $buffer2=$connectionHandler->fast_request($contextData2,[],'formatter');
        unset($GLOBALS["_JSON_BUFFER"]);
        $finalRes=__jpd_decode_lazy($buffer2);
        file_put_contents(__DIR__."/../log/output_from_llm_fast_step_2.log", $buffer2, FILE_APPEND);
        file_put_contents(__DIR__."/../log/output_from_llm_fast_step_2.log", print_r($finalRes,true), FILE_APPEND);
        unset($GLOBALS["_JSON_BUFFER"]);
        $fakeObject["choices"][0]=[
            "index"=>0,
            "delta"=>["role"=>"assistant","content"=>json_encode($finalRes)]
        ];

        $connectionHandler->primary_handler=fopen("php://memory", "r+");// Total hack, we're emulating streaming mode.
        $fakedStream='data: '.json_encode($fakeObject);
        fwrite($connectionHandler->primary_handler,$fakedStream);
        rewind($connectionHandler->primary_handler);

        error_log("[CLEAN_CONTEXT_FOCUS_CHAT] Using 2-step schema, model: {$currentConnectorData["driver"]}/{$currentConnectorData["model"]}" );

    } else {

        
            /* *****
        Player TTS

        Player TTS. We overwrite some confs an then restore them.
        */
        // Only process player TTS on the first attempt, not during fallback retry
        if (!isset($GLOBALS["IN_FALLBACK_MODE"]) && in_array($gameRequest[0],["inputtext","inputtext_s","ginputtext","ginputtext_s","narrator_inputtext"]) && !Translation::isSavePlayerTranslationEnabled()) {
            require(__DIR__."/../processor/player_tts.php");
        }

        $connectionHandler->open($contextData,$overrideParameters);
    }





    ///// PATCH. STORE FUNCTION RESULT ONCE RESULT PROMPT HAS BEEN BUILT.
    if (isset($GLOBALS["PATCH_STORE_FUNC_RES"])) {
        $gameRequestCopy=$gameRequest;
        $gameRequestCopy[0]="infoaction";
        $gameRequestCopy[3]=$GLOBALS["PATCH_STORE_FUNC_RES"];
        logEvent($gameRequestCopy);
    }
    ///// PATCH

    error_log("[FALLBACK DEBUG] Checking primary_handler status: " . ($connectionHandler->primary_handler === false ? "FALSE" : "OK"));
    
    if ($connectionHandler->primary_handler === false) {
        error_log("[FALLBACK DEBUG] primary_handler is false, checking fallback conditions");
        
        // Check if we should try fallback BEFORE sending error message
        if (!isset($GLOBALS["IN_FALLBACK_MODE"])) {
            $shouldTryFallback = false;
            $fallbackConnectorId = null;
            
            if (isset($GLOBALS["CHIM_CORE_CURRENT_PROFILE_DATA"])) {
                $profileData = $GLOBALS["CHIM_CORE_CURRENT_PROFILE_DATA"];
                $fallbackConnectorId = $profileData["llm_fallback_id"] ?? null;
                error_log("[FALLBACK DEBUG] Fallback connector ID from profile: " . ($fallbackConnectorId ?? "NULL"));
                
                // Check if fallback is enabled in metadata
                if (!empty($profileData["metadata"])) {
                    $metadata = is_string($profileData["metadata"]) 
                        ? json_decode($profileData["metadata"], true) 
                        : $profileData["metadata"];
                    if (is_array($metadata)) {
                        $fallbackEnabled = !empty($metadata["LLM_FALLBACK_ENABLED"]);
                        error_log("[FALLBACK DEBUG] Fallback enabled in metadata: " . ($fallbackEnabled ? "YES" : "NO"));
                        $currentConnectorId = $GLOBALS["CHIM_CORE_CURRENT_CONNECTOR_DATA"]["id"] ?? null;
                        error_log("[FALLBACK DEBUG] Current connector ID: " . ($currentConnectorId ?? "NULL"));
                        $shouldTryFallback = $fallbackEnabled && $fallbackConnectorId && $fallbackConnectorId != $currentConnectorId;
                        error_log("[FALLBACK DEBUG] Should try fallback: " . ($shouldTryFallback ? "YES" : "NO"));
                    }
                }
            }
            
            if ($shouldTryFallback) {
                error_log("[FALLBACK] Primary connector failed (connection error). Attempting fallback connector ID: {$fallbackConnectorId}");
                
                // Set fallback mode flag to prevent player TTS reprocessing
                $GLOBALS["IN_FALLBACK_MODE"] = true;
                
                // Load and try fallback connector
                $connector = new LLMConnector();
                $fallbackConnectorData = $connector->getById($fallbackConnectorId);
                
                if ($fallbackConnectorData) {
                    error_log("[FALLBACK] Loaded fallback connector: {$fallbackConnectorData["driver"]}/{$fallbackConnectorData["model"]}");
                    $GLOBALS["CHIM_CORE_CURRENT_CONNECTOR_DATA"] = $fallbackConnectorData;
                    $connector->setOldGlobals($fallbackConnectorData);
                    
                    error_log("[FALLBACK] Recursively retrying with fallback connector");
                    // Recursively retry with fallback (flag stays set throughout retry)
                    $result = call_llm_internal();
                    
                    // Clear fallback mode flag after retry completes
                    unset($GLOBALS["IN_FALLBACK_MODE"]);
                    
                    return $result;
                } else {
                    error_log("[FALLBACK] Fallback connector ID {$fallbackConnectorId} not found.");
                    unset($GLOBALS["IN_FALLBACK_MODE"]);
                }
            }
        } else {
            error_log("[FALLBACK DEBUG] Already in fallback mode, not retrying");
        }
        
        // No fallback or fallback also failed - send error message
        error_log("[FALLBACK DEBUG] Sending ERROR_OPENAI message to user");
        $db->insert(
            'log',
            array(
                'localts' => time(),
                'prompt' => nl2br((json_encode($GLOBALS["DEBUG_DATA"], JSON_PRETTY_PRINT))),
                'response' => ((print_r(error_get_last(), true))),
                'url' => nl2br(("$receivedData in " . (microtime(true) - $startTime) . " secs "))
            )
        );
        if (Translation::isEnabled()) {
            Translation::translate($GLOBALS["ERROR_OPENAI"]);
            Translation::$sentences = [Translation::$response];
        }        
        returnLines([$GLOBALS["ERROR_OPENAI"]]);
        
        $ERROR_TRIGGERED=true;
        @ob_end_flush();

        Logger::error(print_r(error_get_last(), true));
        return false;
    }

    // Check for error response code
    $statusCode = method_exists($connectionHandler, 'getHttpStatusCode') ? $connectionHandler->getHttpStatusCode() : 200;
    if ($statusCode >= 300) {
        // Check if we should try fallback BEFORE sending error message
        if (!isset($GLOBALS["IN_FALLBACK_MODE"])) {
            $shouldTryFallback = false;
            $fallbackConnectorId = null;
            
            if (isset($GLOBALS["CHIM_CORE_CURRENT_PROFILE_DATA"])) {
                $profileData = $GLOBALS["CHIM_CORE_CURRENT_PROFILE_DATA"];
                $fallbackConnectorId = $profileData["llm_fallback_id"] ?? null;
                
                // Check if fallback is enabled in metadata
                if (!empty($profileData["metadata"])) {
                    $metadata = is_string($profileData["metadata"]) 
                        ? json_decode($profileData["metadata"], true) 
                        : $profileData["metadata"];
                    if (is_array($metadata)) {
                        $fallbackEnabled = !empty($metadata["LLM_FALLBACK_ENABLED"]);
                        $currentConnectorId = $GLOBALS["CHIM_CORE_CURRENT_CONNECTOR_DATA"]["id"] ?? null;
                        $shouldTryFallback = $fallbackEnabled && $fallbackConnectorId && $fallbackConnectorId != $currentConnectorId;
                    }
                }
            }
            
            if ($shouldTryFallback) {
                error_log("[FALLBACK] Primary connector failed (HTTP {$statusCode}). Attempting fallback connector ID: {$fallbackConnectorId}");
                
                // Set fallback mode flag to prevent player TTS reprocessing
                $GLOBALS["IN_FALLBACK_MODE"] = true;
                
                // Load and try fallback connector
                $connector = new LLMConnector();
                $fallbackConnectorData = $connector->getById($fallbackConnectorId);
                
                if ($fallbackConnectorData) {
                    $GLOBALS["CHIM_CORE_CURRENT_CONNECTOR_DATA"] = $fallbackConnectorData;
                    $connector->setOldGlobals($fallbackConnectorData);
                    
                    // Recursively retry with fallback (flag stays set throughout retry)
                    $result = call_llm_internal();
                    
                    // Clear fallback mode flag after retry completes
                    unset($GLOBALS["IN_FALLBACK_MODE"]);
                    
                    return $result;
                } else {
                    error_log("[FALLBACK] Fallback connector ID {$fallbackConnectorId} not found.");
                    unset($GLOBALS["IN_FALLBACK_MODE"]);
                }
            }
        }
        
        Logger::error("LLM provider error response code: $statusCode");
        return false;
    }

    // Read and process the response line by line
    $buffer="";
    $totalBuffer="";
    $breakFlag=false;
    $lineCounter=0;
    $fullContent="";
    $totalProcessedData="";
    $numOutputTokens = 0;
    $INCREMENTAL_SENTENCESIZE=20;

    // --- BEGIN CACHED CONNECTOR MODIFICATION ---
    // Check if the connector handles its own sentence splitting (e.g. simple format).
    // When true, bypass MINIMUM_SENTENCE_SIZE buffer to enable immediate sentence streaming.
    $connectorHandlesSentences = (method_exists($connectionHandler, 'handlesSentenceSplitting') &&
                                   $connectionHandler->handlesSentenceSplitting());
    // --- END CACHED CONNECTOR MODIFICATION ---

    while (true) {
        if ($breakFlag) {
            break;
        }

        $tmpData=$connectionHandler->process();
        if ($tmpData==-1 || (isset($GLOBALS["VALIDATE_LLM_OUTPUT_FNCT"]) && !$GLOBALS["VALIDATE_LLM_OUTPUT_FNCT"]($tmpData))) {
            Logger::warn("Invalid JSON Output.");
            $outputWasValid=false;
            $breakFlag=true;
        }
        else {
            $buffer.= $tmpData;
            $totalBuffer.=$buffer;
        }

        if ($connectionHandler->isDone()) {
            $breakFlag=true;
        }

        $buffer=strtr($buffer, array("\""=>"",".)"=>")."));

        // For narration events, allow immediate streaming without minimum buffer size
        // --- BEGIN CACHED CONNECTOR MODIFICATION ---
        // Also bypass minimum buffer for connectors that handle their own sentence splitting
        if ($gameRequest[0] !== "narration" && !$connectorHandlesSentences && strlen($buffer)<$INCREMENTAL_SENTENCESIZE) {	// Avoid too short buffers
            continue;
        }
        // --- END CACHED CONNECTOR MODIFICATION ---

        // disable streaming when translating to avoid sentence fragments getting translated
        if (Translation::isEnabled()) {
            continue;
        }

        $position = findFastSentencePosition($buffer);

        //echo "<$buffer>".PHP_EOL;
        // --- BEGIN CACHED CONNECTOR MODIFICATION ---
        // Connectors with internal sentence splitting: send immediately when any boundary found
        if (($position !== false) && ($gameRequest[0] === "narration" || $connectorHandlesSentences || $position>$INCREMENTAL_SENTENCESIZE)) {
        // --- END CACHED CONNECTOR MODIFICATION ---
            $extractedData = substr($buffer, 0, $position + 1);
            $remainingData = substr($buffer, $position + 1);
            $sentences=split_sentences_stream(cleanResponse($extractedData));
            $GLOBALS["DEBUG_DATA"]["response"][]=["raw"=>$buffer,"processed"=>implode("|", $sentences)];
            $GLOBALS["DEBUG_DATA"]["perf"][]=(microtime(true) - $startTime)." secs in openai stream";

            if ($gameRequest[0] != "diary") {
                returnLines($sentences);
                $INCREMENTAL_SENTENCESIZE=MINIMUM_SENTENCE_SIZE;
            } else { //why is the diary talking? is this correct?
                $talkedSoFar[md5(implode(" ", $sentences))]=implode(" ", $sentences);
            }

            //echo "$extractedData  # ".(microtime(true)-$startTime)."\t".strlen($finalData)."\t".PHP_EOL;  // Output
            $totalProcessedData.=$extractedData;
            $extractedData="";
            $buffer=$remainingData;
            //$user_input_after=$GLOBALS["db"]->fetchAll("select count(*) as N from eventlog where type='user_input' and ts>$gameRequest[1]"); //9.0ms
            $user_input_after=$GLOBALS["db"]->fetchAll("select rowid as N from eventlog where type='user_input' and ts>$gameRequest[1] LIMIT 1"); // 2.1ms, faster than count(*)
            if (isset($user_input_after[0]))
                if (isset($user_input_after[0]["N"]))

                    if ($user_input_after[0]["N"]>0) {
                        
                        Logger::info("Generation stopped because user_input. ".__FILE__." ".__LINE__." ".__FUNCTION__);
                        die('X-CUSTOM-CLOSE');
                        // Abort , user input detected
                    }

        }

    } // --- end while
    
    
    if (trim($buffer)) {
        Logger::info("REMAINING DATA <$buffer>");
        $sentences=split_sentences_stream(cleanResponse(trim($buffer)));

        if (Translation::isEnabled()) {
            Translation::translate($buffer);
            if (isset(Translation::$response)) {
                if (strlen(trim(Translation::$response)) > 0) {
                    Translation::$sentences = split_sentences_stream(cleanResponse(trim(Translation::$response)));
                    Translation::normalizeArrays($sentences, Translation::$sentences);
                }
            }
        }

        $GLOBALS["DEBUG_DATA"]["response"][]=["raw"=>$buffer,"processed"=>implode("|", $sentences)];
        $GLOBALS["DEBUG_DATA"]["perf"][]=(microtime(true) - $startTime)." secs in openai stream";
        if ($gameRequest[0] != "diary") {
            returnLines($sentences);
        } else {
            $talkedSoFar[md5(implode(" ", $sentences))]=implode(" ", $sentences);
        }
        $totalBuffer.=trim($buffer);
        $totalProcessedData.=trim($buffer);
    }

    if ($GLOBALS["FUNCTIONS_ARE_ENABLED"])  {
        $actions=$connectionHandler->processActions();
        if (isset($GLOBALS["action_post_process_fnct"])) {
            $actions=$GLOBALS["action_post_process_fnct"]($actions);
        }

        // Extnded version which is an array, so we can hook more than one function
        if (isset($GLOBALS["action_post_process_fnct_ex"]) && is_array($GLOBALS["action_post_process_fnct_ex"])) {
            foreach ($GLOBALS["action_post_process_fnct_ex"] as $postFilterFunc)
                $actions=$postFilterFunc($actions);
        }

        
        if (is_array($actions) && (sizeof($actions)>0)) {
            
            // ACTION POST-FILTER
            
            if ($GLOBALS["FUNCTIONS_ARE_ENABLED"]) {
                $copyActions=[];
                foreach ($actions as $n=>$action) {
                    $copyActions[$n]=$actions[$n];
                    $actionParts=explode("|",$action);
                    $actionParts2=explode("@",$actionParts[2]);
                    
                    if (isset($actionParts2[1])) {
                        // Parameter part 
                        if ($actionParts2[0]=="Attack"||$actionParts2[0]=="AttackHunt") {
                            // Lets polish the parameters
                            $localtarget=$actionParts2[1];
                            $mang1=explode(",",$localtarget);
                            $mang2=explode(" and ",$mang1[0]);
                            $mang3=explode("(",$mang2[0]);
                            $mang4=FindClosestNPCName($mang3[0]);

                            //$actions[$n]="{$actionParts[0]}|{$actionParts[1]}|Attack@{$mang3[0]}";

                            if ($mang4)
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|Attack@{$mang4}";
                            else
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|Attack@{$mang3[0]}";

                            error_log("[ACTION POSTFILTER Attack] $localtarget => {$mang3[0]} => $mang4");
                        } else if ($actionParts2[0]=="Inspect") {
                            // Lets polish the parammeters
                            $localtarget=$actionParts2[1];
                            $mang1=explode(",",$localtarget);
                            $mang2=explode(" and ",$mang1[0]);
                            $mang3=explode("(",$mang2[0]);
                            $mang4=FindClosestActorName($mang3[0]);

                            if ($mang4)
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|Inspect@{$mang4}";
                            else
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|Inspect@{$mang3[0]}";

                            error_log("[ACTION POSTFILTER GiveItemTo] $localtarget => {$mang3[0]} => $mang4");


                        } else if ($actionParts2[0]=="GiveItemTo") {
                            // Check if parameter is JSON (multi-param) - skip post-filtering for JSON
                            if (isset($actionParts2[1]) && substr(trim($actionParts2[1]), 0, 1) === '{') {
                                error_log("[ACTION POSTFILTER GiveItemTo] JSON parameter detected, skipping post-filter");
                                // Keep the action as-is for JSON parameters
                            } else {
                                // Legacy: polish the parameters for single-param format
                                $localtarget=$actionParts2[1];
                                $mang1=explode(",",$localtarget);
                                $mang2=explode(" and ",$mang1[0]);
                                $mang3=explode("(",$mang2[0]);
                                $mang4=FindClosestActorName($mang3[0]);
                                error_log("[ACTION POSTFILTER GiveItemTo] $localtarget => {$mang3[0]} => $mang4");

                                if ($mang4)
                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|GiveItemTo@{$mang4}";
                                else
                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|GiveItemTo@{$mang3[0]}";
                            }

                        } else if ($actionParts2[0]=="GiveGoldTo") {
                            // Check if parameter is JSON (multi-param) - validate gold amount
                            if (isset($actionParts2[1]) && substr(trim($actionParts2[1]), 0, 1) === '{') {
                                error_log("[ACTION POSTFILTER GiveGoldTo] JSON parameter detected, validating gold amount");
                                
                                // Parse JSON to extract amount
                                $jsonStr = trim($actionParts2[1]);
                                $requestedAmount = null;
                                
                                // Simple JSON parsing for amount
                                if (preg_match('/"amount"\s*:\s*(\d+)/', $jsonStr, $matches)) {
                                    $requestedAmount = intval($matches[1]);
                                }
                                
                                // Get available gold from NPC metadata
                                $availableGold = getGoldFromMetadata();
                                
                                if ($requestedAmount !== null && $requestedAmount > 0) {
                                    if ($requestedAmount > $availableGold) {
                                        // Cap the amount to available gold
                                        error_log("[ACTION POSTFILTER GiveGoldTo] Requested {$requestedAmount} gold but only have {$availableGold}, capping amount");
                                        $jsonStr = preg_replace('/"amount"\s*:\s*\d+/', '"amount":' . $availableGold, $jsonStr);
                                        $actions[$n] = "{$actionParts[0]}|{$actionParts[1]}|GiveGoldTo@{$jsonStr}";
                                    } else {
                                        // Amount is valid, keep as-is
                                        $actions[$n] = "{$actionParts[0]}|{$actionParts[1]}|GiveGoldTo@{$jsonStr}";
                                    }
                                } else {
                                    // No amount specified or invalid, keep as-is (plugin will handle error)
                                    $actions[$n] = "{$actionParts[0]}|{$actionParts[1]}|GiveGoldTo@{$jsonStr}";
                                }
                            } else {
                                // Legacy: polish the parameters for single-param format
                                $localtarget=$actionParts2[1];
                                $mang1=explode(",",$localtarget);
                                $mang2=explode(" and ",$mang1[0]);
                                $mang3=explode("(",$mang2[0]);
                                $mang4=FindClosestActorName($mang3[0]);
                                error_log("[ACTION POSTFILTER GiveGoldTo] $localtarget => {$mang3[0]} => $$mang4");

                                if ($mang4)
                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|GiveGoldTo@{$mang4}";
                                else
                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|GiveGoldTo@{$mang3[0]}";
                            }


                        }  else if ($actionParts2[0]=="TradeItems") {
                            // Lets polish the parammeters
                            $localtarget=$actionParts2[1];
                            $mang1=explode(",",$localtarget);
                            $mang2=explode(" and ",$mang1[0]);
                            $mang3=explode("(",$mang2[0]);

                            $mang4=FindClosestActorName($mang3[0]);

                            error_log("[ACTION POSTFILTER TradeItems] $localtarget => {$mang3[0]} => $mang4");

                            if ($mang4)
                                $destination=$mang4;
                            else
                                $destination=$mang3[0];

                            error_log("[ACTION POSTFILTER TradeItems] $localtarget => {$mang3[0]} => $destination");

                            if ($destination!=$GLOBALS["PLAYER_NAME"])
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|TradeItems@$destination";

                        }  else if ($actionParts2[0]=="Follow") {
                            // Lets polish the parammeters
                            $localtarget=$actionParts2[1];
                            $mang1=explode(",",$localtarget);
                            $mang2=explode(" and ",$mang1[0]);
                            $mang3=explode("(",$mang2[0]);
                            $mang4=FindClosestActorName($mang3[0]);

                            error_log("[ACTION POSTFILTER Follow] $localtarget =>  {$mang3[0]} => $mang4");

                            if ($mang4)
                                $destination=$mang4;
                            else
                                $destination=$mang3[0];
                            if ($destination!=$GLOBALS["PLAYER_NAME"])
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|Follow@$destination";
                            else
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|FollowPlayer@";
                            

                            error_log("[ACTION POSTFILTER Follow] $localtarget => {$mang3[0]} => $destination");

                        } else if ($actionParts2[0]=="TravelTo") {
                            // Lets polish the parammeters
                            $localtarget=$actionParts2[1];
                            $mang1=explode(",",$localtarget);
                            $mang2=explode(" and ",$mang1[0]);
                            $mang3=explode("(",$mang2[0]);
                            $mang4=explode("--",$mang3[0]);
                            
                            $destination=$mang4[0];

                            error_log("[ACTION POSTFILTER TravelTo]  $localtarget => {$mang4[0]} => $destination");

                            $destinationName=$GLOBALS["db"]->escape(trim($destination));
                            $dbDestination=$GLOBALS["db"]->fetchOne("SELECT name, similarity(name, '$destinationName') AS sim,formid FROM locations ORDER BY sim DESC LIMIT 1");
                            $dbDestinationRegion=$GLOBALS["db"]->fetchOne("SELECT name, similarity(region, '$destinationName') AS sim,formid FROM locations ORDER BY sim DESC LIMIT 1");

                            $contextDestinations=DataPosibleLocationsToGo();

                            if (in_array(trim($localtarget),$contextDestinations)) {
                                // Perfect match
                                error_log("[ACTION POSTFILTER TravelTo] Seems valid as-is (context destination): <$localtarget> => $localtarget");
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|TravelTo@$localtarget";

                            } else if (in_array($destination,$contextDestinations)) {
                                error_log("[ACTION POSTFILTER TravelTo] Seemd valid (context destination): $localtarget => $destination");
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|TravelTo@$destination";

                            } else {
                                if (isset($GLOBALS["NPC_ROLEMASTERED"]) && $GLOBALS["NPC_ROLEMASTERED"]) {
                                    if (stripos($destination,"home")===0) {
                                        // Rolemastered NPC wants to return back home
                                        $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|ReturnBackHome@"; 
                                        continue;

                                    }

                                } 
                                if (is_array($dbDestination) && isset($dbDestination["formid"])) {
                                    $destination=$dbDestination["formid"];
                                    error_log("[ACTION POSTFILTER TravelTo] found database entry for $localtarget => $destination => {$dbDestination["name"]}, similarity ({$dbDestination["sim"]})");
                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|TravelToRaw@$destination";    
                                
                                } else if (is_array($dbDestinationRegion) && isset($dbDestinationRegion["formid"])) {

                                    $destination=$dbDestinationRegion["formid"];
                                    error_log("[ACTION POSTFILTER TravelTo] found database (searching by region) entry for $localtarget => $destination => {$dbDestinationRegion["name"]}, similarity ({$dbDestinationRegion["sim"]})");
                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|TravelToRaw@$destination";    
                                } else if (stripos($destination,"outside")!==false) {
                                    $destination=DataLastKnownLocationHuman(true,false);
                                    error_log("[ACTION POSTFILTER TravelTo] reference to outside detected , $localtarget => $destination");
                                    
                                } else
                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|TravelTo@$destination";
                            }
                            
                        }  else if ($actionParts2[0]=="FollowPlayer") {
                            
                            error_log("[ACTION POSTFILTER FollowPlayer] Just Cleaning here");
                            $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|FollowPlayer@";
                            
                        }  else if ($actionParts2[0]=="ReturnBackHome") {
                            
                            error_log("[ACTION POSTFILTER ReturnBackHome] Just Cleaning here");
                            $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|ReturnBackHome@";
                            
                        }  else if ($actionParts2[0]=="Brawl") {
                            // Lets polish the parammeters
                            $localtarget=$actionParts2[1];
                            $mang1=explode(",",$localtarget);
                            $mang2=explode(" and ",$mang1[0]);
                            $mang3=explode("(",$mang2[0]);

                            $mang4=FindClosestActorName($mang3[0]);

                            error_log("[ACTION POSTFILTER Brawl] $localtarget => {$mang3[0]} => $mang4");

                            if ($mang4)
                                $finaltarget=$mang4;
                            else
                                $finaltarget=$mang3[0];

                            error_log("[ACTION POSTFILTER Brawl] $localtarget => {$mang3[0]} => $finaltarget");

                            $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|Brawl@$finaltarget";

                        } else if ($actionParts2[0]=="TakeGoldFromPlayer") {
                            // Lets polish the parammeters
                            $localtarget=$actionParts2[1];
                            $mang1=explode(",",$localtarget);
                            $mang2=explode(" and ",$mang1[0]);
                            $mang3=explode("(",$mang2[0]);

                            $mang4 = is_numeric(trim($mang3[0])) ? trim($mang3[0]) + 0 : null;

                            error_log("[ACTION POSTFILTER TakeGoldFromPlayer] $localtarget => {$mang3[0]} => $mang4");

                            if (!is_numeric($mang4)) {
                                // Try to figure out quantity from speech
                                $localNpc=$GLOBALS["db"]->escape($GLOBALS["HERIKA_NAME"]);
                                $qtyrecord=$GLOBALS["db"]->fetchOne("SELECT speech,(regexp_matches(speech, '\d+'))[1]::int AS quantity FROM public.speech 
                                WHERE listener = '$localNpc' OR speaker = '$localNpc' order by rowid desc LIMIT 100");
                                if (isset($qtyrecord["quantity"])) {
                                    $qty=trim($qtyrecord["quantity"]);
                                    error_log("[ACTION POSTFILTER TakeGoldFromPlayer] quantity found $qty");
                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|TakeGoldFromPlayer@$qty";
                                } else
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|TakeGoldFromPlayer@";
                            } else
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|TakeGoldFromPlayer@$mang4";

                        } else if ($actionParts2[0]=="SetCurrentTask") {
                            // Lets polish the parammeters
                            if (empty(trim($actionParts2[1]))) {
                                //$speech=implode(" ".$talkedSoFar); typo? if not, what does this do
                                //trying
                                $speech=implode(" ", $talkedSoFar);
                                $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|SetCurrentTask@$speech";
                                error_log("[ACTION POSTFILTER SetCurrentTask, using speech as parameter $speech] ");
                            
                            } else {
                                error_log("[ACTION POSTFILTER SetCurrentTask, using target as parameter {$actionParts2[1]}] ");
                            }

                        } else if ($actionParts2[0]=="PickupItem") {
                            // Parse item parameter - can be JSON or plain string
                            $itemParam = trim($actionParts2[1]);
                            
                            Logger::info("[PickupItem PostFilter] Raw LLM item parameter: '{$itemParam}'");
                            
                            // Check if parameter is JSON (multi-param format)
                            if (substr($itemParam, 0, 1) === '{') {
                                // JSON format: {"target":"","item":"0xFF00550D:Diamond"}
                                $params = json_decode($itemParam, true);
                                $itemParam = isset($params['item']) ? trim($params['item']) : '';
                                Logger::info("[PickupItem PostFilter] Extracted item from JSON: '{$itemParam}'");
                            }
                            
                            // If still empty, can't proceed
                            if (empty($itemParam)) {
                                Logger::warn("[PickupItem PostFilter] No item parameter provided, skipping");
                                continue;
                            }
                            
                            // Get the last infoitems context from eventlog (contains RefID:BaseID:ItemName)
                            $lastItemsContext = $GLOBALS["db"]->fetchOne(
                                "SELECT data FROM eventlog WHERE type='infoitems' ORDER BY localts DESC LIMIT 1"
                            );
                            
                            if ($lastItemsContext && !empty($lastItemsContext['data'])) {
                                Logger::info("[PickupItem PostFilter] Found infoitems in database");
                                // Extract items from context: "(items in range:0xRef:0xBase:Item1,0xRef2:0xBase2:Item2)"
                                // Use greedy match to capture everything including (STEALING) tags
                                if (preg_match('/\(items in range:(.+)\)/', $lastItemsContext['data'], $matches)) {
                                    $itemsStr = $matches[1];
                                    $itemsList = explode(',', $itemsStr);
                                    
                                    Logger::info("[PickupItem PostFilter] Found " . count($itemsList) . " items in database");
                                    Logger::info("[PickupItem PostFilter] First 3 items: " . implode(' | ', array_slice($itemsList, 0, 3)));
                                    
                                    $foundItem = false;
                                    
                                    // Check if LLM provided the RefID:ItemName format
                                    if (preg_match('/^0x[0-9A-Fa-f]+:/', $itemParam)) {
                                        // LLM provided "0xRefID:ItemName", extract the RefID
                                        $paramParts = explode(':', $itemParam, 2);
                                        $paramRefID = $paramParts[0];
                                        
                                        Logger::info("[PickupItem PostFilter] LLM provided RefID: {$paramRefID}, searching for exact match...");
                                        
                                        // Search for exact RefID match
                                        foreach ($itemsList as $itemEntry) {
                                            // Parse "RefID:BaseID:ItemName" from database
                                            $entryParts = explode(':', trim($itemEntry), 3);
                                            if (count($entryParts) >= 3) {
                                                $refID = $entryParts[0];
                                                $itemName = $entryParts[2];
                                                
                                                // Exact RefID match (case-insensitive)
                                                if (strcasecmp($refID, $paramRefID) === 0) {
                                                    // Send RefID:ItemName without (STEALING) tag to game
                                                    $cleanItemName = str_replace(' (STEALING)', '', $itemName);
                                                    $cleanFormat = "{$refID}:{$cleanItemName}";
                                                    Logger::info("[PickupItem PostFilter] EXACT MATCH FOUND! Sending: {$cleanFormat}");
                                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|PickupItem@{$cleanFormat}";
                                                    $foundItem = true;
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        if (!$foundItem) {
                                            Logger::warn("[PickupItem PostFilter] No exact match found for RefID: {$paramRefID}");
                                            Logger::warn("[PickupItem PostFilter] Item may have despawned or moved. Available RefIDs: " . 
                                                implode(', ', array_map(function($item) {
                                                    $parts = explode(':', trim($item), 3);
                                                    return $parts[0] ?? 'invalid';
                                                }, array_slice($itemsList, 0, 10))));
                                        }
                                    } else {
                                        // LLM provided just the item name, search by name
                                        foreach ($itemsList as $itemEntry) {
                                            $entryParts = explode(':', trim($itemEntry), 3);
                                            if (count($entryParts) >= 3) {
                                                $refID = $entryParts[0];
                                                $itemName = $entryParts[2];
                                                
                                                // Strip (STEALING) tag for comparison
                                                $cleanItemName = str_replace(' (STEALING)', '', $itemName);
                                                
                                                if (stripos($cleanItemName, $itemParam) !== false) {
                                                    // Send RefID:ItemName without (STEALING) tag to game
                                                    $displayFormat = "{$refID}:{$cleanItemName}";
                                                    $actions[$n]="{$actionParts[0]}|{$actionParts[1]}|PickupItem@{$displayFormat}";
                                                    $foundItem = true;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        }
                    }
                    
                }
            }
            
            // Log actions
            foreach ($actions as $n=>$singleaction) {
                $actionPart=explode("|",$singleaction); 
                $actionArg=explode("@",$actionPart[2]); 
                
                $GLOBALS["db"]->insert(
                    'actions_issued',
                    array(
                        'action' => $actionArg[0],
                        'fullcall' =>$singleaction,
                        'actorname'=> isset($GLOBALS["PATCH_ACTION_ALL_ACTORS"])?$GLOBALS["PATCH_ACTION_ALL_ACTORS"]:$actionPart[0],
                        'ts' => $gameRequest[1],
                        'gamets' => $gameRequest[2],
                        'localts'=>time(),
                        'original'=>$copyActions[$n]
                    )
                );


            }
            $GLOBALS["DEBUG_DATA"]["response"][]=$actions;
            
            // Log actions before echoing
            foreach ($actions as $action) {
                Logger::info("Echoing action to plugin: {$action}");
            }
            
            echo implode("\r\n", $actions)."\r\n";
            
            file_put_contents(__DIR__."/../log/output_to_plugin.log",implode("\r\n", $actions)."\r\n", FILE_APPEND | LOCK_EX);
            // Enforce flush output
            if (ob_get_level()) @ob_end_flush();
            @flush();

        }
    }
    
    if (isset($GLOBALS["CLEAN_CONTEXT_FOCUS_CHAT"]) && $GLOBALS["CLEAN_CONTEXT_FOCUS_CHAT"]) {
        ;//Was a faked stream
    } else 
        $connectionHandler->close('standard');
    //fwrite($fileLog, $totalBuffer . PHP_EOL); // Write the line to the file with a line break // DEBUG CODE


    return $outputWasValid;
}

function AddFirstTimeMet($followerName,$momentum,$gamets,$ts) {

    $fn=$GLOBALS["db"]->escape($followerName);
    
    // Check if already recorded - with error handling
    $already = @$GLOBALS["db"]->fetchAll("select 1 as t from memory where event='first_met' and message like '%met {$fn}%'");
    if ($already === false) {
        Logger::warn("[AddFirstTimeMet] Query to memory table failed for follower: {$followerName}");
        return;
    }
    
    if (is_array($already) && sizeof($already)>0) {
        // Already exists;
        return;
    }

    // Get first interaction timestamp - with error handling
    $realFirst = @$GLOBALS["db"]->fetchAll("SELECT gamets,convert_gamets2skyrim_date(gamets) as sk_date,ts,localts FROM speech where companions ilike '%$fn%' order by rowid asc limit 1 offset 0");
    
    if ($realFirst === false) {
        Logger::warn("[AddFirstTimeMet] Query to speech table failed for follower: {$followerName}");
        return;
    }

    if (is_array($realFirst) && sizeof($realFirst)>0) {
        $gamets=$realFirst[0]["gamets"];
        $ts=$realFirst[0]["ts"];
        $momentum=$realFirst[0]["localts"];
        $sk_date=$realFirst[0]["sk_date"]; // game timestamp converted to skyrim date YYYY-MM-DD HH:MM:SS

        logMemory($GLOBALS["PLAYER_NAME"], $followerName,
        "(Important note: {$GLOBALS["PLAYER_NAME"]} met {$followerName} for the first time on {$sk_date}. This is an important event, so use tag #FirstTimeMet.)",
        $momentum, $gamets,'first_met',$ts);
    }


}


function DataRetrieveFirstTimeMet($s_player_name, $s_npc_name) {
    global $db;

	$s_res = "";

	if ((strlen($s_player_name)>0) && (strlen($s_npc_name)>0) && ($s_player_name != $s_npc_name)) {
        if (($s_npc_name == "Herika") || ($s_player_name == "Herika")) { // Herika easter egg
            return "{$s_player_name} met {$s_npc_name} for the first time on 0199-04-26, 15:36:00, years ago.";
        }
		$s_player = $db->escape($s_player_name);
		$s_npc = $db->escape($s_npc_name);

        $crt_gamets = intval(DataLastKnownGameTS());

		$db_rec = $db->fetchAll("SELECT speaker,listener,
			message,gamets,momentum,rowid  
			FROM memory 
			WHERE event = 'first_met' AND gamets > 0 AND
			((speaker = '{$s_player}' AND listener = '$s_npc') OR
			(listener = '{$s_player}' AND speaker = '$s_npc'))
			ORDER BY rowid ASC LIMIT 1; ");
            
        $b_found_memory = (is_array($db_rec) && sizeof($db_rec)>0); 
        
        if (!$b_found_memory) { // check conversations
            $gts_met = GetFirstInteraction($s_player, $s_npc); 
        } else {
			$gts_met = intval($db_rec[0]['gamets'] ?? 0);
		}

        if (($gts_met > 0) && ($crt_gamets > $gts_met)) {
            $gts_ago = $crt_gamets - $gts_met;
            $s_met = convert_gamets2skyrim_date($gts_ago);
			$hours_ago = convert_gamets2hours($gts_ago);
            
			if ($hours_ago < 49)
				$s_time_ago = "{$hours_ago} hours ago";
			else {
				$days_ago = intval($hours_ago / 24); 
				$s_time_ago = "{$days_ago} days ago";
			}
			$s_res = "{$s_player_name} met {$s_npc_name} for the first time on {$s_met}, {$s_time_ago}.";

        } else { 
			Logger::info("DataRetrieveLastMet: NO match found");
			//$s_res = "There is no record of when {$s_player_name} met {$s_npc_name}.";
		}
	}
	return $s_res;
}

function GetFirstTimeMetMemory($s_player_name, $s_npc_name) {
    global $db;
    $i_res = 0;

	if ((strlen($s_player_name)>0) && (strlen($s_npc_name)>0) && ($s_player_name != $s_npc_name)) {
		$s_player = $db->escape($s_player_name);
		$s_npc = $db->escape($s_npc_name);

        //$crt_gamets = intval(DataLastKnownGameTS());

		$db_rec = $db->fetchAll("SELECT speaker,listener,
			message,gamets,momentum,rowid  
			FROM memory 
			WHERE event = 'first_met' AND gamets > 0 AND
			((speaker = '{$s_player}' AND listener = '$s_npc') OR
			(listener = '{$s_player}' AND speaker = '$s_npc'))
			ORDER BY rowid ASC LIMIT 1; ");
            
        $b_found_memory = (is_array($db_rec) && sizeof($db_rec)>0); 
        
        if ($b_found_memory) { 
			$i_res = intval($db_rec[0]['gamets'] ?? 0);
		}

	}
	return $i_res;
}

function GetFirstTimeMet($s_player_name, $s_npc_name) {
    $i_res = 0;

	if ((strlen($s_player_name)>0) && (strlen($s_npc_name)>0) && ($s_player_name != $s_npc_name)) {
        
        $i_res = GetFirstTimeMetMemory($s_player_name, $s_npc_name); 

        if ($i_res <= 0) { // check conversations
            $i_res = GetFirstInteraction($s_player_name, $s_npc_name); 
		}
	}
	return $i_res;
}

function GetLastInteraction($s_player_name, $s_npc_name) {
    global $db;
	$i_res = 0;
	if ((strlen($s_player_name)>0) && (strlen($s_npc_name)>0) && ($s_player_name != $s_npc_name)) {
		$s_player = $db->escape($s_player_name);
		$s_npc = $db->escape($s_npc_name);
		$db_rec = $db->fetchAll("SELECT gamets FROM speech 
        WHERE (gamets > 0) AND 
          ((speaker = '{$s_player}' AND listener = '{$s_npc}') OR 
          (listener = '{$s_player}' AND speaker = '{$s_npc}'))  
        ORDER BY gamets DESC LIMIT 1 ");
		if (is_array($db_rec) && sizeof($db_rec)>0) {
			$i_res = intval($db_rec[0]['gamets']);
		}
	}
	return $i_res;
}

function GetLastSpeechTs() {
    global $db;
    $i_res=0;
	$db_rec = $db->fetchAll("SELECT gamets as gamets FROM speech 
        WHERE (gamets > 0) ORDER BY gamets DESC LIMIT 1 ");
	if (is_array($db_rec) && sizeof($db_rec)>0) {
		$i_res = intval($db_rec[0]['gamets']);
	}
	
	return $i_res;
}

function GetFirstInteraction($s_player_name, $s_npc_name) {
    global $db;
	$i_res = 0;
	if ((strlen($s_player_name)>0) && (strlen($s_npc_name)>0) && ($s_player_name != $s_npc_name)) {
		$s_player = $db->escape($s_player_name);
		$s_npc = $db->escape($s_npc_name);
		$db_rec = $db->fetchAll("SELECT gamets FROM speech 
        WHERE (gamets > 0) AND 
          ((speaker = '{$s_player}' AND listener = '{$s_npc}') OR 
          (listener = '{$s_player}' AND speaker = '{$s_npc}'))  
        ORDER BY gamets ASC LIMIT 1 ");
		if (is_array($db_rec) && sizeof($db_rec)>0) {
			$i_res = intval($db_rec[0]['gamets']);
		}
	}
	return $i_res;
}

function DataRetrieveLastTimeTalk($s_player_name, $s_npc_name) {
    global $db;

	$s_res = "";

	if ((strlen($s_player_name)>0) && (strlen($s_npc_name)>0) && (!($s_player_name == 'The Narrator')) && (!($s_npc_name == 'The Narrator'))) {
		$crt_gamets = intval(DataLastKnownGameTS());
		$gts_met = GetLastInteraction($s_player_name, $s_npc_name); 
		if ($gts_met > 0) {
			$s_date = gamets2str_format_date($gts_met, $dt_format = 'Y-m-d'); 
			$gts_ago = $crt_gamets - $gts_met;
			$hours_ago = convert_gamets2hours($gts_ago);
			if ($hours_ago > 3) {
				if ($hours_ago < 48) {
					$s_res = "{$s_player_name} and {$s_npc_name} last spoke {$hours_ago} hours ago.";
				} else {
					$days_ago = convert_gamets2days($gts_ago);
					if ($days_ago < 31) {
						$s_res = "{$s_player_name} and {$s_npc_name} last spoke {$days_ago} days ago.";
					} else {
						$months_ago = intval($days_ago * 0.03333333);
						if ($months_ago < 12) {
							$s_res = "{$s_player_name} and {$s_npc_name} last spoke {$months_ago} months ago on {$s_date}.";
						} else {
							$s_res = "{$s_player_name} and {$s_npc_name} last spoke long time ago on {$s_date}.";
						}
					}
				}	
			} else {
                Logger::debug("DataRetrieveLastTimeTalk: {$s_player_name} and {$s_npc_name} spoke recently");
				//$s_res = "{$s_player_name} and {$s_npc_name} spoke recently.";
			}
		} else { 
			Logger::debug("DataRetrieveLastTimeTalk: NO match found for {$s_player_name} - {$s_npc_name}");
			//$s_res = "There is no record of when {$s_player_name} and {$s_npc_name} last spoke.";
		}
	}
	return $s_res;
}


function GetAnimationHex($mood)
{

    //error_log("Getting animation for mood: $mood");
    $ANIMATIONS=[
        "ArmsCrossed"=>"IdleExamine",        // Arms crossed
        "PointClose"=>"IdlePointClose",
        "HandsBehindBack"=>"IdleHandsBehindBack",    // 000B240A ? // Arms behind back
        //"DrawAttention"=>"0x0006FF15",     // Continous
        //"Cheer"=>"0x00066374",             // Continous
        "ApplauseSarcastic"=>"IdleApplaudSarcastic",  // Continous
        "WaveHand"=>"IdleWave",
        "Nervous"=>"IdleNervous",
        "ArmsRaised"=>"IdleSurrender",
        "NervousDialogue"=>"IdleDialogueMovingTalkA",
        "NervousDialogue1"=>"IdleDialogueMovingTalkB",
        "NervousDialogue2"=>"IdleDialogueMovingTalkC",
        "NervousDialogue3"=>"IdleDialogueMovingTalkD",
        "Cheer"=>"SpectatorCheer",
        "ComeThisWay"=>"IdleComeThisWay",
        "SarcasticMove"=>"IdleDialogueExpressiveStart",
        "Applause1"=>"IdleApplaud2",
        "Applause2"=>"IdleApplaud3",
        "Applause3"=>"IdleApplaud4",
        "Applause4"=>"IdleApplaud5",
        "DrinkPotion"=>"IdleDrinkPotion",        // Don't use while talking
        "PointFar"=>"IdlePointFar_01",
        "PointFar2"=>"IdlePointFar_02",
        "GiveSomething"=>"IdleGive",
        "TakeSomething"=>"IdleTake",
        "Salute"=>"IdleSalute",
        "CleanSweat"=>"IdleWipeBrow",
        "NoteRead"=>"IdleNoteRead",
        "LookFar"=>"IdleLookFar",
        "Laugh"=>"IdleLaugh",
        "CleanSword"=>"IdleCleanSword",
        "WarmArms"=>"IdleWarmArms",
        "Positive"=>"LooseDialogueResponsePositive",
        "Negative"=>"LooseDialogueResponseNegative",
        "HappyDialogue"=>"IdleDialogueHappyStart",
        "AngryDialogue"=>"IdleDialogueAngryStart",
        "Agitated"=>"IdleCiceroAgitated",
        "HandOnChinGesture"=>"IdleDialogueHandOnChinGesture",
        
    ];
    
    $animationsDb=$GLOBALS["db"]->fetchAll("select animations from animations_custom where mood ilike '%$mood%'");
    foreach ($animationsDb as $an) {
        $candidates=explode(",", $an["animations"]);
        if (is_array($candidates)) {
            error_log("[ANIMATION] {$an["animations"]}");
            return $candidates[array_rand($candidates)];
        }

    }

    $animationsDb=$GLOBALS["db"]->fetchAll("select animations from animations where mood ilike '%$mood%'");
    foreach ($animationsDb as $an) {
        $candidates=explode(",", $an["animations"]);
        if (is_array($candidates)) {
            // error_log("[ANIMATION] {$an["animations"]}");
            return $candidates[array_rand($candidates)];
        }

    }


    if ($mood=="sarcastic") {
        return array_rand(array_flip([$ANIMATIONS["SarcasticMove"],$ANIMATIONS["CleanSweat"],$ANIMATIONS["Agitated"],$ANIMATIONS["ApplauseSarcastic"]]), 1);
        
        
    } else if ($mood=="sassy") {
        return array_rand(array_flip([$ANIMATIONS["SarcasticMove"],$ANIMATIONS["CleanSweat"],$ANIMATIONS["Agitated"],$ANIMATIONS["ApplauseSarcastic"]]), 1);
        
        
    } else if ($mood=="sardonic") {
        return array_rand(array_flip([$ANIMATIONS["SarcasticMove"],$ANIMATIONS["CleanSweat"],$ANIMATIONS["Agitated"],$ANIMATIONS["ApplauseSarcastic"]]), 1);
        
        
    } else if ($mood=="irritated") {
        return array_rand(array_flip([$ANIMATIONS["PointClose"],$ANIMATIONS["Negative"],$ANIMATIONS["AngryDialogue"]]), 1);
       
        
    } else if ($mood=="mocking") {
        return array_rand(array_flip([$ANIMATIONS["Applause1"],$ANIMATIONS["Applause2"],$ANIMATIONS["Applause3"],$ANIMATIONS["Applause4"]]), 1);
        
        
    } else if ($mood=="playful") {
        return array_rand(array_flip([$ANIMATIONS["Cheer"],$ANIMATIONS["HappyDialogue"],$ANIMATIONS["Positive"]]), 1);
            
    } else if ($mood=="teasing") {
        return array_rand(array_flip([$ANIMATIONS["NervousDialogue"],$ANIMATIONS["NervousDialogue1"],$ANIMATIONS["NervousDialogue2"],$ANIMATIONS["NervousDialogue3"]]), 1);
        
        
    } else if ($mood=="smug") {
        return $ANIMATIONS["Nervous"];
        
        
    } else if ($mood=="amused") {
        return $ANIMATIONS["ArmsRaised"];
        
    } else if ($mood=="smirking") {
        return $ANIMATIONS["Nervous"];
    
        
    } else if ($mood=="serious") {
        return array_rand(array_flip([$ANIMATIONS["CleanSweat"],$ANIMATIONS["PointClose"],$ANIMATIONS["HandOnChinGesture"]]), 1);
    
        
    } else if ($mood=="firm") {
        return array_rand(array_flip([$ANIMATIONS["CleanSweat"],$ANIMATIONS["PointClose"],$ANIMATIONS["HandOnChinGesture"]]), 1);
    
        
    } else if ($mood=="neutral") {
        return array_rand(array_flip([$ANIMATIONS["HappyDialogue"]]), 1);
        
        
    } else if ($mood=="drunk") {
        // No animation :(
        Logger::info("Using filter for mood drunk");
        $GLOBALS["TTS_FFMPEG_FILTERS"]["tempo"]='atempo=0.65';
        return "DrunkStart";
        
    } else if ($mood=="sober") {

        Logger::info("Resetting mood drunk.");
        
        return "DrunkStop";
        
    } else if ($mood=="high") {
        // No animation :(
        $GLOBALS["TTS_FFMPEG_FILTERS"]["tempo"]='atempo=1.45';
        
    } 
                      
    
    //error_log("Getting animation for mood: $mood, no result found");
    return "";

}


function GetExpression($mood) {
    $EXPRESSIONS=[
     "DialogueAnger",    "DialogueFear",    "DialogueHappy",     "DialogueSad",
     "DialogueSurprise", "DialoguePuzzled", "DialogueDisgusted", "MoodNeutral",
     "MoodAnger",        "MoodFear",        "MoodHappy",        "MoodSad",
     "MoodSurprise",    "MoodPuzzled",    "MoodDisgusted",    "CombatAnger",
     "CombatShout"
     ];
     
     $result="";
     if ($mood=="sarcastic") {
        $result= array_rand(array_flip(["DialoguePuzzled"]), 1);
         
         
     } else if ($mood=="sassy") {
        $result= array_rand(array_flip(["DialoguePuzzled"]), 1);
         
         
     } else if ($mood=="sardonic") {
        $result= array_rand(array_flip(["DialoguePuzzled"]), 1);
         
         
     } else if ($mood=="irritated") {
        $result= array_rand(array_flip(["DialogueAnger"]), 1);
        
         
     } else if ($mood=="mocking") {
        $result= array_rand(array_flip(["DialogueHappy"]), 1);
         
         
     } else if ($mood=="playful") {
        $result= array_rand(array_flip(["DialogueHappy"]), 1);
             
     } else if ($mood=="teasing") {
        $result= array_rand(array_flip(["DialogueSurprise"]), 1);
         
         
     } else if ($mood=="smug") {
        $result= array_rand(array_flip(["DialogueAnger"]), 1);
         
         
     } else if ($mood=="amused") {
        $result= array_rand(array_flip(["DialogueSurprise"]), 1);
         
     } else if ($mood=="smirking") {
        $result= array_rand(array_flip(["DialogueHappy"]), 1);
     
         
     } else if ($mood=="serious") {
        $result= array_rand(array_flip(["MoodNeutral"]), 1);
     
         
     } else if ($mood=="firm") {
        $result= array_rand(array_flip(["MoodNeutral"]), 1);
     
         
     } if ($mood=="neutral") {
        $result= array_rand(array_flip(["MoodNeutral"]), 1);
         
         
     }
                             
     
     $GLOBALS["PATCH_ORIGINAL_MOOD_ISSUED"]=$mood;
     return $result;
     
 }

 

function isOk($arr) {
    if (is_array($arr))
        if (sizeof($arr)>0)
            return true;

    return false;
}

function getArrayKey($arr,$key) {
    if (is_array($arr))
        if (isset($arr[$key]))
            return $arr[$key];

    return false;
}

function profile_exists($npcname) {
    $path = dirname((__FILE__)) . DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR;
    $newConfFile=md5($npcname);
    return file_exists($path . "conf".DIRECTORY_SEPARATOR."conf_$newConfFile.php");
}

function createProfile($npcname, $FORCE_PARMS = [], $overwrite = false, $baseprofile = '')
{
    // This should be done at NpcMaster::createProfile
    global $db;

    if ($npcname == "The Narrator")   // Refuse to add Narrator [review this]
        return;

    $path = dirname((__FILE__)) . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR;
    $newConfFile = md5($npcname);

    $codename = npcNameToCodename($npcname);
    $baseprofileName = npcNameToCodename($baseprofile);

    $npcMaster = new NpcMaster();
    $currentNpcData = $npcMaster->getByName($npcname);

    $EMPTY_PROFILE=false;

    if (!$currentNpcData || $overwrite ) {
        error_log("Creating/overwriting:$overwrite  profile for $npcname");
        //sleep (1);
        if (empty($GLOBALS["CORE_LANG"])) {
            $npcTemlate = $db->fetchAll("SELECT core FROM combined_bio_templates where npc_name='$codename'");
            // Query for new HERIKA fields (bio tables)
            $npcNewFields = $db->fetchAll("SELECT npc_static_bio, personality, appearance, relationships, occupation, skills, speechstyle, goals, oghma_knowledge_tags, voiceid, gender, race, refid FROM combined_bio_templates where npc_name='$codename'");
        } else {
            Logger::info("Using npc_templates_trl, name_trl='$codename' and lang='{$GLOBALS["CORE_LANG"]}'");
            $npcTemlate = $db->fetchAll("SELECT npc_pers FROM npc_templates_trl where name_trl='$codename' and lang='{$GLOBALS["CORE_LANG"]}'");
            if (!isset($npcTemlate[0])) {
                Logger::info("No trl found, using standard template");
                $npcTemlate = $db->fetchAll("SELECT core FROM combined_bio_templates where npc_name='$codename'");
                // Query for new HERIKA fields (bio tables)
                $npcNewFields = $db->fetchAll("SELECT npc_static_bio, personality, appearance, relationships, occupation, skills, speechstyle, goals, oghma_knowledge_tags, voiceid, gender, race, refid FROM combined_bio_templates where npc_name='$codename'");
            } else {
                // For translated templates, set empty new fields for now
                $npcNewFields = [0 => ['npc_background' => '', 'npc_personality' => '', 'npc_appearance' => '', 'npc_relationships' => '', 'npc_occupation' => '', 'npc_skills' => '', 'npc_speechstyle' => '', 'npc_goals' => '']];
            }
        }

        // 3. Extract the bracketed portion and convert it to the "stripped" version
        //    e.g. Bofesar [Whiterun Guard] -> whiterun_guard
        $bracketMatch = '';
        if (preg_match('/\[(.*?)\]/', $npcname, $matches)) {
            $bracketMatch = trim($matches[1]);    // remove possible extra spaces
            $bracketMatch = strtolower($bracketMatch);
            $bracketMatch = str_replace(' ', '_', $bracketMatch);
        }

        // Original logic for pulling from database
        if (isset($npcTemlate[0]) && is_array($npcTemlate[0])) {
                error_log("Creating from template ");

            // Build core from template core (or npc_pers in translated case)
            $coreFull = '';
            if (array_key_exists('core', $npcTemlate[0])) {
                $coreFull = trim((string)$npcTemlate[0]['core']);
            } elseif (array_key_exists('npc_pers', $npcTemlate[0])) {
                $coreFull = trim((string)$npcTemlate[0]['npc_pers']);
            }
            if ($coreFull === '') {
                // Fallback: minimal core
                $coreFull = trim($npcname);
            }

            $npcMaster->create([

                    "npc_name" => $npcname,
                    'npc_static_bio' => $npcNewFields[0]["npc_static_bio"] ?? '',
                    'personality' => $npcNewFields[0]["personality"] ?? '',
                    'core' => $coreFull,
                    'relationships' => $npcNewFields[0]["relationships"] ?? '',
                    'occupation' => $npcNewFields[0]["occupation"] ?? '',
                    'appearance' => $npcNewFields[0]["appearance"] ?? '',
                    'skills' => $npcNewFields[0]["skills"] ?? '',
                    'speechstyle' => $npcNewFields[0]["speechstyle"] ?? '',
                    'goals' => $npcNewFields[0]["goals"] ?? '',
                    'oghma_knowledge_tags' => $npcNewFields[0]["oghma_knowledge_tags"] ?? ''

                ]
            );

            // RealNamesExtended support for generic npcs
        } elseif (!empty($bracketMatch)) {
            
            // Query for new HERIKA fields for bracket match (bio tables)
            $npcNewFields2 = $db->fetchAll("SELECT npc_static_bio, personality, appearance, relationships, occupation, skills, speechstyle, goals, oghma_knowledge_tags, voiceid, gender, race, refid FROM combined_bio_templates WHERE npc_name='" . $db->escape($bracketMatch) . "'");
            $npcCore2 = $db->fetchAll("SELECT core FROM combined_bio_templates WHERE npc_name='" . $db->escape($bracketMatch) . "'");

            if (!empty($npcNewFields2[0])) {
                error_log("Creating from template bracketMatch");
                // Build core from template core
                $coreFull2 = '';
                if (!empty($npcCore2[0]) && array_key_exists('core', $npcCore2[0])) {
                    $coreFull2 = trim((string)$npcCore2[0]['core']);
                }
                if ($coreFull2 === '') { $coreFull2 = trim($npcname); }

                $npcMaster->create([
                        "npc_name" => $npcname,
                        'npc_static_bio' => $npcNewFields2[0]["npc_static_bio"] ?? '',
                        'personality' => $npcNewFields2[0]["personality"] ?? '',
                        'core' => $coreFull2,
                        'relationships' => $npcNewFields2[0]["relationships"] ?? '',
                        'occupation' => $npcNewFields2[0]["occupation"] ?? '',
                        'appearance' => $npcNewFields2[0]["appearance"] ?? '',
                        'skills' => $npcNewFields2[0]["skills"] ?? '',
                        'speechstyle' => $npcNewFields2[0]["speechstyle"] ?? '',
                        'goals' => $npcNewFields2[0]["goals"] ?? '',
                        'oghma_knowledge_tags' => $npcNewFields2[0]["oghma_knowledge_tags"] ?? ''
                    ]
                );
            } else {
                error_log("Creating initial empty profile");
                $npcMaster->create([
                        "npc_name" => $npcname
                    ]
                );
            }
        } else {
            error_log("Creating initial empty profile");
            $npcMaster->create([
                    "npc_name" => $npcname
                ]
            );
            $EMPTY_PROFILE=true;
            $newData = $npcMaster->GetByName($npcname);
            

        }

        // Voice
        //TODO i dont think these ids are used to set the voice in this code - not sure i follow it [needs review]
        // $voiceRow = $db->fetchAll("SELECT voiceid FROM combined_bio_templates WHERE npc_name='$codename'");
        // $melottsid = $db->fetchAll("SELECT melotts_voiceid FROM combined_npc_templates WHERE npc_name='$codename'");
        // $xvasynthid = $db->fetchAll("SELECT xvasynth_voiceid	 FROM combined_npc_templates WHERE npc_name='$codename'");

        // $cn = $db->escape("Voicetype/$codename");
        // $vtype = $db->fetchAll("select value from conf_opts where id='$cn'");
        // $voicetypeString = (isOk($vtype)) ? $vtype[0]["value"] : null;
        // if ($voicetypeString) {
            // $voicetype = explode("\\", $voicetypeString);
        // } else {
        //     $voicetype = null;
        // }

        // $voicelogic = $GLOBALS["TTS"]["XTTSFASTAPI"]["voicelogic"];
        //use the Nametype conf opts to latch onto the character name while still being able to pull the correct voicetype[3]
        // if ($voicelogic === "voicetype") {
            //$codename = npcNameToCodename($npcname);
            //$cn = $db->escape("Nametype/$codename");
            //$vtype = $db->fetchAll("select value from conf_opts where id='$cn'");
            //$voicetypeString = (isOk($vtype)) ? $vtype[0]["value"] : null;
            //if ($voicetypeString) {
                //$voicetype = explode("\\", $voicetypeString);
            //}
        //}
        // Legacy per-engine voice ids (deprecated in favor of unified voiceid)
        // $melottsid = $db->fetchAll("SELECT melotts_voiceid FROM combined_npc_templates WHERE npc_name='$codename'");
        // $xvasynthid = $db->fetchAll("SELECT xvasynth_voiceid FROM combined_npc_templates WHERE npc_name='$codename'");

        // Populate voiceid for core_npc_master using XTTS-style logic with template fallback
        $voiceid = "";

        // 1) Prefer explicit template voiceid if present
        if (isset($npcNewFields) && isset($npcNewFields[0]["voiceid"]) && !empty($npcNewFields[0]["voiceid"])) {
            $voiceid = trim($npcNewFields[0]["voiceid"]);
        } else if (isset($npcNewFields2) && isset($npcNewFields2[0]["voiceid"]) && !empty($npcNewFields2[0]["voiceid"])) {
            $voiceid = trim($npcNewFields2[0]["voiceid"]);
        }

        // 2) Else derive from conf_opts Nametype/Voicetype path (old XTTS behavior)
        if (empty($voiceid)) {
            $codename = npcNameToCodename($npcname);
            $cnVoicetype = $db->escape("Voicetype/$codename");
            $cnNametype  = $db->escape("Nametype/$codename");

            $row = $db->fetchAll("select value from conf_opts where id='$cnVoicetype' limit 1");
            if (!is_array($row) || sizeof($row) == 0) {
                $row = $db->fetchAll("select value from conf_opts where id='$cnNametype' limit 1");
            }

            if (is_array($row) && sizeof($row) > 0 && isset($row[0]["value"])) {
                $parts = explode("\\", $row[0]["value"]);
                if (sizeof($parts) >= 4 && !empty($parts[3])) {
                    $voiceid = strtolower($parts[3]);
                }
            }
        }

        // 3) Assign (may remain empty if nothing found)
        $currentData = $npcMaster->GetByName($npcname);
        $currentData["voiceid"] = $voiceid;

        $currentData['metadata'] = json_encode([]);
        $currentData['extended_data'] = json_encode(["chim_core_migrated" => 2]);
        $currentData['profile_id'] = 1; // Default profile
        $currentData['md5'] = md5($currentData["npc_name"]);
        $currentData['gamets_last_updated'] = $GLOBALS["gameRequest"][2];

        if ($EMPTY_PROFILE) {
            error_log("[CREATEPROFILE] Created initial empty profile");
        }

        $npcMaster->updateByArray($currentData);
        return 1;
    }
    return 2;
}

function getConfFileFor($npcname) {

    global $db; 
    $path = dirname((__FILE__)) . DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR;
    $newConfFile=md5($npcname);

    
    return $path . "conf".DIRECTORY_SEPARATOR."conf_$newConfFile.php";
    
}

function buildDynamicBiography(array $FOLLOWER_CONF) {
    /**
     * Build dynamic biography from new HERIKA fields, with fallback to legacy HERIKA_DYNAMIC
     * @return string The dynamic biography content
     */
    $dynamicBio = '';
    
    // Helper function to get item description from combined view
    $getItemDescription = function($itemName, $baseid = null) {
        global $db;
        
        // Try by baseid first if provided
        if (!empty($baseid)) {
            $escapedBaseid = $db->escape($baseid);
            $result = $db->fetchAll("SELECT description FROM combined_descriptions WHERE baseid='{$escapedBaseid}' LIMIT 1");
            if (!empty($result) && !empty($result[0]['description'])) {
                return $result[0]['description'];
            }
        }
        
        // Fallback to name-based search
        if (!empty($itemName) && $itemName != '<Missing Name>') {
            $escapedName = $db->escape($itemName);
            $result = $db->fetchAll("SELECT description FROM combined_descriptions WHERE LOWER(name) = LOWER('{$escapedName}') LIMIT 1");
            if (!empty($result) && !empty($result[0]['description'])) {
                return $result[0]['description'];
            }
        }
        
        return null;
    };
    
    // List of new HERIKA fields to include
    $herikaFields = [
        'HERIKA_BACKGROUND' => 'Basic Summary',
        'HERIKA_PERSONALITY' => 'Personality', 
        'HERIKA_APPEARANCE' => 'Appearance',
        'HERIKA_RELATIONSHIPS' => 'Relationships',
        'HERIKA_OCCUPATION' => 'Occupation',
        'HERIKA_SKILLS' => 'Skills',
        'HERIKA_SPEECHSTYLE' => 'Speech Style',
        'HERIKA_GOALS' => 'Goals'
    ];
    $SKILLS_ADD="";
    $EQUIPMENT_ADD="";
    $TARGET_EQUIPMENT_ADD="";
    $STATS_ADD="";
    $SPELLS_ADD="";
    
    $npcMaster=new NpcMaster();
    $currentNpcData=$npcMaster->getByName($FOLLOWER_CONF["HERIKA_NAME"]);
    $metaData=$npcMaster->getMetaData($currentNpcData);
    
    if (isset($metaData["skills"])) {
        // Convert numeric skills to descriptive levels, grouped by category
        $skillCategories = [
            'Combat' => ['archery', 'block', 'onehanded', 'twohanded', 'heavyarmor', 'lightarmor'],
            'Magic' => ['conjuration', 'destruction', 'illusion', 'restoration', 'alteration', 'enchanting'],
            'Stealth' => ['sneak', 'pickpocket', 'lockpicking', 'speechcraft'],
            'Crafting' => ['smithing', 'alchemy']
        ];
        
        $formattedSkills = "\n\nSkill Proficiencies:";
        
        foreach ($skillCategories as $category => $skillNames) {
            $categorySkills = [];
            foreach ($skillNames as $skillName) {
                if (isset($metaData["skills"][$skillName])) {
                    $skillValue = $metaData["skills"][$skillName];
                    $level = '';
                    if ($skillValue >= 100) {
                        $level = 'Master';
                    } elseif ($skillValue >= 75) {
                        $level = 'Expert';
                    } elseif ($skillValue >= 50) {
                        $level = 'Adept';
                    } elseif ($skillValue >= 25) {
                        $level = 'Apprentice';
                    } else {
                        $level = 'Novice';
                    }
                    
                    // Always show skills, including Novice
                    $categorySkills[] = ucfirst($skillName) . " (" . $level . ")";
                }
            }
            
            if (!empty($categorySkills)) {
                $formattedSkills .= "\n  • {$category}: " . implode(", ", $categorySkills);
            }
        }
        
        $SKILLS_ADD = $formattedSkills;
    } 
    
    // Add NPC's own equipment (skip for The Narrator - they don't need equipment context)
    if ($FOLLOWER_CONF["HERIKA_NAME"] !== "The Narrator" && isset($metaData["equipment"]) && is_array($metaData["equipment"])) {
        $equipmentParts = [];
        $describedBaseids = []; // Track which baseids we've already described
        $slots = [
            'helmet' => 'Helmet',
            'armor' => 'Armor', 
            'boots' => 'Boots',
            'gloves' => 'Gloves',
            'amulet' => 'Amulet',
            'ring' => 'Ring',
            'cape' => 'Cape',
            'backpack' => 'Backpack',
            'left_hand' => 'Left Hand',
            'right_hand' => 'Right Hand'
        ];
        
        foreach ($slots as $slot => $label) {
            if (!empty($metaData["equipment"][$slot])) {
                $itemName = $metaData["equipment"][$slot];
                
                // Skip blacklisted items
                if (isItemBlacklisted($itemName)) {
                    continue;
                }
                
                $baseid = isset($metaData["equipment"][$slot . '_baseid']) ? $metaData["equipment"][$slot . '_baseid'] : null;
                
                $itemLine = "  • {$label}: {$itemName}";
                
                // Try to add item description only if we haven't described this baseid yet
                if (!empty($baseid) && !in_array($baseid, $describedBaseids)) {
                    $description = $getItemDescription($itemName, $baseid);
                    if ($description) {
                        $itemLine .= " - {$description}";
                        $describedBaseids[] = $baseid; // Mark this baseid as described
                    }
                } elseif (empty($baseid)) {
                    // No baseid, try name-based (won't dedupe without baseid)
                    $description = $getItemDescription($itemName, null);
                    if ($description) {
                        $itemLine .= " - {$description}";
                    }
                }
                
                $equipmentParts[] = $itemLine;
            }
        }
        
        if (!empty($equipmentParts)) {
            $EQUIPMENT_ADD = "\n<equipment>\n#Current Equipment\nYou are currently wearing/wielding:\n" . implode("\n", $equipmentParts);
            
            // Check if humanoid NPC has no body armor - if so, note they're naked
            $humanoidRaces = ['nord', 'imperial', 'breton', 'redguard', 'orc', 'orsimer', 
                            'altmer', 'highelf', 'bosmer', 'woodelf', 'dunmer', 'darkelf', 
                            'argonian', 'khajiit', 'khajit'];
            $npcRace = isset($currentNpcData["race"]) ? strtolower(trim($currentNpcData["race"])) : '';
            
            if ($npcRace && in_array($npcRace, $humanoidRaces) && empty($metaData["equipment"]["armor"])) {
                $EQUIPMENT_ADD .= "\nNote: You are naked (no body armor/clothing worn).";
            }
            
            $EQUIPMENT_ADD .= "\n</equipment>";
        }
    }

     // Add NPC's inventory (skip for The Narrator - they don't need inventory context)
    if ($FOLLOWER_CONF["HERIKA_NAME"] !== "The Narrator" && isset($metaData["inventory"]) && is_array($metaData["inventory"])) {
       
        $equipmentParts=[];
        // Continue using the same $describedBaseids from equipment to dedupe across all items
        if (!isset($describedBaseids)) {
            $describedBaseids = [];
        }
        
        foreach ($metaData["inventory"] as $item) {
            if ($item["name"]!='<Missing Name>') {
                $itemName = $item["name"];
                
                // Skip blacklisted items
                if (isItemBlacklisted($itemName)) {
                    continue;
                }
                
                $itemCount = $item["count"];
                $baseid = isset($item["baseid"]) ? $item["baseid"] : null;
                
                $itemLine = "{$itemCount} {$itemName}";
                $hasDescription = false;
                
                // Try to add item description for notable items (limit descriptions to avoid clutter)
                // Only if we haven't already described this baseid
                if ($itemCount <= 5) { // Only add descriptions for items with low counts
                    if (!empty($baseid) && !in_array($baseid, $describedBaseids)) {
                        $description = $getItemDescription($itemName, $baseid);
                        if ($description) {
                            $itemLine .= " ({$description})";
                            $describedBaseids[] = $baseid; // Mark this baseid as described
                            $hasDescription = true;
                        }
                    } elseif (empty($baseid)) {
                        // No baseid, try name-based (won't dedupe without baseid)
                        $description = $getItemDescription($itemName, null);
                        if ($description) {
                            $itemLine .= " ({$description})";
                            $hasDescription = true;
                        }
                    }
                }
                
                // If filter is enabled and item has no description, skip it
                if (isset($GLOBALS["INVENTORY_ITEMS_DESCRIPTIONS_ONLY"]) && $GLOBALS["INVENTORY_ITEMS_DESCRIPTIONS_ONLY"] && !$hasDescription) {
                    continue;
                }
                
                $equipmentParts[] = $itemLine;
            }
            
        }
        
        if (!empty($equipmentParts)) {
            $INVENTORY_ADD = "\n<inventory>\n#Current Inventory:\n" . implode(", ", $equipmentParts)."\n</inventory>";
        }
    }
    
	// Add current condition (qualitative HP/MP/SP based on percent, with richer descriptors)
	if (isset($metaData["stats"]) && is_array($metaData["stats"])) {
		$s = $metaData["stats"];
		$describe = function(string $kind, float $cur, float $max): string {
			if ($max <= 0) return "Unknown";
			$pct = ($cur < 0 ? 0.0 : ($cur > $max ? $max : $cur)) / $max * 100.0;
			if ($kind === 'health') {
				if ($pct >= 75.0) return "Near full health";           // 100–75
				if ($pct >= 50.0) return "Wounded";                    // 74–50
				if ($pct >= 25.0) return "Badly wounded";              // 50–25
				return "On the brink of collapse";                      // 24–0
			}
			if ($kind === 'magicka') {
				if ($pct >= 75.0) return "Magicka reserves strong";
				if ($pct >= 50.0) return "Magicka reserves middling";
				if ($pct >= 25.0) return "Magicka reserves low";
				return "Magicka nearly drained";
			}
			// stamina
			if ($pct >= 75.0) return "Well‑rested";
			if ($pct >= 50.0) return "Winded";
			if ($pct >= 25.0) return "Exhausted";
			return "Spent";
		};
		$h = $describe('health', (float)($s['health'] ?? 0), (float)($s['health_max'] ?? 0));
		$m = $describe('magicka', (float)($s['magicka'] ?? 0), (float)($s['magicka_max'] ?? 0));
		$st = $describe('stamina', (float)($s['stamina'] ?? 0), (float)($s['stamina_max'] ?? 0));
		if ($h !== 'Unknown' || $m !== 'Unknown' || $st !== 'Unknown') {
			$lines = [];
			if ($h !== 'Unknown') { $lines[] = "  • Health: {$h}"; }
			if ($m !== 'Unknown') { $lines[] = "  • Magicka: {$m}"; }
			if ($st !== 'Unknown') { $lines[] = "  • Stamina: {$st}"; }
			if (!empty($lines)) {
				$STATS_ADD = "\n\n<current_condition>\n#Current Condition\n" . implode("\n", $lines)."\n</current_condition>\n";
			}
		}
	}
    
    // Add NPC's known spells (skip for The Narrator)
    if ($FOLLOWER_CONF["HERIKA_NAME"] !== "The Narrator" && isset($metaData["spells"]) && is_array($metaData["spells"])) {
        $spellParts = [];
        // Continue using the same $describedBaseids from equipment/inventory to dedupe across all items
        if (!isset($describedBaseids)) {
            $describedBaseids = [];
        }
        
        // Casting type labels
        $castingTypes = [
            0 => 'Concentration',
            1 => 'Fire & Forget',
            2 => 'Constant'
        ];
        // Delivery type labels
        $deliveryTypes = [
            0 => 'Self',
            1 => 'Contact',
            2 => 'Aimed',
            3 => 'Target Actor',
            4 => 'Target Location'
        ];
        
        foreach ($metaData["spells"] as $spell) {
            $spellName = isset($spell['name']) ? $spell['name'] : null;
            $baseid = isset($spell['baseid']) ? $spell['baseid'] : null;
            $castingType = isset($spell['casting_type']) ? intval($spell['casting_type']) : 0;
            $deliveryType = isset($spell['delivery']) ? intval($spell['delivery']) : 0;
            
            if (empty($spellName)) {
                continue;
            }
            
            // Only add spells that have descriptions in the database
            $description = null;
            if (!empty($baseid) && !in_array($baseid, $describedBaseids)) {
                $description = $getItemDescription($spellName, $baseid);
                if ($description) {
                    $describedBaseids[] = $baseid;
                }
            }
            
            // Skip spells without descriptions
            if (!$description) {
                continue;
            }
            
            // Format: Spell Name (Casting Type, Delivery) - Description
            $castingLabel = $castingTypes[$castingType] ?? 'Unknown';
            $deliveryLabel = $deliveryTypes[$deliveryType] ?? 'Unknown';
            
            $spellLine = "  • {$spellName} ({$castingLabel}, {$deliveryLabel}) - {$description}";
            $spellParts[] = $spellLine;
        }
        
        if (!empty($spellParts)) {
            $SPELLS_ADD = "\n\n<spells>\n#Known Spells\nYou know the following spells:\n" . implode("\n", $spellParts) . "\n</spells>\n";
        } else {
            // NPC has spells in metadata, but none matched descriptions
            $SPELLS_ADD = "\n\n<spells>\n#Known Spells\nYou know no spells.\n</spells>\n";
        }
    }
    
    // Add dialogue target's equipment (if DIALOGUE_TARGET is set)
    if (isset($GLOBALS["DIALOGUE_TARGET"]) && !empty($GLOBALS["DIALOGUE_TARGET"])) {
        $targetName = $GLOBALS["DIALOGUE_TARGET"];
        $targetNpcData = $npcMaster->getByName($targetName);
        
        if ($targetNpcData) {
            $targetMetaData = $npcMaster->getMetaData($targetNpcData);
            
            if (isset($targetMetaData["equipment"]) && is_array($targetMetaData["equipment"])) {
                $targetEquipmentParts = [];
                $slots = [
                    'helmet' => 'Helmet',
                    'armor' => 'Armor',
                    'boots' => 'Boots', 
                    'gloves' => 'Gloves',
                    'amulet' => 'Amulet',
                    'ring' => 'Ring',
                    'left_hand' => 'Left Hand',
                    'right_hand' => 'Right Hand'
                ];
                
                foreach ($slots as $slot => $label) {
                    if (!empty($targetMetaData["equipment"][$slot])) {
                        $targetEquipmentParts[] = "  • {$label}: {$targetMetaData["equipment"][$slot]}";
                    }
                }
                
                if (!empty($targetEquipmentParts)) {
                    $TARGET_EQUIPMENT_ADD = "\n<target_equipment>\n#{$targetName}'s Equipment\n{$targetName} is currently wearing/wielding:\n" . implode("\n", $targetEquipmentParts);
                    
                    // Check if humanoid NPC has no body armor - if so, note they're naked
                    $humanoidRaces = ['nord', 'imperial', 'breton', 'redguard', 'orc', 'orsimer', 
                                    'altmer', 'highelf', 'bosmer', 'woodelf', 'dunmer', 'darkelf', 
                                    'argonian', 'khajiit', 'khajit'];
                    $targetRace = isset($targetNpcData["race"]) ? strtolower(trim($targetNpcData["race"])) : '';
                    
                    if ($targetRace && in_array($targetRace, $humanoidRaces) && empty($targetMetaData["equipment"]["armor"])) {
                        $TARGET_EQUIPMENT_ADD .= "\nNote: {$targetName} is naked (no body armor/clothing worn).";
                    }
                    
                    $TARGET_EQUIPMENT_ADD .= "\n</target_equipment>\n";
                }
            }
        }
    }

    foreach ($herikaFields as $fieldName => $label) {
        if (isset($FOLLOWER_CONF[$fieldName]) && !empty(trim($FOLLOWER_CONF[$fieldName]))) {
            $xmlLabel=strtr(strtolower($label),[" "=>"_"]);
            $dynamicBio .= "\n<$xmlLabel>\n" . trim($FOLLOWER_CONF[$fieldName])."\n</$xmlLabel>";
            
            // Add groups (factions) right after HERIKA_BACKGROUND (basic_summary) section
            if ($fieldName=="HERIKA_BACKGROUND") {
                $extendedData = $npcMaster->getExtendedData($currentNpcData);
                if (isset($extendedData['factions']) && is_array($extendedData['factions']) && count($extendedData['factions']) > 0) {
                    $factionLines = [];
                    foreach ($extendedData['factions'] as $faction) {
                        if (isset($faction['formid'])) {
                            // Lookup faction using helper function (supports XX prefix)
                            $factionRecord = lookupDescriptionByFormID($faction['formid']);
                            
                            // Only add to prompt if found in descriptions table
                            if ($factionRecord && !empty($factionRecord['name'])) {
                                $factionName = $factionRecord['name'];
                                $factionDesc = !empty($factionRecord['description']) ? $factionRecord['description'] : '';
                                $factionLines[] = "{$factionName} - {$factionDesc}";
                            }
                        }
                    }
                    
                    if (count($factionLines) > 0) {
                        $dynamicBio .= "\n<groups>\nYou belong to these factions:\n" . implode("\n", $factionLines) . "\n</groups>";
                    }
                }
            }
            
            // Add skills right after HERIKA_SKILLS section
            if ($fieldName=="HERIKA_SKILLS") {
                $dynamicBio.=!empty($SKILLS_ADD) ?"\n<rpg_skills>\n$SKILLS_ADD\n</rpg_skills>\n": "";
            }
            
            // Add equipment and reanimation status right after HERIKA_APPEARANCE section
            if ($fieldName=="HERIKA_APPEARANCE") {
                // Check if this NPC is reanimated
                $extendedData = $npcMaster->getExtendedData($currentNpcData);
                if (empty($GLOBALS["DISABLE_REANIMATION_TRACKING"]) && isset($extendedData["reanimated"]) && $extendedData["reanimated"] === true) {
                    $dynamicBio .= "\n<reanimation_status>\nYou have been reanimated from death as a zombie. Your skin has a deathly pale, greyish pallor with a corpse-like appearance. Your eyes are glazed and lifeless, and your movements are stiff and unnatural.\n</reanimation_status>";
                }
                
                $dynamicBio.=$EQUIPMENT_ADD ?? "";
                $dynamicBio.=$TARGET_EQUIPMENT_ADD ?? "";
                $dynamicBio.=$INVENTORY_ADD ?? "";
                $dynamicBio.=$STATS_ADD ?? "";
                $dynamicBio.=$SPELLS_ADD ?? "";
            }
        }
    }
    
    

    // Fall back to HERIKA_DYNAMIC if no new fields are set
    if (empty(trim($dynamicBio)) && isset($FOLLOWER_CONF["HERIKA_DYNAMIC"]) && !empty(trim($FOLLOWER_CONF["HERIKA_DYNAMIC"]))) {
        $dynamicBio = $FOLLOWER_CONF["HERIKA_DYNAMIC"];
    }
    
    if (isset($GLOBALS["HOOKS"]["BIOGRAPHY_BUILDER"])) {
        foreach ($GLOBALS["HOOKS"]["BIOGRAPHY_BUILDER"] as $fName => $builder) {
            error_log("[buildDynamicBiography] BIOGRAPHY_BUILDER {$fName}");

            if (!is_callable($builder)) {
                error_log("[buildDynamicBiography] Builder {$fName} is not callable, skipping.");
                continue;
            }

            // Call the builder. Support both styles:
            //  - builder returns a new bio string
            //  - builder modifies the first argument by-reference
            // We call with call_user_func_array and pass $dynamicBio by-reference so
            // builders that accept a reference can mutate it directly. If the builder
            // returns a non-empty string, prefer that return value as the new bio.
            $result = null;
            try {
                $result = call_user_func_array($builder, array(&$dynamicBio, $currentNpcData));
            } catch (Throwable $e) {
                // Protect against hook errors — log and continue with current bio
                error_log("[buildDynamicBiography] Exception in builder {$fName}: " . $e->getMessage());
                continue;
            }

            if (is_string($result) && strlen(trim($result)) > 0) {
                // Builder returned a non-empty string -> use it
                $dynamicBio = $result;
            }
            // otherwise assume builder mutated $dynamicBio by reference (or left it unchanged)
        }
    }

    return $dynamicBio;
}

function buildDynamicProfileDisplay() {
    /**
     * Build formatted dynamic profile display for profile updates
     * @return string The formatted dynamic profile content
     */
    $currentDynamicProfile = '';
    $herikaFields = [
        'HERIKA_BACKGROUND' => 'Background',
        'HERIKA_PERSONALITY' => 'Personality', 
        'HERIKA_APPEARANCE' => 'Appearance',
        'HERIKA_RELATIONSHIPS' => 'Relationships',
        'HERIKA_OCCUPATION' => 'Occupation',
        'HERIKA_SKILLS' => 'Skills',
        'HERIKA_SPEECHSTYLE' => 'Speech Style',
        'HERIKA_GOALS' => 'Goals'
    ];
    
    foreach ($herikaFields as $fieldName => $label) {
        if (isset($GLOBALS[$fieldName]) && !empty(trim($GLOBALS[$fieldName]))) {
            $currentDynamicProfile .= "\n$label:\n" . trim($GLOBALS[$fieldName]) . "\n";
        }
    }
    
    // Fall back to HERIKA_DYNAMIC if no new fields are set
    if (empty(trim($currentDynamicProfile)) && isset($GLOBALS["HERIKA_DYNAMIC"]) && !empty(trim($GLOBALS["HERIKA_DYNAMIC"]))) {
        $currentDynamicProfile = "Legacy Dynamic Profile:\n" . $GLOBALS["HERIKA_DYNAMIC"];
    }
    
    if (empty(trim($currentDynamicProfile))) {
        $currentDynamicProfile = "No dynamic profile information available.";
    }
    
    return $currentDynamicProfile;
}


function requireFilesRecursively($dir,$name) {
    
    global $gameRequest;

    $files = scandir($dir);
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') {
            continue;
        }

        $path = $dir . '/' . $file;

        if (is_dir($path)) {
            requireFilesRecursively($path,$name);
        } elseif (is_file($path) && $file === $name) {
            require_once($path);
        } 
    }
}


/**
 * Parses a PHP file and extracts variable assignments into an associative array.
 *
 * Handles:
 * - Scalars: $name = 'Herika';
 * - Arrays: $data = ["a", "b"];
 * - Nested array keys: $a["x"]["y"] = 123;
 *
 * All values are returned in raw form (e.g., quoted strings are unquoted).
 *
 * @param string $filePath Path to the PHP file to parse.
 * @return array Associative array of variable names (or paths) => raw values.
 */
function extract_assignments($filePath) {
    $code = file_get_contents($filePath);
    $tokens = token_get_all($code);

    $variables = [];
    $varName = '';
    $indexStack = [];
    $collectValue = false;
    $valueBuffer = '';
    $bracketDepth = 0;
    $expectingKey = false;

    foreach ($tokens as $i => $token) {
        if (is_array($token)) {
            [$id, $text] = $token;

            if ($id === T_VARIABLE) {
                $varName = substr($text, 1);
                $indexStack = [];
                $collectValue = false;
                $valueBuffer = '';
                $bracketDepth = 0;
                $expectingKey = false;
            }

            elseif ($expectingKey && in_array($id, [T_CONSTANT_ENCAPSED_STRING, T_STRING, T_LNUMBER, T_DNUMBER])) {
                $indexStack[] = trim($text, "'\"");
                $expectingKey = false;
            }

            elseif ($collectValue) {
                $valueBuffer .= $text;
            }

        } else {
            // Symbolic tokens
            if ($token === '[' && !$collectValue) {
                $expectingKey = true;
            }

            elseif ($token === '=' && !$collectValue) {
                $collectValue = true;
                $valueBuffer = '';
                $bracketDepth = 0;
            }

            elseif ($collectValue) {
                if ($token === '[') {
                    $bracketDepth++;
                    $valueBuffer .= $token;
                } elseif ($token === ']') {
                    $bracketDepth--;
                    $valueBuffer .= $token;
                } elseif (($token === ';' || $token === ',') && $bracketDepth === 0) {
                    // Don't add the terminating character to the buffer
                    $rawValue = trim($valueBuffer);

                    // Remove quotes and unescape if present
                    if (strlen($rawValue) >= 2) {
                        if ($rawValue[0] === '"' && $rawValue[-1] === '"') {
                            // Double-quoted string - remove quotes and unescape
                            $rawValue = stripcslashes(substr($rawValue, 1, -1));
                        } elseif ($rawValue[0] === "'" && $rawValue[-1] === "'") {
                            // Single-quoted string - remove quotes and unescape single quotes and backslashes
                            $rawValue = substr($rawValue, 1, -1);
                            $rawValue = str_replace(["\\'", "\\\\"], ["'", "\\"], $rawValue);
                        }
                    }

                    // Build full key
                    $fullKey = $varName;
                    foreach ($indexStack as $key) {
                        $fullKey .= "['$key']";
                    }

                    $variables[$fullKey] = $rawValue;

                    // Reset state
                    $collectValue = false;
                    $valueBuffer = '';
                    $indexStack = [];
                } else {
                    $valueBuffer .= $token;
                }
            }

            // Reset expectingKey if we see closing bracket
            if ($token === ']' && !$collectValue) {
                $expectingKey = false;
            }
        }
    }

    return $variables;
}


/**
 * Writes variable assignments to a PHP file using clean formatting.
 *
 * Accepts keys like 'VAR' or 'ARRAY["KEY"]["SUB"]' and writes them back to PHP code.
 * Automatically quotes strings, and leaves numbers, booleans, null, and arrays untouched.
 *
 * @param array $assignments The variable assignments, as [name => raw_value]
 * @param string $filePath Path to save the output PHP code
 */
function write_php_assignments(array $assignments, string $filePath): bool {
    $output = "<?php\n\n";

    foreach ($assignments as $key => $value) {
        // Clean the value - remove trailing semicolons and trim whitespace
        $cleaned = rtrim(trim($value), ';');
        
        // If the value is already quoted, unquote it first
        if (strlen($cleaned) >= 2) {
            if (($cleaned[0] === '"' && $cleaned[-1] === '"') || 
                ($cleaned[0] === "'" && $cleaned[-1] === "'")) {
                $cleaned = substr($cleaned, 1, -1);
            }
        }
        
        // Now determine the correct output format based on the cleaned value
        $lowerCleaned = strtolower($cleaned);
        
        if (in_array($lowerCleaned, ['true', 'false', 'null'], true)) {
            // Boolean or null values - output as-is
            $finalValue = $lowerCleaned;
        } elseif (is_numeric($cleaned) && !str_contains($cleaned, ' ')) {
            // Numeric values - output as-is
            $finalValue = $cleaned;
        } elseif (preg_match('/^\s*\[.*\]\s*$/s', $cleaned)) {
            // Array literals - output as-is
            $finalValue = $cleaned;
        } else {
            // String values - apply comprehensive sanitization for AI-generated content
            if (is_string($cleaned)) {
                // Sanitize AI-generated content to prevent PHP syntax errors
                $cleaned = str_replace("\0", '', $cleaned); // Remove null bytes
                $cleaned = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $cleaned); // Remove control chars
                if (!mb_check_encoding($cleaned, 'UTF-8')) {
                    $cleaned = mb_convert_encoding($cleaned, 'UTF-8', 'UTF-8'); // Fix encoding
                }
                if (strlen($cleaned) > 100000) {
                    $cleaned = substr($cleaned, 0, 100000) . '... [truncated]'; // Limit length
                }
                $cleaned = str_replace(['<?php', '<?', '?>'], ['&lt;?php', '&lt;?', '?&gt;'], $cleaned); // Escape PHP tags
                
                // Additional sanitization for var_export compatibility
                $cleaned = str_replace('\\', '\\\\', $cleaned); // Escape backslashes
                $cleaned = str_replace("\r\n", "\n", $cleaned); // Normalize line endings
                $cleaned = str_replace("\r", "\n", $cleaned); // Convert Mac line endings
                $cleaned = preg_replace('/\n{3,}/', "\n\n", $cleaned); // Limit consecutive newlines
            }
            
            // Use var_export for safer escaping instead of addslashes
            $finalValue = var_export($cleaned, true);
        }

        // Build the assignment line
        if (strpos($key, '[') !== false) {
            $line = "\${$key} = {$finalValue};";
        } else {
            $line = "\$$key = {$finalValue};";
        }

        $output .= $line . "\n";
    }

    return file_put_contents($filePath, $output, LOCK_EX);
}

function getInGameSkillDataFor($npcName) {

    $npcEscapedName=$GLOBALS["db"]->escape($npcName);
    $query="
WITH npc_spells AS (
  SELECT
    TRIM(SUBSTRING(data FROM '$npcEscapedName casts\s+(.+)$')) AS spell
  FROM public.eventlog
  WHERE type = 'npcspellcast' AND data LIKE '$npcEscapedName casts%'
),

npc_weapons AS (
  SELECT
    TRIM(SUBSTRING(data FROM 'using weapon\s+(.+)$')) AS weapon
  FROM public.eventlog
  WHERE type = 'death' AND data LIKE '%$npcEscapedName has defeated%'
)

SELECT
  'spell' AS type,
  spell AS item,
  COUNT(*) AS usage_count
FROM npc_spells
where spell is not null
GROUP BY spell
HAVING COUNT(*)>1

UNION ALL

SELECT
  'weapon' AS type,
  weapon AS item,
  COUNT(*) AS usage_count
FROM npc_weapons
where weapon is not null
GROUP BY weapon
HAVING COUNT(*)>1

ORDER BY type, usage_count DESC;
";
    $skillsData=$GLOBALS["db"]->fetchAll($query);

    if (sizeof ($skillsData)==0)
        return "";

    $spells = [];
    $weapons = [];

    foreach ($skillsData as $entry) {
        if ($entry['type'] === 'spell') {
            $spells[] = $entry['item'];
        } elseif ($entry['type'] === 'weapon') {
            $weapons[] = $entry['item'];
        }
    }

    // Store in strings
    $spellsList = sizeof($spells)>0?implode(', ', $spells):"none";
    $weaponsList = sizeof($weapons)>0?implode(', ', $weapons):"none";
    

    return "* Fav.Spells: $spellsList\n* Fav. Weapons: $weaponsList\n";
}

/**
 * Safely export a value to PHP code with comprehensive sanitization to prevent syntax errors
 * 
 * This function sanitizes AI-generated content to prevent PHP syntax errors that can occur
 * with standard var_export() when dealing with special characters, encoding issues, etc.
 * 
 * @param mixed $value The value to export
 * @param bool $return Whether to return the string instead of outputting it
 * @return string|null The exported PHP code
 */
function safe_var_export($value, $return = true) {
    // First, sanitize string values
    if (is_string($value)) {
        // Remove null bytes that can break PHP parsing
        $value = str_replace("\0", '', $value);
        
        // Ensure valid UTF-8 encoding
        if (!mb_check_encoding($value, 'UTF-8')) {
            $value = mb_convert_encoding($value, 'UTF-8', 'UTF-8');
        }
        
        // Remove or replace problematic characters
        $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $value);
        
        // Limit length to prevent extremely long strings
        if (strlen($value) > 100000) {
            $value = substr($value, 0, 100000) . '... [truncated]';
        }
        
        // Ensure balanced quotes and backslashes don't break escaping
        $value = str_replace(['\\', "'", '"'], ['\\\\', "\\'", '\\"'], $value);
        $value = stripslashes($value); // Remove double escaping
    }
    
    // Try var_export first
    $exported = var_export($value, true);
    
    // Validate that the exported code is syntactically correct
    $testCode = "<?php return $exported; ?>";
    
    // Use eval to test syntax (in a safe way)
    $oldLevel = error_reporting(0);
    $syntaxValid = @eval("return true; $testCode") !== false;
    error_reporting($oldLevel);
    
    if (!$syntaxValid) {
        // Fallback: manual string escaping for safety
        if (is_string($value)) {
            $exported = "'" . addcslashes($value, "'\\") . "'";
        } else {
            // For non-strings, convert to string safely
            $exported = "'" . addcslashes((string)$value, "'\\") . "'";
        }
    }
    
    if ($return) {
        return $exported;
    } else {
        echo $exported;
        return null;
    }
}

/**
 * Safely update a PHP configuration file variable with proper error handling
 * 
 * @param string $filePath Path to the PHP file
 * @param string $varName Variable name (without $)
 * @param mixed $value New value
 * @return array Result with success status and message
 */
function safe_update_php_variable($filePath, $varName, $value) {
    if (!file_exists($filePath)) {
        return ["success" => false, "error" => "File not found: " . basename($filePath)];
    }
    
    // Read current content
    $content = file_get_contents($filePath);
    if ($content === false) {
        return ["success" => false, "error" => "Cannot read file: " . basename($filePath)];
    }
    
    // Use safe export
    $escapedValue = safe_var_export($value, true);
    
    // Validate the escaped value produces valid PHP
    $testAssignment = "\$$varName = $escapedValue;";
    $testCode = "<?php $testAssignment ?>";
    
    $oldLevel = error_reporting(0);
    $syntaxValid = @eval("return true; $testCode") !== false;
    error_reporting($oldLevel);
    
    if (!$syntaxValid) {
        return ["success" => false, "error" => "Generated PHP code would be invalid for variable $varName"];
    }
    
    // Update or add variable
    $pattern = '/\$' . preg_quote($varName, '/') . '\s*=\s*[^;]+;/';
    if (preg_match($pattern, $content)) {
        $content = preg_replace($pattern, '$' . $varName . '=' . $escapedValue . ';', $content);
    } else {
        // Add before closing 
        $content = str_replace('?>', '$' . $varName . '=' . $escapedValue . ';' . PHP_EOL . '?>', $content);
    }
    
    // Write with atomic operation
    $tempFile = $filePath . '.tmp.' . uniqid();
    if (file_put_contents($tempFile, $content, LOCK_EX) === false) {
        return ["success" => false, "error" => "Cannot write to temporary file"];
    }
    
    if (!rename($tempFile, $filePath)) {
        unlink($tempFile);
        return ["success" => false, "error" => "Cannot update file: " . basename($filePath)];
    }
    
    return ["success" => true, "message" => "Variable $varName updated successfully"];
}


/**
 * Retrieves base data for an NPC from the event log based on the NPC's name.
 *
 * This function queries the database for the most recent log entry of type 'addnpc'
 * that matches the given NPC name. It extracts and returns the NPC's gender, race,
 * and reference ID from the log data. If the NPC name is empty, no matching data is found,
 * or the data is insufficient, the function returns null.
 *
 * @param string $npcname The name of the NPC to retrieve data for.
 * @return array|null An associative array containing 'gender', 'race', and 'refid' keys,
 *                    or null if no valid data is found.
 */
function getBaseDataForNpcFromLog($npcname) {
    if (empty($npcname)) {
        error_log("getBaseDataForNpcFromLog: NPC name is empty.");
        return null;
    }

    $npcNameEscaped = $GLOBALS["db"]->escape($npcname);
    $result = $GLOBALS["db"]->fetchOne("SELECT data FROM eventlog WHERE type='addnpc' AND data LIKE '$npcNameEscaped%' ORDER BY rowid DESC LIMIT 1");

    if (!$result || !isset($result["data"])) {
        error_log("getBaseDataForNpcFromLog: No data found for NPC '$npcname'.");
        return null;
    }

    $splitNameBase = explode("@", $result["data"]);
    if (count($splitNameBase) < 5) {
        error_log("getBaseDataForNpcFromLog: Insufficient data for NPC '$npcname'. Data: " . print_r($result["data"], true));
        return null;
    }

    $currentNpcData = [
        "gender" => $splitNameBase[2],
        "race" => $splitNameBase[3],
        "refid" => $splitNameBase[4]
    ];

    return $currentNpcData;
}

function getLastLocationNamedCell() {
    $q="SELECT A.gamets,A.localts,cell_name,C.name as location_name,statics_list,A.sess::BIGINT,interior,worldspace,B.location_id
FROM public.eventlog A
LEFT JOIN public.named_cell B ON (B.id = A.sess::BIGINT )
LEFT JOIN public.locations C ON (C.formid=B.location_id  )
WHERE A.sess ~ '^[0-9]+$' and type='request'
and A.sess<>'pending'
order by A.gamets desc,A.localts desc
limit 1";

    $locData=$GLOBALS["db"]->fetchOne($q);
    $locationDetailedName = null;
    if ($locData && isset($locData['location_name']) && !empty($locData['location_name'])) {
        $locData['worldspace']=trim($locData['worldspace'] ?? '');
        if ($locData['worldspace']=="Skyrim") {
            $locationDetailedName = $locData['location_name'] . " (outdoors)";
        } else {
            $locationDetailedName = $locData['location_name'] . " (inside " . $locData['worldspace'] . ")";
        }
        if ($locData['interior']==1) {
            $locationDetailedName.=" (interior)";
        } 
        
    }

    return $locationDetailedName;
}

/**
 * Build a situational map description with doors/passages and their directions
 * 
 * Retrieves the current cell from the eventlog, finds all doors in the same worldspace,
 * and generates a description of available passages with compass directions based on
 * relative door positions.
 * 
 * @return string Situational map description with doors and their directions
 */
function buildSituationalMapDescription() {
    // Get current cell from eventlog
    $current_cell_result = $GLOBALS["db"]->fetchOne(
        "SELECT A.sess::BIGINT as current_cell
         FROM public.eventlog A
         WHERE A.sess ~ '^[0-9]+$' and type='request'
         and A.sess<>'pending'
         order by A.gamets desc, A.localts desc
         limit 1"
    );
    
    if (!$current_cell_result || !isset($current_cell_result['current_cell'])) {
        error_log("buildSituationalMapDescription: No current cell found in eventlog.");
        return "";
    }
    
    $current_cell_id = $current_cell_result['current_cell'];
    
    // Get the worldspace of the current cell
    $current_cell_data = $GLOBALS["db"]->fetchOne(
        "SELECT worldspace,cell_name,location_id FROM named_cell WHERE id = {$current_cell_id} LIMIT 1"
    );
    
    if (!$current_cell_data) {
        error_log("buildSituationalMapDescription: Current cell ID {$current_cell_id} not found in named_cell.");
        return "";
    }
    
    $current_worldspace = trim($current_cell_data['worldspace'] ?? '');
    $current_cell_name = trim($current_cell_data['cell_name'] ?? '');
    
    $current_player_cell_data = $GLOBALS["db"]->fetchOne(
        "SELECT worldspace,cell_name,location_id,door_x,door_y FROM named_cell WHERE id = 0 LIMIT 1"
    );

    $player_x=$current_player_cell_data['door_x'] ?? 0;
    $player_y=$current_player_cell_data['door_y'] ?? 0;

    // If worldspace is Skyrim, just return base description
    if ($current_worldspace === 'Skyrim') {
       
        // Get all doors in the worldspace Skyrim, with valid coordinates and (distance< 1024 *10), door_x,door_y is relative to player position
        $doors_result = $GLOBALS["db"]->fetchAll(
            "SELECT id, cell_name, door_name, door_id,door_x, door_y, dest_door_exterior, interior,location_id, sqrt((door_x-({$player_x}))*(door_x-({$player_x})) + (door_y-({$player_y}))*(door_y-({$player_y}))) as distance
            FROM named_cell 
            WHERE worldspace = '{$current_worldspace}' and location_id={$current_cell_data['location_id']}
            AND door_name <> ''
            AND id<>dest_door_cell_id
            ORDER BY id"
        );
        
    } else {
    
        // Get all doors in the same worldspace 
        $doors_result = $GLOBALS["db"]->fetchAll(
            "SELECT id, cell_name, door_name, door_id,door_x, door_y, dest_door_exterior, interior,location_id, sqrt((door_x-({$player_x}))*(door_x-({$player_x})) + (door_y-({$player_y}))*(door_y-({$player_y}))) as distance
            FROM named_cell 
            WHERE worldspace = '{$current_worldspace}' and location_id={$current_cell_data['location_id']}
            AND door_name <> ''
            AND id<>dest_door_cell_id
            ORDER BY id"
        );
    }
    
    if (empty($doors_result)) {
        if ($current_worldspace != $current_cell_name)
            return "You are in {$current_worldspace}, {$current_cell_name}. No other exits found.";
        else
            return "You are in {$current_worldspace}. No other exits found.";
    }
    
    $directional_doors = array();
    
    // Categorize doors by direction
    foreach ($doors_result as $door) {
        $door_x = floatval($door['door_x']);
        $door_y = floatval($door['door_y']);
        $door_name = trim($door['door_name'] ?? 'Unknown');
        $dest_worldspace = trim($door['dest_door_exterior'] ?? '');
        $interior = intval($door['interior'] ?? 0);
        $distance = round(floatval($door['distance'] ?? 0)/70);// Convert to approximate meters (assuming 70 units = 1 meter)

        $unsignedInt = $door['door_id'] & 0xFFFFFFFF;
        $doorHexid=  "0x" . str_pad(dechex($unsignedInt), 8, "0", STR_PAD_LEFT);

        
        if ($distance > 1000) {
            // Ignore doors farther than 1000 meters
            continue;
        }
        // Calculate relative position
        $delta_x = $door_x - $player_x;
        $delta_y = $door_y - $player_y;
        // error_log("Door '{$door_name}' at ({$door_x}, {$door_y}), delta ({$delta_x}, {$delta_y})");
        // Determine cardinal direction
        $direction = getCardinalDirection($delta_x, $delta_y);
        
        
        $passage_type = "Door/Passage to {$door_name} ({$distance} meters) [door id:{$doorHexid}]";
                
        if (!isset($directional_doors[$direction])) {
            $directional_doors[$direction] = array();
        }
        if ($current_cell_id == $door['id']) {
            // We're at this cell
            if ($interior==1) {
                $current_worldspace = $door["cell_name"];
            } else {
                
            }
        }
        $directional_doors[$direction][] = $passage_type;
    }
    
    // Build the map description
    
    if ($current_worldspace != $current_cell_name)
        $map_description = "You are in {$current_worldspace}, {$current_cell_name}. ";
    else
        $map_description = "You are in {$current_cell_name}. ";

    $passages = array();
    
    $cardinal_order = array('North', 'Northeast', 'East', 'Southeast', 'South', 'Southwest', 'West', 'Northwest');
    
    foreach ($cardinal_order as $direction) {
        if (isset($directional_doors[$direction])) {
            foreach ($directional_doors[$direction] as $passage) {
                $passages[] = "{$passage} at {$direction}";
            }
        }
    }
    
    if (!empty($passages)) {
        $map_description .= implode(", ", $passages) . ".";
    } else {
        $map_description .= "No other exits found.";
    }
    
    return $map_description;
}

/**
 * Helper function to determine cardinal direction from relative coordinates
 * 
 * @param float $delta_x Change in X coordinate
 * @param float $delta_y Change in Y coordinate
 * @return string Cardinal direction (N, NE, E, SE, S, SW, W, NW)
 */
function getCardinalDirection($delta_x, $delta_y) {
    // Normalize to get angle
    $angle = atan2($delta_y, $delta_x) * 180 / M_PI;
    
    // Adjust angle to 0-360 range
    if ($angle < 0) {
        $angle += 360;
    }
    
    // Map angle to cardinal direction
    // Using 22.5 degree boundaries for 8-point compass
    if ($angle >= 337.5 || $angle < 22.5) {
        return 'East';
    } elseif ($angle >= 22.5 && $angle < 67.5) {
        return 'Northeast';
    } elseif ($angle >= 67.5 && $angle < 112.5) {
        return 'North';
    } elseif ($angle >= 112.5 && $angle < 157.5) {
        return 'Northwest';
    } elseif ($angle >= 157.5 && $angle < 202.5) {
        return 'West';
    } elseif ($angle >= 202.5 && $angle < 247.5) {
        return 'Southwest';
    } elseif ($angle >= 247.5 && $angle < 292.5) {
        return 'South';
    } else {
        return 'Southeast';
    }
}


?>
