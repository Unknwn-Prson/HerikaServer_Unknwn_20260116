<?php
/**
 * Reasoning/Chain-of-Thought Token Stripping Helpers
 *
 * These functions strip reasoning/CoT tokens from LLM output.
 * The cached connector (openrouterjsoncached) intentionally enables reasoning/thinking
 * at the API level and strips tags itself, unlike upstream connectors which use
 * API-level exclusion (e.g. "reasoning": {"exclude": true}).
 *
 * Called from openrouterjsoncached.php via function_exists() guard for JSON format.
 *
 * @package CachedConnector
 */

/**
 * Strip reasoning/CoT tokens from text
 * Removes common reasoning markers: <think>, <thinking>, <reasoning>, <thought>, <reflection>
 * Also removes DeepSeek-style markers and other common patterns
 *
 * NOTE: Nested markers of the same type are not fully supported. For example:
 *   <think>Outer<think>Inner</think>More</think>
 * May leave orphaned closing tags. This is acceptable as LLMs rarely output nested markers.
 *
 * @param string $text Text to process
 * @return string Text with reasoning tokens removed
 */
function stripReasoningTokens($text) {
    if (empty($text)) {
        return $text;
    }

    // Common reasoning markers (case-insensitive)
    $patterns = [
        '/<think>.*?<\/think>/is',           // <think>...</think>
        '/<thinking>.*?<\/thinking>/is',     // <thinking>...</thinking>
        '/<reasoning>.*?<\/reasoning>/is',   // <reasoning>...</reasoning>
        '/<thought>.*?<\/thought>/is',       // <thought>...</thought>
        '/<reflection>.*?<\/reflection>/is', // <reflection>...</reflection>
        '/<cot>.*?<\/cot>/is',               // <cot>...</cot> (chain of thought)
        '/<scratchpad>.*?<\/scratchpad>/is', // <scratchpad>...</scratchpad>
        '/\[THINK\].*?\[\/THINK\]/is',       // [THINK]...[/THINK]
        '/\[THINKING\].*?\[\/THINKING\]/is', // [THINKING]...[/THINKING]
    ];

    $cleaned = $text;
    foreach ($patterns as $pattern) {
        $cleaned = preg_replace($pattern, '', $cleaned);
    }

    // Clean up any resulting extra whitespace
    // Collapse ALL whitespace (including newlines) to single spaces for roleplay responses
    $cleaned = preg_replace('/\s+/', ' ', $cleaned);
    $cleaned = trim($cleaned);

    return $cleaned;
}

/**
 * Check if text contains an opening reasoning marker without closing
 * Used for streaming to detect incomplete reasoning blocks
 *
 * @param string $text Text to check
 * @return bool True if text has unclosed reasoning marker
 */
function hasUnclosedReasoningMarker($text) {
    if (empty($text)) {
        return false;
    }

    // Check for opening tags without closing
    $markers = [
        ['open' => '<think>', 'close' => '</think>'],
        ['open' => '<thinking>', 'close' => '</thinking>'],
        ['open' => '<reasoning>', 'close' => '</reasoning>'],
        ['open' => '<thought>', 'close' => '</thought>'],
        ['open' => '<reflection>', 'close' => '</reflection>'],
        ['open' => '<cot>', 'close' => '</cot>'],
        ['open' => '<scratchpad>', 'close' => '</scratchpad>'],
        ['open' => '[THINK]', 'close' => '[/THINK]'],
        ['open' => '[THINKING]', 'close' => '[/THINKING]'],
    ];

    foreach ($markers as $marker) {
        $openCount = substr_count(strtolower($text), strtolower($marker['open']));
        $closeCount = substr_count(strtolower($text), strtolower($marker['close']));

        if ($openCount > $closeCount) {
            return true; // Found unclosed marker
        }
    }

    return false;
}

/**
 * Extract reasoning-free portion from text during streaming
 * If text has complete reasoning blocks, they are stripped
 * If text has unclosed reasoning block, extract content before it
 *
 * @param string $text Text to process
 * @return string|false Text with reasoning stripped, or false if text starts with unclosed marker
 */
function extractReasoningFreeContent($text) {
    if (empty($text)) {
        return $text;
    }

    // First, strip all complete reasoning blocks
    $cleaned = stripReasoningTokens($text);

    // Check if there are still unclosed markers after stripping complete blocks
    if (hasUnclosedReasoningMarker($cleaned)) {
        // Find position of first unclosed opening marker
        $markers = [
            '<think>', '<thinking>', '<reasoning>', '<thought>', '<reflection>',
            '<cot>', '<scratchpad>', '[THINK]', '[THINKING]'
        ];

        $firstMarkerPos = false;
        foreach ($markers as $marker) {
            $pos = stripos($cleaned, $marker);
            if ($pos !== false && ($firstMarkerPos === false || $pos < $firstMarkerPos)) {
                $firstMarkerPos = $pos;
            }
        }

        // If unclosed marker is at the start, wait for more data
        if ($firstMarkerPos === 0) {
            return false;
        }

        // If unclosed marker is later in the text, return content before it
        if ($firstMarkerPos !== false) {
            return trim(substr($cleaned, 0, $firstMarkerPos));
        }
    }

    // No unclosed markers, return cleaned text
    return $cleaned;
}
