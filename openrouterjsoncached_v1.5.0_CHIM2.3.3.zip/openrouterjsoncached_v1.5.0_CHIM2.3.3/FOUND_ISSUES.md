# Found Issues — Streaming Pipeline Investigation

Issues discovered while investigating response processing bugs.
Categorized by scope and fix status.

---

## Fixed (Cached Connector)

### 1. checkOAIComplains false positives (Gemini/Palmyra cutoff)

**Location:** `lib/chat_helper_functions.php:340-408`, `returnLines()` line 672-677

**Problem:** The `checkOAIComplains()` function scores sentences for
"refusal language" (e.g. "sorry", "can't", "context", "assist"). If
a sentence scores >= 3, `$FORCED_STOP = true` kills ALL remaining
output — across all subsequent `returnLines()` calls.

Normal RPG dialogue easily triggers this:
- "I'm sorry to hear that" → sorry(1) + can't(0) = 1 (safe)
- "Sorry, I can't help with that context" → sorry(1) + can't(1) + context(1) = 3 → **KILLED**
- "I'm sorry, I can't assist you" → sorry(1) + can't(1) + assist(1) = 3 → **KILLED**

Claude rarely uses these patterns in roleplay. Gemini and Palmyra
use them routinely in normal dialogue. Once triggered, `$FORCED_STOP`
persists, so the rest of the response is silently dropped — explaining
why full responses appear in `output_from_llm.log` but are only
partially processed.

**Fix:** Added `disable_refusal_filter` setting (defaults ON for
cached connector). Sets `$GLOBALS["OPENAI_FILTER_DISABLED"]` which
the existing `checkOAIComplains()` already checks at line 344.
No upstream code change needed.

### 2. Asterisk content stripping

**Location:** `lib/chat_helper_functions.php:503-553` (`unmoodSentence()`)

**Problem:** `unmoodSentence()` strips ALL text between asterisks
(`*like this*`) for TTS. The existing `strip_emotes_from_output`
toggle only switches between full strip and partial strip (multi-word
only) — there's no "preserve content" option.

This strips emphasis formatting (`I *really* think so`), narration
cues, and roleplay formatting that users may want preserved.

**Fix:** Added `PRESERVE_ASTERISKS` global and 'none' mode to
`unmoodSentence()`. Strips the asterisk *characters* but preserves
the text between them. Controlled by `preserve_asterisks` setting
in cached connector metadata.

---

## Found — Beyond Scope (Upstream)

### 3. `returnLines()` early-return bugs

**Location:** `lib/chat_helper_functions.php`, `returnLines()` function

Three places use `return` instead of `continue` inside the
`foreach ($lines as $n => $sentence)` loop, meaning one bad
sentence kills ALL remaining sentences:

```
Line 622-623: if (is_array($sentence)) return;
Line 707-708: if (strlen($responseTextUnmooded) < 2) return;
Line 712-713: if (strpos($responseTextUnmooded, "The Narrator:") !== false) return;
```

**Impact:** If `unmoodSentence()` strips a sentence to <2 chars
(e.g. asterisk-only narration `*She smiles*` → empty), all
subsequent sentences in that batch are dropped. Similarly, if one
sentence contains "The Narrator:", everything after it is lost.

**Recommended fix:** Change `return` to `continue` in all three
locations. This is an upstream bug affecting all connectors.

### 4. `str_replace` incremental extraction in `openrouterjson.php`

**Location:** `connector/openrouterjson.php:960`

```php
$mangledBuffer = str_replace($this->_extractedbuffer, "", $finalData["message"]);
```

**Problem:** Uses `str_replace` to extract incremental text from a
growing string. If the message contains repeated substrings,
`str_replace` can match the wrong occurrence, silently losing or
garbling content. This causes:
- **Words concatenated together** (spaces lost when extraction
  boundary falls incorrectly)
- **Content loss** for LLMs that produce repetitive phrasing

**Recommended fix:** Use `substr()` with length tracking instead
of `str_replace()`:
```php
$mangledBuffer = substr($finalData["message"], strlen($this->_extractedbuffer));
$this->_extractedbuffer = $finalData["message"];
```

**Note:** The cached connector is NOT affected — its
`_parseAndReturnContent()` uses a different extraction mechanism.

### 5. JSON preamble threshold in `openrouterjson.php`

**Location:** `connector/openrouterjson.php:920`

```php
if (strlen($this->_buffer) > $buffer_preamble && strpos($this->_buffer, '{') === false) {
    return -1;
}
```

**Problem:** If no `{` is found in the first 64 characters (or
4096 for reasoning models), the connector returns -1 (fatal error),
killing the streaming loop. LLMs that produce preamble text before
JSON (common with Gemini) get cut off.

**Impact:** Gemini models may be affected when not using reasoning
mode (64-char limit). With reasoning mode, the 4096 limit should
be sufficient.

### 6. Double-quote stripping in streaming loop

**Location:** `lib/data_functions.php:4106`

```php
$buffer = strtr($buffer, array("\"" => "", ".)" => ")."));
```

**Problem:** Strips ALL double-quote characters from the streaming
buffer. If the LLM outputs adjacent quoted words without spaces
between quotes (`"word1""word2"`), stripping produces concatenated
text (`word1word2`).

**Note:** This is applied to the `$buffer` in the streaming loop
before sentence splitting. It affects all connectors.

### 7. `totalBuffer` accumulation bug

**Location:** `lib/data_functions.php:4098-4099`

```php
$buffer .= $tmpData;
$totalBuffer .= $buffer;  // Appends ENTIRE buffer, not just new data
```

**Problem:** On each iteration, `$totalBuffer` appends the full
`$buffer` (which grows each iteration), not just `$tmpData`. This
means `$totalBuffer` contains duplicated/overlapping data. Example:
- Iteration 1: buffer="A", totalBuffer="A"
- Iteration 2: buffer="AB", totalBuffer="A"+"AB"="AAB"

**Impact:** `$totalBuffer` is used for logging and post-processing
after the loop. The duplicated data may cause incorrect token
counts or logging artifacts but does not affect the actual sentence
streaming (which uses `$buffer` directly).

---

## Investigation Date

2026-02-04
