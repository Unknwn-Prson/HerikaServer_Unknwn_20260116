<?php
/**
 * Cached Connector: MINIMIZE_QUALITY_PROMPT override
 *
 * Loaded via requireFilesRecursively() after the main dialogue_prompt.php.
 * Overrides $TEMPLATE_DIALOG for cached connector instances to use a shorter prompt,
 * saving tokens with advanced models that don't need verbose guidance.
 *
 * Can be overridden per-connector via the minimize_quality_prompt metadata setting.
 *
 * @package CachedConnector
 */

// CHIM_CACHED_FEATURE: MINIMIZE_QUALITY_PROMPT
$useMinimizedPrompt = false;

if (function_exists('DMgetCurrentModel')) {
    $currentModel = DMgetCurrentModel();

    // Cached connector defaults to minimized prompt
    if ($currentModel === 'openrouterjsoncached') {
        $useMinimizedPrompt = true;
    }

    // Allow explicit override from connector metadata
    if (isset($GLOBALS["CONNECTOR"][$currentModel]["minimize_quality_prompt"])) {
        $useMinimizedPrompt = (bool)$GLOBALS["CONNECTOR"][$currentModel]["minimize_quality_prompt"];
    }
}

if ($useMinimizedPrompt) {
    // Rebuild $TEMPLATE_DIALOG with minimized version, preserving downstream appends
    // (inline narration, Azure moods) that were already applied by the main file.
    // We strip the verbose guidance portion and keep the base instruction.
    $TEMPLATE_DIALOG = preg_replace(
        '/Be original, creative, knowledgeable, use your own thoughts\.\s*Review dialogue history to focus on conversation topic and to avoid repeating sentences and phraseology from previous dialog lines\./',
        '',
        $TEMPLATE_DIALOG
    );
    // Clean up any double spaces left behind
    $TEMPLATE_DIALOG = preg_replace('/\s{2,}/', ' ', $TEMPLATE_DIALOG);
    $TEMPLATE_DIALOG = rtrim($TEMPLATE_DIALOG);
}
