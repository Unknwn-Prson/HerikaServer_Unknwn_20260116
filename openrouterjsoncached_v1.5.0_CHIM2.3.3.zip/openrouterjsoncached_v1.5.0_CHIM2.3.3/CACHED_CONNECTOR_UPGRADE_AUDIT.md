# Cached Connector Upgrade Audit: v1.4 (CHIM 2.0.5) -> v2.0.1 (CHIM 2.3.3)

## Summary

When the cached connector was upgraded from v1.4 to v2.0.1, three
"ADDITIONALS" files were dropped from the package. These files were not
simple copies of the CHIM baseline — they contained connector-specific
features. Additionally, CHIM 2.3.3 upstream itself introduced a bug in
one of these files.

---

## Files Dropped from v2.0.1 Package

### 1. `prompts/dialogue_prompt.php` — Minimize Quality Instructions

**Purpose in v1.4:** Contained the `CHIM_CACHED_FEATURE: MINIMIZE_QUALITY_PROMPT`
marker comment and logic to toggle between minimized and full quality instructions
based on the connector's `minimize_quality_prompt` setting.

**What it did:**
```php
// v1.4 version (from CHIM 2.0.5 + cached connector):
// CHIM_CACHED_FEATURE: MINIMIZE_QUALITY_PROMPT
if ($useMinimizedPrompt) {
    // "Write {name}'s next dialogue line."
    // (shorter prompt for advanced models — saves tokens)
} else {
    // "Write {name}'s next dialogue line. Avoid narrations, be original..."
    // (longer prompt for older/smaller models)
}
```

**CHIM 2.3.3 upstream version:**
- Does NOT have the `MINIMIZE_QUALITY_PROMPT` marker
- Always uses the full verbose prompt
- Added new feature: `INLINE_NARRATION_ENABLED` toggle

**Impact of dropping:**
- The v2.0.1 UI (`llm_connectors.php`) still checks for the marker at
  `prompts/dialogue_prompt.php` to conditionally show the toggle
- Without the marker, the "Minimize Quality Instructions" checkbox is
  **silently hidden** from the UI
- The `minimize_quality_prompt` setting saved in connector metadata has
  **no effect** — the prompt is always verbose
- The connector's `open()` method still reads `minimize_quality_prompt`
  and uses it internally for action prefix filtering, but the dialogue
  prompt itself is unaffected

**Status: FEATURE LOST** — toggle hidden, setting ignored for dialogue prompt.

---

### 2. `lib/data_functions.php` — Immediate Sentence Streaming (Simple Format)

**Purpose in v1.4:** Added a `handlesSentenceSplitting()` integration point
so that connectors using simple format could bypass the 75-character
`MINIMUM_SENTENCE_SIZE` buffer requirement.

**What it did:**
```php
// v1.4 version — in the streaming loop:
$connectorHandlesSentences = (method_exists($connectionHandler, 'handlesSentenceSplitting') &&
                               $connectionHandler->handlesSentenceSplitting());

if (!$connectorHandlesSentences) {
    // JSON format: enforce 75-char minimum before sending
    if (strlen($buffer) < MINIMUM_SENTENCE_SIZE) {
        continue;
    }
}

// Later, for sentence extraction:
if ($connectorHandlesSentences) {
    // Simple format: send immediately when any sentence boundary found
    $shouldProcess = ($position !== false);
} else {
    // JSON format: require minimum size
    $shouldProcess = (($position !== false) && ($position > MINIMUM_SENTENCE_SIZE));
}
```

**CHIM 2.3.3 upstream version:**
- Completely rewrote the streaming/sentence-splitting logic
- No longer has the `handlesSentenceSplitting()` check
- Uses a new character-by-character sentence accumulator instead of
  regex-based splitting
- Has its own `MINIMUM_SENTENCE_SIZE` handling (different approach)

**The v2.0.1 connector still defines `handlesSentenceSplitting()`:**
```php
// In openrouterjsoncached.php (v2.0.1):
public function handlesSentenceSplitting() {
    return ($this->_responseFormat === 'simple');
}
```
But nothing in CHIM 2.3.3 calls it.

**Impact of dropping:**
- The `handlesSentenceSplitting()` method on the connector is dead code
- Simple format sentences are subject to the same buffering rules as JSON
- Sentence streaming may be slightly delayed (batched to 75+ chars)
  rather than immediate

**Status: FEATURE LOST** — method exists but is never called. Simple format
does not get immediate streaming benefit.

---

### 3. `lib/chat_helper_functions.php` — Asterisk/Dash Fix + Reasoning Token Stripping

**Purpose in v1.4:** Two independent features:

**Feature A: Asterisk/Dash Preservation Fix**
Fixed a regex in `findDotPosition()` that was consuming asterisks, dashes,
hashes, and at-signs during sentence splitting.

```php
// v1.4 fixed regex:
$splitSentenceRegex = "/(?<=[" . $eosPunc . "])(?!\.)[^\p{L}\p{N}\s\*\-\#\@\(\[\{]?[\s+]?/u";
// Explicitly excludes: * - # @ ( [ { from being consumed
```

CHIM 2.3.3 upstream rewrote `findDotPosition()` with a new regex that
requires whitespace after punctuation (`\s+`), which inherently avoids
consuming `*` and `-`. The bug is independently fixed by the rewrite.

**Status: NO LOSS** — upstream fixed this differently.

**Feature B: Reasoning/CoT Token Stripping Functions**
Added three functions for stripping reasoning/chain-of-thought tokens from
LLM output, used by the cached connector for JSON format:

```php
function stripReasoningTokens($text)        // Strip <think>, <thinking>, etc. blocks
function hasUnclosedReasoningMarker($text)   // Detect incomplete reasoning (streaming)
function extractReasoningFreeContent($text)  // Extract content outside reasoning tags
```

The cached connector intentionally enables reasoning/thinking at the API
level and strips tags itself (unlike upstream connectors which use API-level
exclusion via `"reasoning": {"exclude": true}`). The v2.0.1 connector calls
`stripReasoningTokens()` with a `function_exists()` guard — without these
functions, reasoning tags silently leak into NPC dialogue when using JSON
format with thinking enabled.

CHIM 2.3.3 upstream does NOT have these functions.

**Status: FEATURE LOST** — reasoning tags not stripped in JSON format.
Ported back in `claude/cached-chim-2.3.3-start-v2.0.1b-BBbgB`.

---

## CHIM 2.3.3 Upstream Bug (Separate Issue)

### `LOCATION_BLACKLIST` Fatal TypeError — `lib/data_functions.php:782`

The upstream CHIM 2.3.3 code added `LOCATION_BLACKLIST` filtering in two
places within `data_functions.php`:

**Correct implementation (line 688):**
```php
if (isset($GLOBALS["LOCATION_BLACKLIST"]) && !empty($GLOBALS["LOCATION_BLACKLIST"])) {
    $blacklistedLocations = array_map('trim', explode(',', strtolower($GLOBALS["LOCATION_BLACKLIST"])));
    // ... filtering logic ...
}
```

**Broken implementation (line 782):**
```php
$LOCATION_BLACKLIST_ARRAY=explode(",", $GLOBALS["LOCATION_BLACKLIST"] ?: []);
//                                                                      ^^
//                                     BUG: fallback is [] (array), not "" (string)
```

Two bugs:
1. No `isset()` check — triggers "Undefined global variable" warning when
   `conf.php` predates the addition of `$LOCATION_BLACKLIST`
2. The `?:` fallback is `[]` (empty array) — `explode()` requires a string,
   causing `TypeError: Argument #2 ($string) must be of type string, array given`

This is a **fatal error** that kills the entire request — no database
logging, no LLM call, no response.

**Fix applied:** `claude/upstream-investigate-BBbgB` branch, commit `c65efa2`.

---

## v2.0.1 Package Contents Comparison

| File | v1.4 | v2.0.1 | Status |
|------|------|--------|--------|
| `connector/openrouterjsoncached.php` | Yes | Yes | Updated |
| `connector/openrouterjsoncached_helpers.php` | Yes | Yes | Updated |
| `lib/core/llm_connector.class.php` | Yes | Yes | Updated |
| `ui/core/llm_connectors.php` | Yes | Yes | Updated |
| `conf/conf_schema.json` | Yes | Yes | Updated |
| `connector/OPENROUTERJSONCACHED_README.md` | Yes | Moved | -> `documentation/` |
| **`prompts/dialogue_prompt.php`** | **Yes** | **No** | **DROPPED — feature lost** |
| **`lib/data_functions.php`** | **Yes** | **No** | **DROPPED — feature lost** |
| **`lib/chat_helper_functions.php`** | **Yes** | **No** | **DROPPED — partial loss** (asterisk fix: no loss; reasoning stripping: feature lost) |

---

## Resolution Architecture

Each lost feature was evaluated for whether it **must** modify upstream files
or can be implemented without touching them.

### Files that MUST be overwritten (no alternative)

**`lib/data_functions.php`** — Two modifications, both unavoidable:

1. **LOCATION_BLACKLIST fix** (line 785) — Upstream bug in
   `DataPosibleLocationsToGo()`. Crashes fatally before any connector code
   runs. No hook, no ext override, no workaround.

2. **handlesSentenceSplitting integration** (lines 4079-4127) — Modifies
   `if` conditions inside the streaming `while(true)` loop in
   `call_llm_internal()`. No callback/hook mechanism exists in the loop.
   The `method_exists()` check on the connector object is already the
   cleanest pattern — but the loop conditions must be changed directly.

### Files that do NOT need overwriting

**`prompts/dialogue_prompt.php`** — The `requireFilesRecursively()` call
at line 115 loads `ext/*/dialogue_prompt.php` *after* the main file runs.
The MINIMIZE_QUALITY_PROMPT override is placed in
`ext/cached_connector/dialogue_prompt.php`, which strips the verbose
guidance text from `$TEMPLATE_DIALOG` when the cached connector is active.
**Upstream file stays unmodified.**

**`lib/chat_helper_functions.php`** — Two independent features were
extracted from this file:
- Reasoning functions → `lib/reasoning_helpers.php` (new standalone file)
- Asterisk preservation → small inline modification to `unmoodSentence()`
  (adds PRESERVE_ASTERISKS global check, ~10 lines)

The reasoning functions don't require overwriting. The asterisk
preservation does require a small change to `unmoodSentence()`, but
this is a new feature (not restoring a v1.4 feature) discovered during
the streaming bug investigation.

### Summary

| Feature | File Modified | Must Overwrite? | Resolution |
|---------|--------------|-----------------|------------|
| LOCATION_BLACKLIST fix | `lib/data_functions.php` | **Yes** | Inline fix (upstream bug) |
| handlesSentenceSplitting | `lib/data_functions.php` | **Yes** | Inline modification (no hook exists) |
| MINIMIZE_QUALITY_PROMPT | `ext/cached_connector/dialogue_prompt.php` | No | ext override system |
| Reasoning token stripping | `lib/reasoning_helpers.php` | No | New standalone file |
| Asterisk preservation | `lib/chat_helper_functions.php` | **Yes** | Inline modification (~10 lines) |
| Refusal filter disable | — | No | Existing `OPENAI_FILTER_DISABLED` mechanism |
| Asterisk/dash fix | — | N/A | Upstream fixed independently |

---

## Version Reference

- CHIM 2.0.5 branch: `origin/CHIM-2.0.5`
- CHIM 2.3.3 upstream: `upstream/aiagent`
- Cached Connector v1.4 package: `chim_v1.4_package.zip` (in CHIM-2.0.5 branch)
- Cached Connector v2.0.1 package: `openrouterjsoncached_v2.0.1_CHIM2.3.3.zip`
- Fix branch: `claude/upstream-investigate-BBbgB`

Audit date: 2026-01-30
