---
name: chim-format-proxy-v0.1
description: CHIM Format Proxy project status and continuation notes
type: project
originSessionId: eb9dd7bb-fd2a-4dc6-b2da-e032e25f2ebd
---
# CHIM Format Proxy v0.1.0

## Location
- Source: `C:\GitHub\HerikaServer_Unknwn_20260116\dist\chim_format_proxy\`
- Installed to WSL: `/var/www/html/HerikaServer/proxy/` (DwemerAI4Skyrim3)
- Design doc: `dist/chim_format_proxy/DESIGN.md`

## Status: Working prototype, needs iteration

### What works
- Proxy starts, receives requests, forwards to upstream
- Install.bat copies files to WSL, installs deps, auto-patches CHIM
- CHIM UI shows Format Proxy Settings panel when driver=openrouterjsonreformat
- URL split: user enters upstream URL, setOldGlobals constructs proxy URL
- 4-type request logging (RAW_INPUT, TRANSFORMED_INPUT, RAW_OUTPUT, TRANSFORMED_OUTPUT)
- System prompt static/dynamic split (config-driven patterns in proxy_config.yaml)
- Assistant message rewriting (JSON -> clean text)
- Custom prompts: `x_custom_system_instruction` (appended to system) and
  `x_custom_last_instruction` (inserted before format instruction)
- Reasoning/thinking: `x_toggle_thinking`, `x_thinking_tokens` (Anthropic),
  `x_effort_level` (OpenAI). Proxy strips CHIM's reasoning and applies its own.
  CHIM's reasoning_model is set from x_toggle_thinking for timeout handling only.
- Transforms verified functional (Priority 1 done)

### Known issues / TODO for next session

#### Priority 4: Asterisk stripping issue (CHIM-side)
- CHIM strips text between asterisks via `unmoodSentence()` and
  `shouldStripNpcOutputAsterisks()` in chat_helper_functions.php
- This is controlled by `REMOVE_ASTERISKS_FROM_OUTPUT` global setting
- When asterisks are stripped, the text between them gets removed from TTS
- Example: `*keeps her voice low* Hello` becomes `Hello` (the narration part is lost)
- The cached connector had a `PRESERVE_ASTERISKS` per-connector toggle
- CHIM 3 already has `shouldStripNpcOutputAsterisks()` which checks
  `strip_emotes_from_output`, `REMOVE_ASTERISKS_FROM_NPC_OUTPUT`, and
  `REMOVE_ASTERISKS_FROM_OUTPUT` globals
- Could be fixed by setting `REMOVE_ASTERISKS_FROM_NPC_OUTPUT = false` in
  the connector's constructor or via a UI toggle
- NOT a proxy-side fix — this happens after the response reaches CHIM

#### Someday: Simple output format refinement
- All CHIM JSON fields are available as () toggles but only 4 enabled by default
- Item/amount only matter for non-Talk actions
- A smarter format might use conditional fields based on action type
- For now, the all-parenthetical approach works

## Architecture summary
- `connector/openrouterjsonreformat.php` extends openrouterjson, changes $this->name,
  auto-starts proxy via health check + nohup
- `setOldGlobals()` patch: constructs proxy URL from upstream URL + port,
  injects x_* settings into extra_parameters
- `apply_patches.py`: idempotent patcher that modifies 3 CHIM files
  (llm_connector.class.php, llm_connectors.php, conf_schema.json)
- Proxy is stateless — all config per-request from x_* fields in body
- start.bat uses `start /min wsl` to keep proxy alive in minimized window

## CHIM version
- Target: CHIM 3.0.0 (aiagent branch, DwemerAI4Skyrim3 WSL)
- The old cached connector was for CHIM 2.4.3
